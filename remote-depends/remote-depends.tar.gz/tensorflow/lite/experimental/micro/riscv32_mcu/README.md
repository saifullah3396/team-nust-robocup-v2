# RISC-V MCU

This folder contains TFLite kernel operations optimized for RISC-V micro
controllers.

It is designed to be portable even to 'bare metal', so it follows the same
design goals as the micro experimental port.
