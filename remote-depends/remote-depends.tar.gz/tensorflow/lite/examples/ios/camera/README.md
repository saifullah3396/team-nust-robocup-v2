## Using the iOS Demo App

Please read the [TensorFlow Lite iOS Demo App](https://www.tensorflow.org/lite/demo_ios) page.

## Using the iOS Demo App with support for select TensorFlow ops

TODO(ycling): Link to the select TensorFlow ops documentation when it's
done.

Follow the guide to TensorFlow Lite iOS Library with support for select
TensorFlow ops, then open `tflite_camera_example_with_flex.xcodeproj`.
Note that this project setting is not using CocoaPod.
