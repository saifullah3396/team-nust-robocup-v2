/**
 * @file MotionModule/KinematicsModule/KinematicsModule.cpp
 *
 * this file implements the class for solving the kinematics
 * of the robot.cout
 * Some parts of this Module have been extracted from the
 * NaoKinematics provided by:
 * @author Kofinas Nikos aka eldr4d, 2012 kouretes team
 * @author Vosk
 * @link https://github.com/kouretes/NAOKinematics
 * @cite Kofinas N., Orfanoudakis E., Lagoudakis M.: Complete Analytical
 *   Inverse Kinematics for NAO, Proceedings of the 13th International
 *   Conference on Autonomous Robot Systems and Competitions (ROBOTICA),
 *   Lisbon, Portugal, April 2013, pp. 1-6.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 08 Feb 2017
 */

#include "MotionModule/include/MotionModule.h"
#include "MotionModule/include/KinematicsModule/KinematicsModule.h"

#define JOINT_STATE(index, type) \
  joints[index]->states[(unsigned)type]
  
#define JOINT_T(index, type) \
  joints[index]->states[(unsigned)type]->trans

template <typename Scalar>
KinematicsModule<Scalar>::KinematicsModule(MotionModule* motionModule) :  
  MemoryBase(motionModule), 
  motionModule(motionModule),
  joints(NUM_JOINTS),
  linkChains(CHAINS_SIZE),
  links(NUM_JOINTS + TORSO_SIZE), 
  footOnGround(L_FOOT),
  ffBufferSize(15)
{
  GET_CONFIG( "KinCalibration", (Scalar, torsoPitchOffset, torsoPitchOffset), )
  initKinematicsModel();
  /*updateModel();
  Matrix<Scalar, 3, 1> extForces;
  Matrix<Scalar, 3, 1> extMoments;
  Matrix<Scalar, 3, 1> torsoForces;
  Matrix<Scalar, 3, 1> torsoMoments;
  extForces.setZero();
  extMoments.setZero();
  torsoForces.setZero();
  torsoMoments.setZero();
  for (int i = 0; i < CHAINS_SIZE; ++i) {
    Matrix<Scalar, 3, 1> chainForces;
    Matrix<Scalar, 3, 1> chainMoments;
    Matrix<Scalar, Dynamic, 1> torque = 
      newtonEulerForces(
        ACTUAL, i, extForces, extMoments, chainForces, chainMoments);
    torsoForces += chainForces;
    torsoMoments += chainMoments;
  }
  computeZmp();*/
  //setupJointsPlot();
}

template <typename Scalar>
KinematicsModule<Scalar>::~KinematicsModule() {}

template <typename Scalar>
void KinematicsModule<Scalar>::updateModel()
{
  updateJointStates();
  updateTorsoState();
  updateComState();
  prepareDHTransforms();
  updateFootToCamT();
  updateFootOnGround();
  updateTorsoToFeet();
  //computeZmp(CHAIN_L_LEG, KinematicsModule::ACTUAL);
  //cout << "footToCam: " << OVAR(Matrix<Scalar, 4, 4>, MotionModule::upperCamInFeet) << endl;
  //Matrix<Scalar, 4, 4> forwardTransform =
  //    MathsUtils::getTInverse(getForwardEffector(KinematicsModule::ACTUAL, CHAIN_L_LEG, ANKLE)) *
  //    getForwardEffector(KinematicsModule::ACTUAL, CHAIN_R_LEG, ANKLE);
  IOFormat OctaveFmt(StreamPrecision, 0, ", ", ";\n", "", "", "[", "]");
  //Matrix<Scalar, 4, 4> forwardTransform =OVAR(Matrix<Scalar, 4, 4>, MotionModule::upperCamInFeet);
  //Matrix<Scalar, 4, 4> forwardTransform =OVAR(Matrix<Scalar, 4, 4>, MotionModule::lowerCamInFeet);
  //cout << "ft: " << endl << forwardTransform.format(OctaveFmt) << endl;
  //cout << "limbJ: " << endl << computeLimbComJ(ACTUAL, CHAIN_L_LEG) << endl;
  //computeMassMatrix(ACTUAL, CHAIN_L_LEG).format(OctaveFmt);
  //cout << "R"<< endl << computeMassMatrix(ACTUAL, CHAIN_R_LEG).format(OctaveFmt) << endl;
  /*Scalar vm;
  Matrix<Scalar, 4, 4> endEffector;
  endEffector << 1, 0, 0, 0.10272,
                 0, 1, 0, 0.0,
                 0, 0, 1, -0.03519,
                 0, 0, 0, 1;
  computeVirtualMass(
    CHAIN_R_LEG,
    Matrix<Scalar, 3, 1>(1, 0, 0),
    endEffector,
    vm);
  cout << "virtual mass 1, 0, 0: " << vm << endl;
  computeVirtualMass(
    CHAIN_R_LEG,
    Matrix<Scalar, 3, 1>(cos(M_PI/4), sin(M_PI/4), 0),
    endEffector,
    vm);
  cout << "virtual mass 0.707, 0.707, 0: " << vm << endl;
  computeVirtualMass(
    CHAIN_R_LEG,
    Matrix<Scalar, 3, 1>(0, 0, 1),
    endEffector,
    vm);
  cout << "virtual mass 0, 0, 1: " << vm << endl;*/
  //printKinematicData();    
  //cout << "HERE" << endl;
  //cout << "forwardT: " << endl << forwardTransform << endl;
  //plotJointState(ACTUAL, HEAD_YAW);
}

template <typename Scalar>
void KinematicsModule<Scalar>::printKinematicData()
{
  IOFormat OctaveFmt(StreamPrecision, 0, ", ", ";\n", "", "", "[", "]");
  cout << "-------------------________________Printing Kinematic Data________________-------------------" << endl;
  for (int i = 0; i < NUM_JOINTS; ++i) {
    cout << "Joint[" << joints[i]->name << "]" << endl;
    cout << "Position:" << JOINT_STATE(i, JointStateType::ACTUAL)->position * 180 / M_PI << ",  ";
    cout << "Velocity:" << JOINT_STATE(i, JointStateType::ACTUAL)->velocity << ",  ";
    cout << "Acceleration:" << JOINT_STATE(i, JointStateType::ACTUAL)->accel << endl;
    cout << "Com: [" << links[i]->com.format(OctaveFmt) << " ,  Mass:" << links[i]->mass << endl;
    cout << "Inertias: " << endl << links[i]->inertia.format(OctaveFmt) << endl << " ------------------------ " << endl;
    cout << "DHMatrix: " << endl << JOINT_STATE(i, JointStateType::ACTUAL)->trans << endl << " ------------------------ " << endl;
  }
  cout << "[Torso]" << endl;
  cout << "Com: [" << links[NUM_JOINTS]->com.format(OctaveFmt) << " ,  Mass:" << links[NUM_JOINTS]->mass << endl;
  cout << "Inertia: " << endl << links[NUM_JOINTS]->inertia.format(OctaveFmt) << endl;
}

template <typename Scalar>
void KinematicsModule<Scalar>::setupJointsPlot()
{
  jointStateLogPath = ConfigManager::getLogsDirPath() + "KinematicsModule/JointState.txt";
  jointStateLog.open(
    jointStateLogPath.c_str(),
    std::ofstream::out | std::ofstream::trunc);
  jointStateLog.close();
  //gp << "set xrange [0:20]\nset yrange [0:20]\n";
  //gp << "plot '" << jointStateLogPath << "' using 1:2 with lines title 'Joint Position'" << endl;
}

template <typename Scalar> 
void KinematicsModule<Scalar>::plotJointState(const unsigned& index, const JointStateType& type)
{
  Scalar time = motionModule->getModuleTime();
  jointStateLog.open(jointStateLogPath.c_str(), fstream::app | fstream::out);
  jointStateLog << time
                << " " 
                << joints[index]->states[(unsigned)type]->position 
                << " " 
                << joints[index]->states[(unsigned)type]->velocity 
                << " " 
                << joints[index]->states[(unsigned)type]->accel 
                << "\n";
  jointStateLog.close();
  //cout << "time: " << time << endl;
  //gp << "replot '" << jointStateLogPath << "' using 1:2 with lines title 'Joint Position'" << endl;
  //gp << "replot '" << jointStateLogPath << "' using 1:3 with lines title 'Joint Velocity'" << endl;
  //gp << "replot '" << jointStateLogPath << "' using 1:4 with lines title 'Joint Acceleration'" << endl;
}

template <typename Scalar>
void KinematicsModule<Scalar>::updateJointStates()
{
  try {
    auto& posSensors = 
      IVAR(vector<float>, MotionModule::jointPositionSensors);
    for (size_t i = 0; i < NUM_JOINTS; ++i) {
      JOINT_STATE(i, JointStateType::ACTUAL)->prevPosition = JOINT_STATE(i, JointStateType::ACTUAL)->position;
      JOINT_STATE(i, JointStateType::ACTUAL)->prevVelocity = JOINT_STATE(i, JointStateType::ACTUAL)->velocity;
      JOINT_STATE(i, JointStateType::ACTUAL)->position = posSensors[i];
      JOINT_STATE(i, JointStateType::ACTUAL)->velocity = 
        (JOINT_STATE(i, JointStateType::ACTUAL)->position - JOINT_STATE(i, JointStateType::ACTUAL)->prevPosition) / 
        cycleTime;
      JOINT_STATE(i, JointStateType::ACTUAL)->accel = 
        (JOINT_STATE(i, JointStateType::ACTUAL)->velocity - JOINT_STATE(i, JointStateType::ACTUAL)->prevVelocity) / 
        cycleTime;
    }
  } catch (const exception& e) {
    cout << e.what();
  }
}

/**
 * Inertial sensors enum defined in Utils/include/HardwareIds.h
  GYROSCOPE_X = 0,
  GYROSCOPE_Y,
  GYROSCOPE_Z,
  TORSO_ANGLE_X,
  TORSO_ANGLE_Y,
  TORSO_ANGLE_Z,
  ACCELEROMETER_X,
  ACCELEROMETER_Y,
  ACCELEROMETER_Z,
 */ 
 
template <typename Scalar>
void KinematicsModule<Scalar>::updateTorsoState()
{
  try {
    // Need a kalman filter for this tracker.
    // Nao sensors are updated almost with cycle time of 40ms in memory
    // Whereas motion module runs at 10ms
    auto& inertial = IVAR(vector<float>, MotionModule::inertialSensors);
    torsoState->accel[0] = inertial[ACCELEROMETER_X];
    torsoState->accel[1] = inertial[ACCELEROMETER_Y];
    torsoState->accel[2] = inertial[ACCELEROMETER_Z];    
    MathsUtils::makeRotationXYZ(
      torsoState->rot,
      (Scalar) inertial[TORSO_ANGLE_X],
      (Scalar) inertial[TORSO_ANGLE_Y],
      0.f);
    torsoState->accel = torsoState->rot.block(0, 0, 3, 3) * torsoState->accel;
    torsoState->velocity = torsoState->velocity + torsoState->accel * cycleTime;
    //cout << "torsoState->rot:\n" << torsoState->rot << endl;
    //cout << "torso velocity:\n" << torsoState->velocity << endl;
    //cout << "torso accel:\n" << torsoState->accel << endl;
  } catch (const exception& e) {
    cout << e.what();
  }
}

template <typename Scalar>
void KinematicsModule<Scalar>::updateComState()
{
  comState->position = calculateCenterOfMass();
  comState->velocity = (comState->position - comState->prevPosition) / cycleTime;
  comState->accel = (comState->velocity - comState->prevVelocity) / cycleTime;
  comState->prevPosition = comState->position;
  comState->prevVelocity = comState->velocity;
}

template <typename Scalar>
void KinematicsModule<Scalar>::initKinematicsModel()
{
  torsoState = 
    boost::shared_ptr<TorsoState<Scalar> > (
      new TorsoState<Scalar>()
    );
  comState = 
    boost::shared_ptr<ComState<Scalar> > (
      new ComState<Scalar>()
    );
  vector<Matrix<Scalar, 3, 3> > inertiaTrans(NUM_JOINTS+1);
  cycleTime = motionModule->getPeriodMinMS() / ((Scalar) 1000);
  Matrix<Scalar, 3, 3> iMat = Matrix<Scalar, 3, 3>::Identity();
  Matrix<Scalar, 4, 4> t1, t2;
  for (size_t i = 0; i < NUM_JOINTS + 1; ++i) {
    links[i] = 
      boost::shared_ptr<LinkInfo<Scalar> > (
        new LinkInfo<Scalar>()
      );
    for (size_t j = 0; j < 3; ++j) {
      for (unsigned k = 0; k < 3; ++k) {
        links[i]->inertia(j, k) = InertiaMatrices[j + i * 3][k];
      }
    }
    inertiaTrans[i] = Matrix<Scalar, 3, 3>::Identity();
    //cout << linkInertias[i] << endl;
  }
  for (size_t i = 0; i < NUM_JOINTS; ++i) {
    DHParams<Scalar>* params = 
      new DHParams<Scalar>(
        jointDHConsts[i][0], 
        jointDHConsts[i][1], 
        jointDHConsts[i][2], 
        jointDHConsts[i][3]
      );
    joints[i] = 
      boost::shared_ptr<Joint<Scalar> > (
        new Joint<Scalar>(
          jointNameConsts[i],
          jointMaxPositionConsts[i],
          jointMinPositionConsts[i],
          jointMaxVelocityConsts[i],
          params)
      );
  }
  
  for (size_t i = 0; i < CHAINS_SIZE; ++i) {
    linkChains[i] = 
      boost::shared_ptr<LinkChain<Scalar> > (
        new LinkChain<Scalar>()
      );
  }
  
  linkChains[CHAIN_HEAD]->start = HEAD_YAW;
  linkChains[CHAIN_L_ARM]->start = L_SHOULDER_PITCH;
  linkChains[CHAIN_R_ARM]->start = R_SHOULDER_PITCH;
  linkChains[CHAIN_L_LEG]->start = L_HIP_YAW_PITCH;
  linkChains[CHAIN_R_LEG]->start = R_HIP_YAW_PITCH;

  linkChains[CHAIN_HEAD]->size = HEAD_SIZE;
  linkChains[CHAIN_L_ARM]->size = L_ARM_SIZE;
  linkChains[CHAIN_R_ARM]->size = R_ARM_SIZE;
  linkChains[CHAIN_L_LEG]->size = L_LEG_SIZE;
  linkChains[CHAIN_R_LEG]->size = R_LEG_SIZE;

  //!torso mass and center of mass definitions.
  links[NUM_JOINTS + TORSO]->com = Matrix<Scalar, 4, 1>(torsoX, torsoY, torsoZ, 1.0f);
  links[NUM_JOINTS + TORSO]->mass = torsoMass;
  //!----------------------Head Start------------------------!//
  //!End and base transformations.
  MathsUtils::makeTranslation(
    linkChains[CHAIN_HEAD]->startT,
    (Scalar) 0.0,
    (Scalar) 0.0,
    (Scalar) neckOffsetZ);
  MathsUtils::makeRotationXYZ(
    linkChains[CHAIN_HEAD]->endT,
    (Scalar) M_PI_2,
    (Scalar) M_PI_2,
    (Scalar) 0.0);
  //!Masses
  links[HEAD_YAW]->mass = headYawMass;
  links[HEAD_PITCH]->mass = headPitchMass;
  //!Center of mass vectors.
  links[HEAD_YAW]->com = Matrix<Scalar, 4, 1>(headYawX, headYawY, headYawZ, 1.0f);
  links[HEAD_PITCH]->com = Matrix<Scalar, 4, 1>(headPitchX, headPitchY, headPitchZ, 1.0f);
  links[HEAD_PITCH]->inertia = linkChains[CHAIN_HEAD]->endT.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[HEAD_PITCH]->com = linkChains[CHAIN_HEAD]->endT * links[HEAD_PITCH]->com;

  //!Transforming inertia tensor from the given frame to the joint frame.
  links[HEAD_PITCH]->inertia = 
    inertiaTrans[HEAD_PITCH] * 
    links[HEAD_PITCH]->inertia * 
    inertiaTrans[HEAD_PITCH].transpose();
  //!----------------------Head End------------------------!//

  //!-------------------Right Arm Start--------------------!//
  //!End and base transformations.
  MathsUtils::makeTranslation(
    linkChains[CHAIN_R_ARM]->startT,
    (Scalar) 0.0,
    (Scalar) -(shoulderOffsetY),
    (Scalar) shoulderOffsetZ);
  MathsUtils::makeRotationXYZ(
    linkChains[CHAIN_R_ARM]->endT,
    (Scalar) -M_PI_2,
    (Scalar) 0.0,
    (Scalar) -M_PI_2);
  linkChains[CHAIN_R_ARM]->endT(0, 3) = 0.f;
  linkChains[CHAIN_R_ARM]->endT(1, 3) = -handOffsetZ;
  linkChains[CHAIN_R_ARM]->endT(2, 3) = handOffsetX;

  //!Masses
  links[R_SHOULDER_PITCH]->mass = rShoulderPitchMass;
  links[R_SHOULDER_ROLL]->mass = rShoulderRollMass;
  links[R_ELBOW_YAW]->mass = rElbowYawMass;
  links[R_ELBOW_ROLL]->mass = rElbowRollMass;
  links[R_WRIST_YAW]->mass = rWristYawMass;

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) 0.0, (Scalar) 0.0);
  links[R_SHOULDER_PITCH]->com = Matrix<Scalar, 4, 1>(
    rShoulderPitchX,
    rShoulderPitchY,
    rShoulderPitchZ,
    1.0f);

  //!Fixing the coordinate system of center of mass.
  links[R_SHOULDER_PITCH]->com = t1 * links[R_SHOULDER_PITCH]->com;

  inertiaTrans[R_SHOULDER_PITCH] = t1.block(0, 0, 3, 3);
  inertiaTrans[L_SHOULDER_PITCH] = t1.block(0, 0, 3, 3);

  //!Fixing the Inertia tensor rotation.
  links[R_SHOULDER_PITCH]->inertia =
    inertiaTrans[R_SHOULDER_PITCH] * 
    links[R_SHOULDER_PITCH]->inertia * 
    inertiaTrans[R_SHOULDER_PITCH].transpose();

  /**
   * Both left and right have same transformations
   * hence Rotation Matrices
   */
  links[L_SHOULDER_PITCH]->inertia =
    inertiaTrans[L_SHOULDER_PITCH] * 
    links[L_SHOULDER_PITCH]->inertia * 
    inertiaTrans[L_SHOULDER_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) 0.0, (Scalar) 0.0, (Scalar) -M_PI_2);
  links[R_SHOULDER_ROLL]->com = Matrix<Scalar, 4, 1>(
    rShoulderRollX,
    rShoulderRollY,
    rShoulderRollZ,
    1.0f);

  inertiaTrans[R_SHOULDER_ROLL] = t1.block(0, 0, 3, 3);
  inertiaTrans[L_SHOULDER_ROLL] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_SHOULDER_ROLL]->com = t1 * links[R_SHOULDER_ROLL]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_SHOULDER_ROLL]->inertia =
    inertiaTrans[R_SHOULDER_ROLL] * 
    links[R_SHOULDER_ROLL]->inertia * 
    inertiaTrans[R_SHOULDER_ROLL].transpose();

  /**
   * Both left and right have same Scalarransformations
   * hence Rotation Matrices
   */
  links[L_SHOULDER_ROLL]->inertia =
    inertiaTrans[L_SHOULDER_ROLL] * 
    links[L_SHOULDER_ROLL]->inertia * 
    inertiaTrans[L_SHOULDER_ROLL].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(
    t1,
    (Scalar) -M_PI_2,
    (Scalar) 0.0,
    (Scalar) -M_PI_2);
  links[R_ELBOW_YAW]->com = Matrix<Scalar, 4, 1>(rElbowYawX, rElbowYawY, rElbowYawZ, 1.0f);


  inertiaTrans[R_ELBOW_YAW] = t1.block(0, 0, 3, 3);
  inertiaTrans[L_ELBOW_YAW] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_ELBOW_YAW]->com = t1 * links[R_ELBOW_YAW]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_ELBOW_YAW]->inertia =
    inertiaTrans[R_ELBOW_YAW] * 
    links[R_ELBOW_YAW]->inertia * 
    inertiaTrans[R_ELBOW_YAW].transpose();

  /**
   * Both left and right have same Scalarransformations
   * hence Rotation Matrices
   */
  links[L_ELBOW_YAW]->inertia =
    inertiaTrans[L_ELBOW_YAW] * 
    links[L_ELBOW_YAW]->inertia * 
    inertiaTrans[L_ELBOW_YAW].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) 0.0, (Scalar) 0.0, (Scalar) -M_PI_2);
  links[R_ELBOW_ROLL]->com = Matrix<Scalar, 4, 1>(
    rElbowRollX,
    rElbowRollY,
    rElbowRollZ,
    1.0f);


  inertiaTrans[R_ELBOW_ROLL] = t1.block(0, 0, 3, 3);
  inertiaTrans[L_ELBOW_ROLL] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_ELBOW_ROLL]->com = t1 * links[R_ELBOW_ROLL]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_ELBOW_ROLL]->inertia =
    inertiaTrans[R_ELBOW_ROLL] *
    links[R_ELBOW_ROLL]->inertia *
    inertiaTrans[R_ELBOW_ROLL].transpose();

  /**
   * Both left and right have same Scalarransformations
   * hence Rotation Matrices
   */
  links[L_ELBOW_ROLL]->inertia =
    inertiaTrans[L_ELBOW_ROLL] * 
    links[L_ELBOW_ROLL]->inertia * 
    inertiaTrans[R_ELBOW_ROLL].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) -M_PI_2, (Scalar) 0.0, (Scalar) -M_PI_2);
  links[R_WRIST_YAW]->com = Matrix<Scalar, 4, 1>(rWristYawX, rWristYawY, rWristYawZ, 1.0f);

  inertiaTrans[R_WRIST_YAW] = t1.block(0, 0, 3, 3);
  inertiaTrans[L_WRIST_YAW] = t1.block(0, 0, 3, 3);

  //!Fixing the coordinate system of center of mass.
  links[R_WRIST_YAW]->com = t1 * links[R_WRIST_YAW]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_WRIST_YAW]->inertia =
    inertiaTrans[R_WRIST_YAW] * 
    links[R_WRIST_YAW]->inertia * 
    inertiaTrans[R_WRIST_YAW].transpose();

  /**
   * Both left and right have same Scalarransformations
   * hence Rotation Matrices
   */
  links[L_WRIST_YAW]->inertia =
    inertiaTrans[L_WRIST_YAW] * 
    links[L_WRIST_YAW]->inertia * 
    inertiaTrans[L_WRIST_YAW].transpose();
  //!-------------------Right Arm End----------------------!//

  //!-------------------Left Arm Start--------------------!//

  //!End and base transformations.
  MathsUtils::makeTranslation(
    linkChains[CHAIN_L_ARM]->startT,
    (Scalar) 0.0,
    (Scalar) shoulderOffsetY,
    (Scalar) shoulderOffsetZ);
  linkChains[CHAIN_L_ARM]->endT = linkChains[CHAIN_R_ARM]->endT;

  //!Masses and center of mass vectors
  for (size_t i = 0; i < L_ARM_SIZE; i++) {
    links[linkChains[CHAIN_L_ARM]->start + i]->com =
      links[linkChains[CHAIN_R_ARM]->start + i]->com;
    links[linkChains[CHAIN_L_ARM]->start + i]->mass =
      links[linkChains[CHAIN_R_ARM]->start + i]->mass;
  }

  //!Fixing the center of mass coordinates
  links[L_SHOULDER_PITCH]->com(2) = -links[L_SHOULDER_PITCH]->com(2);
  links[L_SHOULDER_ROLL]->com(0) = -links[L_SHOULDER_ROLL]->com(0);
  links[L_ELBOW_YAW]->com(0) = -links[L_ELBOW_YAW]->com(0);
  links[L_ELBOW_ROLL]->com(0) = -links[L_ELBOW_ROLL]->com(0);
  links[L_WRIST_YAW]->com(0) = -links[L_WRIST_YAW]->com(0);

  //!-------------------Left Arm End--------------------!//

  //!------------------Right Leg Start------------------!//
  //!End and base transformations.
  MathsUtils::makeTranslation(
    linkChains[CHAIN_R_LEG]->startT,
    (Scalar) 0.0,
    (Scalar) -hipOffsetY,
    (Scalar) -hipOffsetZ);
  MathsUtils::makeRotationZYX(
    linkChains[CHAIN_R_LEG]->endT,
    (Scalar) M_PI,
    (Scalar) -M_PI_2,
    (Scalar) 0.0);
  rotRLeg = linkChains[CHAIN_R_LEG]->endT;

  //!Masses
  links[R_HIP_YAW_PITCH]->mass = rHipYawPitchMass;
  links[R_HIP_ROLL]->mass = rHipRollMass;
  links[R_HIP_PITCH]->mass = rHipPitchMass;
  links[R_KNEE_PITCH]->mass = rKneePitchMass;
  links[R_ANKLE_PITCH]->mass = rAnklePitchMass;
  links[R_ANKLE_ROLL]->mass = rAnkleRollMass;

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(
    t1,
    (Scalar) -M_PI_2 / 2,
    (Scalar) 0.0,
    (Scalar) -M_PI_2);
  links[R_HIP_YAW_PITCH]->com = Matrix<Scalar, 4, 1>(
    rHipYawPitchX,
    rHipYawPitchY,
    rHipYawPitchZ,
    1.0f);

  //!Fixing the coordinate system of center of mass.
  t1 = MathsUtils::getTInverse(t1);
  
  inertiaTrans[R_HIP_YAW_PITCH] = t1.block(0, 0, 3, 3);
  links[R_HIP_YAW_PITCH]->com = t1 * links[R_HIP_YAW_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_HIP_YAW_PITCH]->inertia =
    inertiaTrans[R_HIP_YAW_PITCH] * 
    links[R_HIP_YAW_PITCH]->inertia * 
    inertiaTrans[R_HIP_YAW_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI, (Scalar) M_PI_2, (Scalar) 0.0);
  links[R_HIP_ROLL]->com = Matrix<Scalar, 4, 1>(rHipRollX, rHipRollY, rHipRollZ, 1.0f);

  inertiaTrans[R_HIP_ROLL] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_HIP_ROLL]->com = t1 * links[R_HIP_ROLL]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_HIP_ROLL]->inertia =
   inertiaTrans[R_HIP_ROLL] * 
   links[R_HIP_ROLL]->inertia * 
   inertiaTrans[R_HIP_ROLL].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[R_HIP_PITCH]->com = Matrix<Scalar, 4, 1>(rHipPitchX, rHipPitchY, rHipPitchZ, 1.0f);

  inertiaTrans[R_HIP_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_HIP_PITCH]->com = t1 * links[R_HIP_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_HIP_PITCH]->inertia =
    inertiaTrans[R_HIP_PITCH] * 
    links[R_HIP_PITCH]->inertia * 
    inertiaTrans[R_HIP_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[R_KNEE_PITCH]->com = Matrix<Scalar, 4, 1>(
    rKneePitchX,
    rKneePitchY,
    rKneePitchZ,
    1.0f);

  inertiaTrans[R_KNEE_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_KNEE_PITCH]->com = t1 * links[R_KNEE_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_KNEE_PITCH]->inertia =
    inertiaTrans[R_KNEE_PITCH] * 
    links[R_KNEE_PITCH]->inertia *  
    inertiaTrans[R_KNEE_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[R_ANKLE_PITCH]->com = Matrix<Scalar, 4, 1>(
    rAnklePitchX,
    rAnklePitchY,
    rAnklePitchZ,
    1.0f);

  inertiaTrans[R_ANKLE_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_ANKLE_PITCH]->com = t1 * links[R_ANKLE_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_ANKLE_PITCH]->inertia =
    inertiaTrans[R_ANKLE_PITCH] * 
    links[R_ANKLE_PITCH]->inertia * 
    inertiaTrans[R_ANKLE_PITCH].transpose();

  //!Center of mass vectors.
  links[R_ANKLE_ROLL]->com = Matrix<Scalar, 4, 1>(
    rAnkleRollX,
    rAnkleRollY,
    rAnkleRollZ,
    1.0f);

  inertiaTrans[R_ANKLE_ROLL] = linkChains[CHAIN_R_LEG]->endT.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[R_ANKLE_ROLL]->com = linkChains[CHAIN_R_LEG]->endT * links[R_ANKLE_ROLL]->com;

  //!Fixing the Inertia tensor rotation.
  links[R_ANKLE_ROLL]->inertia =
    inertiaTrans[R_ANKLE_ROLL] * 
    links[R_ANKLE_ROLL]->inertia * 
    inertiaTrans[R_ANKLE_ROLL].transpose();
  //!------------------Right Leg Start------------------!//

  //!------------------Left Leg Start-------------------!//
  //!End and base transformations.
  MathsUtils::makeTranslation(
    linkChains[CHAIN_L_LEG]->startT,
    (Scalar) 0.0,
    (Scalar) hipOffsetY,
    (Scalar) -hipOffsetZ);
  tBaseLLegInv = linkChains[CHAIN_L_LEG]->startT;
  tBaseLLegInv = MathsUtils::getTInverse(tBaseLLegInv);
  MathsUtils::makeRotationZYX(
    linkChains[CHAIN_L_LEG]->endT,
    (Scalar) M_PI,
    (Scalar) -M_PI_2,
    (Scalar) 0.0);
  MathsUtils::makeRotationXYZ(
    rotFixLLeg,
    (Scalar) M_PI_4,
    (Scalar) 0.0,
    (Scalar) 0.0);
  tEndLLegInv = t1;
  tEndLLegInv = MathsUtils::getTInverse(tEndLLegInv);

  //!Masses
  links[L_HIP_YAW_PITCH]->mass = rHipYawPitchMass;
  links[L_HIP_ROLL]->mass = rHipRollMass;
  links[L_HIP_PITCH]->mass = rHipPitchMass;
  links[L_KNEE_PITCH]->mass = rKneePitchMass;
  links[L_ANKLE_PITCH]->mass = rAnklePitchMass;
  links[L_ANKLE_ROLL]->mass = rAnkleRollMass;

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(
    t1,
    (Scalar) -(3 * M_PI) / 4,
    (Scalar) 0.0,
    (Scalar) -M_PI_2);
  links[L_HIP_YAW_PITCH]->com = Matrix<Scalar, 4, 1>(
    rHipYawPitchX,
    -rHipYawPitchY,
    rHipYawPitchZ,
    1.0f);

  //!Fixing the coordinate system of center of mass.
  t1 = MathsUtils::getTInverse(t1);
  
  inertiaTrans[L_HIP_YAW_PITCH] = t1.block(0, 0, 3, 3);
  links[L_HIP_YAW_PITCH]->com = t1 * links[L_HIP_YAW_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[L_HIP_YAW_PITCH]->inertia =
    inertiaTrans[L_HIP_YAW_PITCH] * 
    links[L_HIP_YAW_PITCH]->inertia * 
    inertiaTrans[L_HIP_YAW_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI, (Scalar) M_PI_2, (Scalar) 0.0);
  links[L_HIP_ROLL]->com = Matrix<Scalar, 4, 1>(rHipRollX, -rHipRollY, rHipRollZ, 1.0f);
  
  inertiaTrans[L_HIP_ROLL] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[L_HIP_ROLL]->com = t1 * links[L_HIP_ROLL]->com;

  //!Fixing the Inertia tensor rotation.
  links[L_HIP_ROLL]->inertia =
    inertiaTrans[L_HIP_ROLL] * 
    links[L_HIP_ROLL]->inertia * 
    inertiaTrans[L_HIP_ROLL].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[L_HIP_PITCH]->com = Matrix<Scalar, 4, 1>(rHipPitchX, -rHipPitchY, rHipPitchZ, 1.0f);

  inertiaTrans[L_HIP_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[L_HIP_PITCH]->com = t1 * links[L_HIP_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[L_HIP_PITCH]->inertia =
    inertiaTrans[L_HIP_PITCH] * 
    links[L_HIP_PITCH]->inertia * 
    inertiaTrans[L_HIP_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[L_KNEE_PITCH]->com = Matrix<Scalar, 4, 1>(
    rKneePitchX,
    -rKneePitchY,
    rKneePitchZ,
    1.0f);

  inertiaTrans[L_KNEE_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[L_KNEE_PITCH]->com = t1 * links[L_KNEE_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[L_KNEE_PITCH]->inertia =
    inertiaTrans[L_KNEE_PITCH] * 
    links[L_KNEE_PITCH]->inertia *
    inertiaTrans[L_KNEE_PITCH].transpose();

  //!Center of mass vectors.
  MathsUtils::makeRotationXYZ(t1, (Scalar) M_PI_2, (Scalar) M_PI_2, (Scalar) 0.0);
  links[L_ANKLE_PITCH]->com = Matrix<Scalar, 4, 1>(
    rAnklePitchX,
    -rAnklePitchY,
    rAnklePitchZ,
    1.0f);

  inertiaTrans[L_ANKLE_PITCH] = t1.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[L_ANKLE_PITCH]->com = t1 * links[L_ANKLE_PITCH]->com;

  //!Fixing the Inertia tensor rotation.
  links[L_ANKLE_PITCH]->inertia =
    inertiaTrans[L_ANKLE_PITCH] * 
    links[L_ANKLE_PITCH]->inertia * 
    inertiaTrans[L_ANKLE_PITCH].transpose();

  //!Center of mass vectors.
  links[L_ANKLE_ROLL]->com = Matrix<Scalar, 4, 1>(
    rAnkleRollX,
    -rAnkleRollY,
    rAnkleRollZ,
    1.0f);

  inertiaTrans[L_ANKLE_ROLL] = linkChains[CHAIN_L_LEG]->endT.block(0, 0, 3, 3);
  //!Fixing the coordinate system of center of mass.
  links[L_ANKLE_ROLL]->com = linkChains[CHAIN_L_LEG]->endT * links[L_ANKLE_ROLL]->com;


  //!Fixing the Inertia tensor rotation.
  links[L_ANKLE_ROLL]->inertia =
    inertiaTrans[L_ANKLE_ROLL] * 
    links[L_ANKLE_ROLL]->inertia * 
    inertiaTrans[L_ANKLE_ROLL].transpose();

  //!------------------Left Leg End-------------------!//

  cout << "check!" << endl;
  cout << inertiaTrans[L_ANKLE_ROLL] << endl;
  cout << inertiaTrans[R_ANKLE_ROLL] << endl;
  cout << links[L_ANKLE_ROLL]->mass << endl;
  cout << links[R_ANKLE_ROLL]->mass << endl;
  cout << links[L_ANKLE_ROLL]->inertia << endl;
  cout << links[R_ANKLE_ROLL]->inertia << endl;
  cout << "check!" << endl;

  //!Moving Inertias of all joints to to center of mass
  for (size_t i = 0; i < NUM_JOINTS + 1; ++i) {
    links[i]->inertia =
      links[i]->inertia - links[i]->mass * ((links[i]->com.segment(0, 3).transpose() * links[i]->com.segment(
        0,
        3))(0, 0) * iMat - links[i]->com.segment(0, 3) * links[i]->com.segment(0, 3).transpose());
  }

  prepareDHTransforms();

  /*vector<Matrix<Scalar, 3, 1> > comsGlobal(NUM_JOINTS);
  Matrix<Scalar, 4, 4> T;
  unsigned chainStart = 0;
  unsigned n = 0;
  for (int i = 0; i < CHAINS_SIZE; ++i) {
    T = linkChains[i]->startT;
    for (int j = 0; j < linkChains[i]->size; ++j) {
      T = T * joints[linkChains[i]->start + j]->states[ACTUAL]->T;
      Matrix<Scalar, 3, 1> com = (T * links[linkChains[i]->size + j]->com).block(0, 0, 3, 1);
      comsGlobal[chainStart + j] = com;
      ++n;
    }
    chainStart = n;
  }

  for (size_t i = 0; i < NUM_JOINTS + 1; ++i) {
    cout << "Joint[" << jointNames[i] << "]" << endl;
    cout << "com" << endl;
    cout << comsGlobal[i] << endl;
    //cout << "inertia" << endl;
    //cout << 
    //  inertiaTrans[i].transpose() * 
    //  linkInertias[i] * 
    //  inertiaTrans[i] << endl;
  }*/

  //!Definition of effectors.
  linkChains[CHAIN_HEAD]->endEffectors.resize(NUM_CAMS);
  linkChains[CHAIN_L_LEG]->endEffectors.resize(NUM_LEG_EES);
  linkChains[CHAIN_R_LEG]->endEffectors.resize(NUM_LEG_EES);
  linkChains[CHAIN_L_ARM]->endEffectors.push_back(Matrix<Scalar, 4, 4>::Identity());
  linkChains[CHAIN_R_ARM]->endEffectors.push_back(Matrix<Scalar, 4, 4>::Identity());
  MathsUtils::makeTranslation(
    linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM],
    (Scalar) cameraTopX,
    (Scalar) 0.0,
    (Scalar) cameraTopZ);
  MathsUtils::makeTranslation(
    linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM],
    (Scalar) cameraBottomX,
    (Scalar) 0.0,
    (Scalar) cameraBottomZ);
  MathsUtils::makeRotationXYZ(t1, (Scalar) 0.0, (Scalar) M_PI_2, (Scalar) -M_PI_2);
  linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM] = linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM] * t1;
  linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM] =
    linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM] * t1;
  MathsUtils::makeRotationXYZ(t1, (Scalar) -cameraTopAngleY, //Y becomes -X after frame transfomration
    (Scalar) 0.0,
    (Scalar) 0.0);
  linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM] = linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM] * t1;
  MathsUtils::makeRotationXYZ(t1, (Scalar) -cameraBotAngleY, //Y becomes -X after frame transfomration
    (Scalar) 0.0,
    (Scalar) 0.0);
  linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM] =
    linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM] * t1;

  //cout << "Camera EEs" << endl;
  //cout << linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM] << endl;
  //cout << linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM] << endl;

  linkChains[CHAIN_L_LEG]->endEffectors[ANKLE] = Matrix<Scalar, 4, 4>::Identity();
  linkChains[CHAIN_R_LEG]->endEffectors[ANKLE] = Matrix<Scalar, 4, 4>::Identity();
  MathsUtils::makeTranslation(
    linkChains[CHAIN_L_LEG]->endEffectors[FEET_BASE],
    (Scalar) 0.0,
    (Scalar) 0.0,
    (Scalar) -footHeight);
  linkChains[CHAIN_R_LEG]->endEffectors[FEET_BASE] = linkChains[CHAIN_L_LEG]->endEffectors[FEET_BASE];
  Scalar totalChainsMass = 0;
  for (int i = 0; i < CHAINS_SIZE; ++i) {
    linkChains[i]->mass = 0;
    for (int j = 0; j < linkChains[i]->size; ++j) {
      linkChains[i]->mass += links[linkChains[i]->start + j]->mass;
      totalChainsMass += links[linkChains[i]->start + j]->mass;
    }
  }
  cout << "totalChainsMass:  " << totalChainsMass << endl;
  updateModel();
  feetForcesBuffer.set_capacity(ffBufferSize);
}

template <typename Scalar>
void
KinematicsModule<Scalar>::prepareDHTransforms(const unsigned& ch, const JointStateType& type)
{
  if (ch == CHAINS_SIZE) {
    for (size_t i = 0; i < NUM_JOINTS; ++i) {
      joints[i]->computeLinkTrans(type);
    } 
  } else {
    for (size_t i = linkChains[ch]->start; i < linkChains[ch]->start + linkChains[ch]->size; ++i) {
      joints[i]->computeLinkTrans(type);
    } 
  }
}

template <typename Scalar>
void
KinematicsModule<Scalar>::setEndEffector(const unsigned& chain, const unsigned& eeIndex,
  const Matrix<Scalar, 4, 1>& ee)
{
  Matrix<Scalar, 4, 4> t1;
  if (chain == CHAIN_R_LEG) {
    MathsUtils::makeTranslation(t1, ee[0], ee[1], ee[2]);
    linkChains[chain]->endEffectors[eeIndex] = t1;
    MathsUtils::makeTranslation(t1, ee[0], -ee[1], ee[2]);
    tEndLLegInv = t1;
    tEndLLegInv = MathsUtils::getTInverse(tEndLLegInv);
  }
  if (chain == CHAIN_L_LEG) {
    MathsUtils::makeTranslation(t1, ee[0], ee[1], ee[2]);
    linkChains[chain]->endEffectors[eeIndex] = t1;
    tEndLLegInv = t1;
    tEndLLegInv = MathsUtils::getTInverse(tEndLLegInv);
  } else {
    MathsUtils::makeTranslation(t1, ee[0], ee[1], ee[2]);
    linkChains[chain]->endEffectors[eeIndex] = t1;
  }
}

template <typename Scalar>
Matrix<Scalar, 4, 4>
KinematicsModule<Scalar>::getForwardEffector(
  const unsigned& chainIndex, const Matrix<Scalar, 4, 4> &endEffector, const JointStateType& type)
{
  Matrix<Scalar, 4, 4> t;
  t = linkChains[chainIndex]->startT;
  for (size_t i = 0; i < linkChains[chainIndex]->size; i++) {
    t *= JOINT_T(linkChains[chainIndex]->start + i, type);
  }
  t *= linkChains[chainIndex]->endT * endEffector;
  return t;
}

template <typename Scalar>
Matrix<Scalar, 4, 4>
KinematicsModule<Scalar>::getForwardEffector(
  const unsigned& chainIndex, const unsigned& eeIndex, const JointStateType& type)
{
  return getForwardEffector(chainIndex, linkChains[chainIndex]->endEffectors[eeIndex], type);
}

template <typename Scalar>
ComState<Scalar>
KinematicsModule<Scalar>::getComStateWrtFrame(
  const unsigned& baseFrame, 
  const unsigned& eeIndex)
{
  ComState<Scalar> tComState = *comState; // Get current com state
  // These readings will also require a kalman filter for good com state
  if (baseFrame >= 0 && baseFrame < CHAINS_SIZE) {
    Matrix<Scalar, 4, 4> T = 
      MathsUtils::getTInverse(getForwardEffector(baseFrame, eeIndex));
    MathsUtils::transformVector(T, tComState.position);
    tComState.velocity = T.block(0, 0, 3, 3) * tComState.velocity;
    tComState.accel = T.block(0, 0, 3, 3) * tComState.accel;
  }
  return tComState;
}

template <typename Scalar>
void
KinematicsModule<Scalar>::getComWrtBase(const unsigned& limbIndex,
  const unsigned& eeIndex, Matrix<Scalar, 3, 1> &comVector, const JointStateType& type)
{
  Matrix<Scalar, 3, 1> comWrtTorso = calculateCenterOfMass(type);
  if (limbIndex != -1) {
    comVector = MathsUtils::transformVector(
      MathsUtils::getTInverse(getForwardEffector(limbIndex, eeIndex, type)),
      comWrtTorso);
  } else {
    comVector = comWrtTorso;
  }
}

template <typename Scalar>
void
KinematicsModule<Scalar>::getComWrtBase(const unsigned& limbIndex,
  const unsigned& eeIndex, Matrix<Scalar, 2, 1>& comVector, const JointStateType& type)
{
  Matrix<Scalar, 3, 1> com;
  getComWrtBase(limbIndex, eeIndex, com, type);
  comVector[0] = com(0, 0);
  comVector[1] = com(1, 0);
}

template <typename Scalar>
Matrix<Scalar, Dynamic, 1>
KinematicsModule<Scalar>::cartToJointVels(
  const unsigned& chainIndex, const Matrix<Scalar, Dynamic, 1> cVels, const Matrix<Scalar, 4, 4> endEffector, const JointStateType& type)
{
  Matrix<Scalar, Dynamic, Dynamic> jacobian = computeLimbJ(chainIndex, endEffector, type);
  return MathsUtils::pseudoInverseSolve(jacobian, cVels);
}

template <typename Scalar>
Matrix<Scalar, Dynamic, Dynamic>
KinematicsModule<Scalar>::computeLimbJ(const unsigned& chainIndex,
  const unsigned& eeIndex, const JointStateType& type)
{
  return computeLimbJ(
    chainIndex,
    Matrix<Scalar, 4, 1>(
      linkChains[chainIndex]->endEffectors[eeIndex].block(0, 3, 4, 1)
    ),
    type);
}

template <typename Scalar>
Matrix<Scalar, Dynamic, Dynamic>
KinematicsModule<Scalar>::computeLimbJ(const unsigned& chainIndex,
  const Matrix<Scalar, 4, 4>& endEffector, const JointStateType& type)
{
  return computeLimbJ(chainIndex, Matrix<Scalar, 4, 1>(endEffector.block(0, 3, 4, 1)), type);
}

template <typename Scalar>
Matrix<Scalar, Dynamic, Dynamic>
KinematicsModule<Scalar>::computeLimbJ(const unsigned& chainIndex,
  const Matrix<Scalar, 4, 1>& endEffector, const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  unsigned chainStart = linkChains[chainIndex]->start;
  Matrix<Scalar, Dynamic, Dynamic> jacobian;
  vector<Matrix<Scalar, 3, 1> > z;
  vector<Matrix<Scalar, 3, 1> > pos;
  Matrix<Scalar, 4, 4> T;
  Matrix<Scalar, 3, 1> fPos;
  jacobian.resize(6, size);
  z.resize(size);
  pos.resize(size);
  //cout << "chainStarts" << chainStarts << endl;
  T = linkChains[chainIndex]->startT;
  for (int j = 0; j < size; ++j) {
    T = T * JOINT_T(chainStart + j, type);
    //cout << "T   " << T << endl;
    z[j] = T.block(0, 2, 3, 1);
    //cout << "z   " << z[j] << endl;
    pos[j] = T.block(0, 3, 3, 1);
    //cout << "pos   " << pos[j] << endl;
    jacobian.block(3, j, 3, 1) = z[j];
  }
  //cout << jacobian << endl;
  T = T * linkChains[chainIndex]->endT;
  fPos = (T * endEffector).block(0, 0, 3, 1);
  for (int j = 0; j < size; ++j) {
    jacobian.block(0, j, 3, 1) =
      MathsUtils::makeSkewMat(z[j]) * (fPos - pos[j]);
  }
  return jacobian;
}

template <typename Scalar>
Matrix<Scalar, Dynamic, Dynamic>
KinematicsModule<Scalar>::computeLimbComJ(
  const unsigned& chainIndex, const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  unsigned chainStart = linkChains[chainIndex]->start;
  Matrix<Scalar, Dynamic, Dynamic> jacobianC;
  Matrix<Scalar, Dynamic, Dynamic> jacobianCV;
  Matrix<Scalar, Dynamic, Dynamic> jacobianCW;
  Matrix<Scalar, 3, 1> comT;
  vector<Matrix<Scalar, 3, 1> > z;
  vector<Matrix<Scalar, 3, 1> > pos;
  Matrix<Scalar, 4, 4> T;
  Matrix<Scalar, 4, 1> ee;
  Matrix<Scalar, 4, 1> zero;
  Scalar partialMass = 0;
  jacobianC.resize(6, size);
  jacobianCV.resize(3, size);
  jacobianCW.resize(3, size);
  z.resize(size);
  pos.resize(size);
  T.setIdentity();
  jacobianC.setZero();
  comT.setZero();
  zero.setZero();
  zero(3, 0) = 1;
  Scalar chainMass = linkChains[chainIndex]->mass;
  //cout << "chainStart" << chainStart << endl;
  T = linkChains[chainIndex]->startT;
  for (int j = 0; j < size; ++j) {
    jacobianCV.setZero();
    jacobianCW.setZero();
    partialMass = links[chainStart + j]->mass;
    T = T * JOINT_T(chainStart + j, type);
    comT = (T * links[chainStart + j]->com).block(0, 0, 3, 1);
    //cout << "T   " << T << endl;
    z[j] = T.block(0, 2, 3, 1);
    //cout << "z   " << z[j] << endl;
    pos[j] = T.block(0, 3, 3, 1);
    //cout << "pos   " << pos[j] << endl;
    for (int m = 0; m <= j; ++m) {
      jacobianCW.block(0, m, 3, 1) = z[m];
      jacobianCV.block(0, m, 3, 1) = MathsUtils::makeSkewMat(z[m]) *
      //(comT + pos[j] - pos[m]);
      (comT - pos[m]);
    }
    jacobianC.block(3, 0, 3, size) =
      jacobianC.block(3, 0, 3, size) + jacobianCW * (partialMass / chainMass);
    jacobianC.block(3, 0, 3, size) =
      jacobianC.block(3, 0, 3, size) + jacobianCV * (partialMass / chainMass);
  }
  return jacobianC;
}

template <typename Scalar>
Matrix<Scalar, Dynamic, 1>
KinematicsModule<Scalar>::solveComIK(const unsigned& baseLimb,
  const Matrix<Scalar, 6, 1>& comVelocityD,
  const vector<unsigned>& limbMotionSpace,
  const vector<Matrix<Scalar, Dynamic, 1> >& limbVelocitiesD, const vector<int>& eeIndices, const JointStateType& type)
{
  ASSERT(limbMotionSpace.size() == CHAINS_SIZE);
  ASSERT(eeIndices.size() == CHAINS_SIZE);
  ASSERT(baseLimb == CHAIN_L_LEG || baseLimb == CHAIN_R_LEG);
  vector<Matrix<Scalar, 4, 4> > limbTs(CHAINS_SIZE);
  Matrix<Scalar, 3, 3> rBase;
  Matrix<Scalar, 6, 6> XBase;
  Matrix<Scalar, 6, 6> Xo;
  vector<Matrix<Scalar, Dynamic, Dynamic> > limbComJs(CHAINS_SIZE);
  vector<Matrix<Scalar, Dynamic, Dynamic> > limbJs(CHAINS_SIZE);
  vector<Matrix<Scalar, 6, 6> > XiWithBase(CHAINS_SIZE);
  vector<Matrix<Scalar, Dynamic, Dynamic> > Xinv(CHAINS_SIZE);
  Matrix<Scalar, 3, 1> comWrtBaseLimb;
  limbTs[baseLimb] = getForwardEffector(baseLimb, eeIndices[baseLimb], type);
  rBase = MathsUtils::getTInverse(limbTs[baseLimb]).block(0, 0, 3, 3);
  Matrix<Scalar, 3, 1> eeBase = limbTs[baseLimb].block(0, 3, 3, 1);
  XBase << Matrix<Scalar, 3, 3>::Identity(), rBase * MathsUtils::makeSkewMat(eeBase), Matrix<Scalar, 3, 3>::Zero(), Matrix<Scalar, 3, 3>::Identity();
  Xo << rBase, Matrix<Scalar, 3, 3>::Zero(), Matrix<Scalar, 3, 3>::Zero(), rBase;
  getComWrtBase(baseLimb, eeIndices[baseLimb], comWrtBaseLimb, type);
  Matrix<Scalar, Dynamic, Dynamic> baseComJ;
  baseComJ.resize(6, linkChains[baseLimb]->size);
  baseComJ.setZero();
  Matrix<Scalar, 6, 1> baseComVelocityD = comVelocityD;
  limbJs[baseLimb] = computeLimbJ(baseLimb, eeIndices[baseLimb], type);
  Matrix<Scalar, Dynamic, Dynamic> baseJT = XBase * limbJs[baseLimb];
  Matrix<Scalar, 3, 1> comLimbsDiff = Matrix<Scalar, 3, 1>::Zero();
  for (size_t i = 0; i < CHAINS_SIZE; ++i) {
    limbComJs[i] = computeLimbComJ(i, type);
    limbComJs[i].block(0, 0, 3, linkChains[i]->size) = rBase * limbComJs[i].block(
      0,
      0,
      3,
      linkChains[i]->size);
    if (limbMotionSpace[i]) {
      if (i == baseLimb) {
        limbJs[i] = Xo * limbJs[i];
        baseComJ.block(3, 0, 3, linkChains[i]->size) = -limbJs[i].block(
          3,
          0,
          3,
          linkChains[i]->size);
        baseComJ.block(0, 0, 3, linkChains[i]->size) =
          baseComJ.block(0, 0, 3, linkChains[i]->size) + -limbJs[i].block(
            0,
            0,
            3,
            linkChains[i]->size) + MathsUtils::makeSkewMat(comWrtBaseLimb) * limbJs[i].block(
            3,
            0,
            3,
            linkChains[i]->size) + limbComJs[i].block(0, 0, 3, linkChains[i]->size);
      } else {
        limbTs[i] = getForwardEffector(i, eeIndices[i], type);
        limbJs[i] = computeLimbJ(i, eeIndices[i], type);
        Matrix<Scalar, 3, 1> ee = limbTs[i].block(0, 3, 3, 1);
        Matrix<Scalar, 6, 6> Xi;
        Xi << Matrix<Scalar, 3, 3>::Identity(), rBase * MathsUtils::makeSkewMat(ee), Matrix<Scalar, 3, 3>::Zero(), Matrix<Scalar, 3, 3>::Identity();
        XiWithBase[i] = Xi.inverse() * baseJT;
        Matrix<Scalar, Dynamic, Dynamic> X = Xo * limbJs[i];
        Xinv[i] = MathsUtils::pseudoInverse(X);
        baseComJ.block(0, 0, 3, linkChains[baseLimb]->size) =
          baseComJ.block(0, 0, 3, linkChains[baseLimb]->size) + limbComJs[i].block(
            0,
            0,
            3,
            linkChains[i]->size) * Xinv[i] * XiWithBase[i];
        comLimbsDiff =
          comLimbsDiff + limbComJs[i].block(0, 0, 3, linkChains[i]->size) * Xinv[i] * limbVelocitiesD[i];
      }
    } else {
      comLimbsDiff =
        comLimbsDiff + limbComJs[i].block(0, 0, 3, linkChains[i]->size) * limbVelocitiesD[i];
    }
  }
  baseComVelocityD.segment(0, 3) =
    baseComVelocityD.segment(0, 3) - comLimbsDiff;
  Matrix<Scalar, Dynamic, 1> jointD(NUM_JOINTS);
  vector<Matrix<Scalar, Dynamic, 1> > jointVD(CHAINS_SIZE);

  jointVD[baseLimb] = MathsUtils::pseudoInverseSolve(
    baseComJ,
    baseComVelocityD);
  for (size_t i = 0; i < CHAINS_SIZE; ++i) {
    if (i != baseLimb) {
      jointVD[i].resize(linkChains[i]->size);
      jointVD[i].setZero();
      if (limbMotionSpace[i]) {
        Matrix<Scalar, Dynamic, Dynamic> rhs = limbVelocitiesD[i] + XiWithBase[i] * jointVD[baseLimb];
        jointVD[i] = Xinv[i] * rhs;
      }
    }
    for (size_t j = linkChains[i]->start; j < linkChains[i]->start + linkChains[i]->size; ++j) {
      jointD[j] = JOINT_STATE(j, type)->position + jointVD[i][j] * cycleTime;
    }
  }
  return jointD;
}

template <typename Scalar>
Matrix<Scalar, Dynamic, Dynamic>
KinematicsModule<Scalar>::computeMassMatrix(
  const unsigned& chainIndex, const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  unsigned chainStart = linkChains[chainIndex]->start;
  Matrix<Scalar, Dynamic, Dynamic> jacobianCV;
  Matrix<Scalar, Dynamic, Dynamic> jacobianCW;
  Matrix<Scalar, Dynamic, Dynamic> massMatrix;
  Matrix<Scalar, 3, 1> comT;
  vector<Matrix<Scalar, 3, 1> > z;
  vector<Matrix<Scalar, 3, 1> > pos;
  Matrix<Scalar, 4, 4> T;
  Matrix<Scalar, 4, 1> ee;
  Matrix<Scalar, 4, 1> zero;
  jacobianCV.resize(3, size);
  jacobianCW.resize(3, size);
  massMatrix.resize(size, size);
  z.resize(size);
  pos.resize(size);
  T.setIdentity();
  jacobianCV.setZero();
  jacobianCW.setZero();
  massMatrix.setZero();
  comT.setZero();
  zero.setZero();
  zero(3, 0) = 1;
  //Matrix<Scalar, Dynamic, Dynamic> combined;
  //combined.resize(3, size);
  //combined.setZero();
  //Scalar chainMass = chainMasses[chainIndex];
  T = linkChains[chainIndex]->startT;
  for (int j = 0; j < size; ++j) {
    jacobianCV.setZero();
    jacobianCW.setZero();
    T = T *  JOINT_T(chainStart + j, type);
    comT = (T * links[chainStart + j]->com).block(0, 0, 3, 1);
    z[j] = T.block(0, 2, 3, 1);
    pos[j] = T.block(0, 3, 3, 1);
    for (int m = 0; m <= j; ++m) {
      jacobianCW.block(0, m, 3, 1) = z[m];
      jacobianCV.block(0, m, 3, 1) = MathsUtils::makeSkewMat(z[m]) *
      //(comT + pos[j] - pos[m]);
      (comT - pos[m]);
    }
    massMatrix =
      massMatrix + 
      links[chainStart + j]->mass * jacobianCV.transpose() * jacobianCV + 
      jacobianCW.transpose() * links[chainStart + j]->inertia * jacobianCW;
    //cout << "combined: " << endl << combined << endl;
    //combined = combined + jacobianCV * (links[chainStart + j]->mass / chainMass);
  }
  //cout << "combined: " << endl << combined << endl;
  //cout << massMatrix << endl;
  return massMatrix;
}

template <typename Scalar>
bool
KinematicsModule<Scalar>::computeVirtualMass(
  const unsigned& chainIndex, const Matrix<Scalar, 3, 1>& direction,
  const Matrix<Scalar, 4, 4>& endEffector, Scalar& virtualMass, const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  unsigned chainStart = linkChains[chainIndex]->start;
  //Matrix<Scalar, Dynamic, 1> joints = getJointPositions(chainStart, size, type);
  ////! center of mass of final link
  //Matrix<Scalar, Dynamic, Dynamic> T = MathsUtils::getTInverse(linkChains[chainIndex]->endT);
  //Matrix<Scalar, 4, 1> lastCom = T * linkComs[chainStart + size - 1];
  //cout << "lastCom: " << lastCom << endl;

  //! Inertia matrix (size x size) at given joint configuration
  Matrix<Scalar, Dynamic, Dynamic> massMatrix = computeMassMatrix(chainIndex, type);
  //cout << "Mass matrix: " << endl << massMatrix << endl;

  //Matrix<Scalar, Dynamic, Dynamic> jacobian = computeLimbJ(chainIndex, lastCom, type);
  //cout << "Jacobian: " << endl << jacobian << endl;
  //! Jacobian matrix (6 x size) at given joint configuration
  Matrix<Scalar, Dynamic, Dynamic> jacobianEE = computeLimbJ(chainIndex, endEffector, type);
  ///cout << "JacobianEE: " << endl << jacobianEE << endl;

  //! Inertia matrix inverse (size x size) at given joint configuration
  Matrix<Scalar, Dynamic, Dynamic> mmInv = massMatrix.inverse();
  //cout << "Mass matrix Inv: " << endl << mmInv << endl;

  //! Inertial projection in cartesian space (6x6)
  //! (G = 6x6 Symmetric) [G11, G12;G21, G22]
  //Matrix<Scalar, Dynamic, Dynamic> gMatrix = jacobian * mmInv * jacobian.transpose();
  //cout << " gMatrix: " << endl <<  gMatrix << endl;
  Matrix<Scalar, Dynamic, Dynamic> gMatrixEE = jacobianEE * mmInv * jacobianEE.transpose();
  //cout << "G-matrixEE: " << endl << gMatrixEE << endl;

  //! Position vector from center of mass to end effector
  //Matrix<Scalar, 3, 1> pos =
  //  endEffector.block(0, 3, 3, 1) - lastCom.block(0, 0, 3, 1);
  //Matrix<Scalar, 3, 3> skewPosT = MathsUtils::makeSkewMat(pos);
  //Matrix<Scalar, 3, 3> skewPos = skewPosT.transpose();
  //! Conversion of cartesian space inertia matrix from center of mass
  //! to the contact point using skewPos
  //Matrix<Scalar, 3, 3> g11 = gMatrix.block(0, 0, 3, 3);
  //Matrix<Scalar, 3, 3> g12 = gMatrix.block(0, 3, 3, 3);
  //Matrix<Scalar, 3, 3> g22 = gMatrix.block(3, 3, 3, 3);
  //Matrix<Scalar, Dynamic, Dynamic> transfMassMatrix =
  // g11 + skewPos * g12.transpose() + g12* skewPosT + skewPos * g22 * skewPosT;
  //cout << "G-matrix: " << endl << transfMassMatrix << endl;
  //cout << "G12: " << endl << g12 + skewPos *g22 << endl;
  //cout << "G22: " << endl << g22 << endl;
  Matrix<Scalar, Dynamic, Dynamic> g11 = gMatrixEE.block(0, 0, 3, 3);
  //! Virtual Mass in the target direction
  //virtualMass = direction.transpose() * transfMassMatrix * direction;
  virtualMass = direction.transpose() * g11 * direction;
  if (virtualMass != 0) {
    virtualMass = 1.f / virtualMass;
    //PRINT("Calculated virtual mass =" + DataUtils::varToString(virtualMass));
    return true;
  } else return false;
}

template <typename Scalar>
Matrix<Scalar, Dynamic, 1>
KinematicsModule<Scalar>::newtonEulerForces(
  const unsigned& chainIndex, const Matrix<Scalar, 3, 1>& extForces,
  const Matrix<Scalar, 3, 1>& extMoments, Matrix<Scalar, 3, 1>& totalForces, Matrix<Scalar, 3, 1>& totalMoments, 
  const unsigned& supportLeg, const JointStateType& type)
{
  unsigned chainSize = linkChains[chainIndex]->size;
  unsigned chainStart = linkChains[chainIndex]->start;
  //!Forward Recursion
  Matrix<Scalar, 3, 1> zAxis(0, 0, 1);
  Matrix<Scalar, 3, 1> linAcc(0, 0, -gConst);
  Matrix<Scalar, 3, 1> angVel(0, 0, 0);
  Matrix<Scalar, 3, 1> angAcc(0, 0, 0);
  Matrix<Scalar, 3, 1> linAccCom(0, 0, 0);
  vector<Matrix<Scalar, 3, 1> > comForces(chainSize);
  vector<Matrix<Scalar, 3, 1> > comMoments(chainSize);

  //! Rotating torso forces and moments to inertial frame situated at 
  //! the base support leg
  Matrix<Scalar, 4, 4> supportT = getForwardEffector(supportLeg, FEET_BASE, type);
  linAcc = MathsUtils::transformVector(supportT, linAcc);

  //cout << "chainSize" << chainSize << endl;
  //cout << "chainStart" << chainStart << endl;
  for (size_t i = 0; i < chainSize; ++i) {
    Matrix<Scalar, 4, 4> tMat =  JOINT_T(chainStart + i, type);
    Matrix<Scalar, 3, 3> rotMat = tMat.block(0, 0, 3, 3).transpose(); // transposed
    Matrix<Scalar, 3, 1> transMat = tMat.block(0, 3, 3, 1);
    angVel = rotMat * angVel + zAxis * JOINT_STATE(chainStart + i, type)->velocity; // good
    angAcc = rotMat * angAcc + (rotMat * angVel).cross(
      zAxis *  JOINT_STATE(chainStart + i, type)->velocity) + 
      zAxis * JOINT_STATE(chainStart + i, type)->accel;  // good
    linAcc = rotMat * (angAcc.cross(transMat) + angVel.cross(
      angVel.cross(transMat)) + linAcc);  // good
    Matrix<Scalar, 3, 1> comP = links[chainStart + i]->com.segment(0, 3);
    linAccCom =
      angAcc.cross(comP) + angVel.cross(angVel.cross(comP)) + linAcc;
    comForces[i] = links[chainStart + i]->mass * linAccCom;
    comMoments[i] = links[chainStart + i]->inertia * angVel + angVel.cross(
      links[chainStart + i]->inertia * angVel);
    
    /*cout << "comForces[" << i << "]" << "      "<< comForces[i](0,0) << endl;
    cout << "comForces[" << i << "]" << "      "<< comForces[i](1,0) << endl;
    cout << "comForces[" << i << "]" << "      "<< comForces[i](2,0) << endl;
    cout << "comMoments[" << i << "]" << "      "<< comMoments[i](0,0) << endl;
    cout << "comMoments[" << i << "]" << "      "<< comMoments[i](1,0) << endl;
    cout << "comMoments[" << i << "]" << "      "<< comMoments[i](2,0) << endl;
    cout<< endl;*/
  }

  //!Backward Recursion
  Matrix<Scalar, Dynamic, 1> jointTorques;
  jointTorques.resize(chainSize);
  Matrix<Scalar, 3, 1> f(0, 0, 0);
  Matrix<Scalar, 3, 1> n(0, 0, 0);
  for (size_t i = chainSize; i > 0; --i) {
    Matrix<Scalar, 4, 4> tMat;
    if (i == chainSize) {
      tMat.setIdentity();
      f = extForces;
      n = extMoments;
    } else {
      tMat =  JOINT_T(chainStart + i, type);
    }
    Matrix<Scalar, 3, 3> rotMat = tMat.block(0, 0, 3, 3);
    Matrix<Scalar, 3, 1> transMat = tMat.block(0, 3, 3, 1);
    Matrix<Scalar, 3, 1> comP = links[chainStart + i - 1]->com.segment(0, 3);
    n = comMoments[i-1] + rotMat * n + comP.cross(comForces[i-1]) + transMat.cross(rotMat * f);
    f = comForces[i-1] + rotMat * f;
    jointTorques[i-1] = n.transpose() * zAxis;
  }
  auto initRot = JOINT_T(chainStart, type).block(0, 0, 3, 3);
  f = initRot * f;
  n = initRot * n;
  //jointTorques[0] = n.transpose() * zAxis;
  /*cout << "forces" << f(0,0) << endl;
  cout << "forces" << f(1,0) << endl;
  cout << "forces" << f(2,0) << endl;
  cout << "moments" << n(0,0) << endl;
  cout << "moments" << n(1,0) << endl;
  cout << "moments" << n(2,0) << endl;*/
  
  //! Relocating moments to torso origin frame
  n = n + Matrix<Scalar, 3, 1>(linkChains[chainIndex]->startT.block(0, 3, 3, 1)).cross(f);
  // f remains the same
      
  totalMoments = n;
  totalForces = f;
  return jointTorques;
}

template <typename Scalar>
Matrix<Scalar, 2, 1> KinematicsModule<Scalar>::computeZmp(
  const unsigned& supportLeg, const JointStateType& type)
{
  Matrix<Scalar, 3, 1> extForces;
  Matrix<Scalar, 3, 1> extMoments;
  Matrix<Scalar, 3, 1> torsoForces;
  Matrix<Scalar, 3, 1> torsoMoments;
  extForces.setZero();
  extMoments.setZero();
  torsoForces.setZero();
  torsoMoments.setZero();
  for (int i = 0; i < CHAINS_SIZE; ++i) {
    Matrix<Scalar, 3, 1> chainForces;
    Matrix<Scalar, 3, 1> chainMoments;
    Matrix<Scalar, Dynamic, 1> torque = 
      newtonEulerForces(
        i, extForces, extMoments, chainForces, chainMoments, supportLeg, type);
    torsoForces += chainForces;
    torsoMoments += chainMoments;
  }
  
  //! Rotating torso forces and moments to inertial frame situated at 
  //! the base support leg
  Matrix<Scalar, 4, 4> supportT;
  supportT =
    MathsUtils::getTInverse(
      getForwardEffector(supportLeg, FEET_BASE, type)
    );
    
  Matrix<Scalar, 3, 3> supportR = supportT.block(0, 0, 3, 3);
  torsoForces = supportR * torsoForces;
  torsoMoments = supportR * torsoMoments;  
  
  //! Torso weight and vector
  Matrix<Scalar, 3, 1> torsoCog, batteryCog;
  torsoCog = (supportT * links[NUM_JOINTS + TORSO]->com).block(0, 0, 3, 1); // Torso center of mass
  //batteryCog = (supportT * Matrix<Scalar, 4, 1>(batteryX, batteryY, batteryZ, 1.f)).block(0, 0, 3, 1); // Battery center of mass
  auto torsoWeight = Matrix<Scalar, 3, 1>(0.f, 0.f, links[NUM_JOINTS + TORSO]->mass * -gConst);
  //auto batteryWeight = Matrix<Scalar, 3, 1>(0.f, 0.f, batteryMass * -gConst);
  
  //! Resulatant moments and forces at the base frame
  torsoMoments = 
    torsoMoments + 
    Matrix<Scalar, 3, 1>(supportT.block(0, 3, 3, 1)).cross(torsoForces) +
    torsoCog.cross(torsoWeight);//
    //batteryCog.cross(batteryWeight);
  
  Matrix<Scalar, 3, 1> rForce = -torsoForces - torsoWeight;// - batteryWeight;
  
  // zmp_y * R_z - zmp_z * R_y + M_x = 0
  // zmp_z * R_x - zmp_x * R_z + M_y = 0
  // zmp_x * R_y - zmp_y * R_x + M_z = 0
  
  Matrix<Scalar, 2, 1> zmp;
  zmp[0] = torsoMoments[1] / rForce[2]; // M_y / R_z
  zmp[1] = - torsoMoments[0] / rForce[2]; // - M_x / R_z  
  
  Matrix<Scalar, 2, 1> com;
  getComWrtBase(supportLeg, FEET_BASE, com, type);
  //cout << "Center of mass: " << endl;
  //cout << com << endl;
  
  //cout << "Zmp: " << endl;
  //cout << zmp << endl;
  return zmp;
}

template <typename Scalar>
Matrix<Scalar, 3, 1>
KinematicsModule<Scalar>::calculateCenterOfMass(const JointStateType& type)
{
  Matrix<Scalar, 3, 1> com;
  Matrix<Scalar, 4, 4> T;
  com.setZero();
  unsigned chainStarts = 0;
  unsigned n = 0;
  for (int i = 0; i < CHAINS_SIZE; ++i) {
    T = linkChains[i]->startT;
    for (int j = 0; j < linkChains[i]->size; ++j) {
      T = T * JOINT_T(chainStarts + j, type);
      Matrix<Scalar, 3, 1> temp = (T * links[chainStarts + j]->com).block(0, 0, 3, 1);
      com = com + temp * links[chainStarts + j]->mass;
      ++n;
    }
    chainStarts = n;
  }
  com =
    com + links[NUM_JOINTS + TORSO]->com.block(0, 0, 3, 1) * links[NUM_JOINTS + TORSO]->mass;
  //com = com + Matrix<Scalar, 3, 1>(batteryX, batteryY, batteryZ) * batteryMass;
  com = com / totalMassH25;
  return com;
}

template <typename Scalar>
void
KinematicsModule<Scalar>::updateFootOnGround()
{
  auto& fsrSensors = IVAR(vector<float>, MotionModule::fsrSensors);
  feetForcesBuffer.push_back(
    Matrix<Scalar, 2, 1>(fsrSensors[L_FOOT_TOTAL_WEIGHT], fsrSensors[R_FOOT_TOTAL_WEIGHT]));
  if (feetForcesBuffer.size() >= ffBufferSize) {
    Matrix<Scalar, 2, 1> bufferAvg = Matrix<Scalar, 2, 1>::Zero();
    for (int i = 0; i < feetForcesBuffer.size(); ++i)
      bufferAvg = bufferAvg + feetForcesBuffer[i];
    bufferAvg = bufferAvg / ffBufferSize;

    if (bufferAvg[L_FOOT] < 0.1 && bufferAvg[R_FOOT] < 0.1) {
      footOnGround = -1;
    } else {
      if (bufferAvg[L_FOOT] > 1.3) footOnGround = L_FOOT;
      else if (bufferAvg[R_FOOT] > 1.3) footOnGround = R_FOOT;
      else footOnGround = L_FOOT;
    }
    
    
  }
}

template <typename Scalar> Matrix<Scalar, 4, 4>
KinematicsModule<Scalar>::getFeetCenterT()
{
  Matrix<Scalar, 4, 4> T;
  Matrix<Scalar, 4, 4> ee;
  if (footOnGround == L_FOOT) {
    ee = linkChains[CHAIN_L_LEG]->endEffectors[FEET_BASE];
    MathsUtils::makeTranslation(T, (Scalar) 0.0, (Scalar) -0.05, (Scalar) 0.0);
    ee = ee * T;
    T = getForwardEffector(CHAIN_L_LEG, ee);
  } else if (footOnGround == R_FOOT) {
    ee = linkChains[CHAIN_R_LEG]->endEffectors[FEET_BASE];
    MathsUtils::makeTranslation(T, (Scalar) 0.0, (Scalar) 0.05, (Scalar) 0.0);
    ee = ee * T;
    T = getForwardEffector(CHAIN_R_LEG, ee);
  } else {
    ee = linkChains[CHAIN_L_LEG]->endEffectors[FEET_BASE];
    MathsUtils::makeTranslation(T, (Scalar) 0.0, (Scalar) -0.05, (Scalar) 0.0);
    ee = ee * T;
    T = getForwardEffector(CHAIN_L_LEG, ee);
  }
  return T;
}

template <typename Scalar> void
KinematicsModule<Scalar>::updateTorsoToFeet()
{
  OVAR(Matrix4f, MotionModule::lFootOnGround) = 
    getForwardEffector(CHAIN_L_LEG, FEET_BASE).template cast <float> ();
  OVAR(Matrix4f, MotionModule::rFootOnGround) = 
    getForwardEffector(CHAIN_R_LEG, FEET_BASE).template cast <float> ();
}

template <typename Scalar> Matrix<Scalar, 4, 1>
KinematicsModule<Scalar>::getWorldToCam(
  const unsigned& camIndex, const Matrix<Scalar, 4, 1>& posInFoot)
{
  if (camIndex == TOP_CAM) {
    return OVAR(Matrix4f, MotionModule::upperCamInFeet).cast <Scalar> () * posInFoot;
  } else {
    return OVAR(Matrix4f, MotionModule::lowerCamInFeet).cast <Scalar> () * posInFoot;
  }
}

template <typename Scalar> void
KinematicsModule<Scalar>::updateFootToCamT()
{
  Matrix<Scalar, 4, 4> torsoToFeet = getFeetCenterT();
  //cout << "Feet center: \n" << torsoToFeet << endl;
  Matrix<Scalar, 4, 4> torsoPitchRot;
  MathsUtils::makeRotationXYZ(
    torsoPitchRot,
    (Scalar) 0.0,
    (Scalar) -torsoPitchOffset * M_PI / 180,
    (Scalar) 0.0);
  torsoToFeet = torsoPitchRot * torsoToFeet;
  //cout << "Feet center: \n" << torsoToFeet << endl;
  OVAR(Matrix4f, MotionModule::upperCamInFeet) =
    (MathsUtils::getTInverse(
      getForwardEffector(
        CHAIN_HEAD, linkChains[CHAIN_HEAD]->endEffectors[TOP_CAM])
     ) * torsoToFeet
    ).template cast <float> ();
  OVAR(Matrix4f, MotionModule::lowerCamInFeet) = 
    (MathsUtils::getTInverse(
      getForwardEffector(
        CHAIN_HEAD, linkChains[CHAIN_HEAD]->endEffectors[BOTTOM_CAM])
     ) * torsoToFeet
    ).template cast <float> ();
  //cout << "Tmatrix: " << endl << OVAR(Matrix<Scalar, 4, 4>, MotionModule::upperCamInFeet) << endl << endl;
  //cout << "Tmatrix: " << endl << OVAR(Matrix<Scalar, 4, 4>, MotionModule::lowerCamInFeet) << endl << endl;
  //cout << "Tmatrix Inv: " << endl << MathsUtils::getTInverse(OVAR(Matrix<Scalar, 4, 4>, MotionModule::upperCamInFeet)) << endl << endl;
}

template <typename Scalar> Matrix<Scalar, Dynamic, 1>
KinematicsModule<Scalar>::solveJacobianIK(
  const unsigned& chainIndex, const unsigned& eeIndex, const Matrix<Scalar, 4, 4>& targetT,
  const unsigned& maxIterations, const JointStateType& startType, const bool& solveForOrientation,
  const Scalar& pTol,
  const Scalar& oTol)
{
  return solveJacobianIK(
    chainIndex,
    linkChains[chainIndex]->endEffectors[eeIndex],
    targetT,
    maxIterations,
    startType,
    solveForOrientation,
    pTol,
    oTol);
}

template <typename Scalar>
Matrix<Scalar, Dynamic, 1>
KinematicsModule<Scalar>::solveJacobianIK(
  const unsigned& chainIndex, const Matrix<Scalar, 4, 4>& endEffector,
  const Matrix<Scalar, 4, 4>& targetT,
  const unsigned& maxIterations,
  const JointStateType& startType,
  const bool& solveForOrientation,
  const Scalar& pTol,
  const Scalar& oTol)
{
  JointStateType type = JointStateType::VALID;
  unsigned chainStart = linkChains[chainIndex]->start;
  unsigned chainSize = linkChains[chainIndex]->size;
  Scalar kP = 1.0, kO = 1.0;
  setStateFromTo(startType, type);
  auto initT = getForwardEffector(chainIndex, endEffector, type);
  Matrix<Scalar, 3, 1> initPos = initT.block(0, 3, 3, 1);
  Matrix<Scalar, 3, 1> targetPos = targetT.block(0, 3, 3, 1);
  Matrix<Scalar, 3, 1> diffPos = kP * (targetPos - initPos);
  Matrix<Scalar, 3, 1> diffOrient;
  if (solveForOrientation)
    diffOrient = kO * MathsUtils::getOrientationDiff(initT, targetT);
  bool success = false;
  if (solveForOrientation) {
    if (diffPos.norm() < pTol)
      success = true;
  } else {
    if (diffPos.norm() < pTol && diffOrient.norm() < oTol)
      success = true;
  }
  for (size_t i = 0; i < maxIterations; ++i) {
    Matrix<Scalar, Dynamic, Dynamic> J, jInv;
    Matrix<Scalar, Dynamic, 1> result;
    if (solveForOrientation) {
      J = computeLimbJ(chainIndex, endEffector, type);
      jInv = MathsUtils::pseudoInverse(J);
      Matrix<Scalar, 6, 1> diff;
      diff.block(0, 0, 3, 1) = diffPos;
      diff.block(3, 0, 3, 1) = diffOrient;
      result = jInv * diff;
    } else {
      J = computeLimbJ(chainIndex, endEffector, type).block(0, 0, 3, 6);
      jInv = MathsUtils::pseudoInverse(J);
      result = jInv * diffPos;
    }
    for (size_t i = 0; i < chainSize; ++i) {
      auto& position = JOINT_STATE(chainStart + i, type)->position;
      position += result[i];
      if (abs(position) > M_PI)
        position = atan2(sin(position), cos(position));
      if (position > joints[chainStart + i]->maxPosition) 
        position = joints[chainStart + i]->maxPosition;
      if (position < joints[chainStart + i]->minPosition) 
        position = joints[chainStart + i]->minPosition;
      JOINT_STATE(chainStart + i, type)->position = position;
    }
    prepareDHTransforms(chainIndex, type);
    initT = getForwardEffector(chainIndex, endEffector, type);
    initPos = initT.block(0, 3, 3, 1);
    if (solveForOrientation) {
      diffOrient = kO * MathsUtils::getOrientationDiff(initT, targetT);
    }
    diffPos = kP * (targetPos - initPos);
    if (solveForOrientation) {
      if (diffPos.norm() < pTol)
        success = true;
      else
        success = false;
    } else {
      if (diffPos.norm() < pTol && diffOrient.norm() < oTol)
        success = true;
      else
        success = false;
    }
  }
  cout << "Success: " << success << endl;
  cout << "diffO: " << diffOrient << endl;
  cout << "diffP: " << diffPos << endl;
  Matrix<Scalar, Dynamic, 1> angles;
  angles.resize(chainSize);
  if (!success) {
      for (size_t i = 0; i < chainSize; ++i)
        angles[i] = NAN;
  } else {
      for (size_t i = 0; i < chainSize; ++i)
        angles[i] = JOINT_STATE(chainStart + i, type)->position;
  }
  return angles;
}

template <typename Scalar>
vector<Matrix<Scalar, Dynamic, 1> >
KinematicsModule<Scalar>::inverseLeftLeg(
  const Matrix<Scalar, 4, 4>& endEffector,
  const Matrix<Scalar, 4, 4>& targetT)
{
  auto type = JointStateType::VALID;
  vector<Matrix<Scalar, Dynamic, 1> > returnResult;
  Matrix<Scalar, 4, 4> tTempTheta5, t4I, t5I, t6I, tTemp, tTemp2;
  Matrix<Scalar, 4, 4> t = targetT;
  Matrix<Scalar, 4, 4> tInit = t;

  //!Move the start point to the hipyawpitch point
  Matrix<Scalar, 4, 4> base = tBaseLLegInv;
  base *= t;

  //!Move the end point to the anklePitch joint
  base *= tEndLLegInv;

  //!Rotate hipyawpitch joint
  Matrix<Scalar, 4, 4> rot = rotFixLLeg;
  rot *= base;

  //!Invert the table, because we need the
  //!chain from the ankle to the hip
  Matrix<Scalar, 4, 4> tStart = rot;
  rot = MathsUtils::getTInverse(rot);
  t = rot;

  //!Build the rotation table
  Scalar side1 = thighLength;
  Scalar side2 = tibiaLength;
  Scalar distanceSqrd = pow(t.block(0, 3, 3, 1).norm(), 2);

  //!Calculate Theta 4
  Scalar theta4 = M_PI - MathsUtils::safeAcos(
    (pow(side1, 2) + pow(side2, 2) - distanceSqrd) / (2 * side1 * side2));
  if (theta4 != theta4) {
    return returnResult;
  }
  Scalar theta6 = atan(t(1, 3) / t(2, 3));
  //if(theta6 < lAnkleRollLow || theta6 > lAnkleRollHigh)
  //  return returnResult;
  if (theta6 < lAnkleRollLow) theta6 = lAnkleRollLow;
  else if (theta6 > lAnkleRollHigh) theta6 = lAnkleRollHigh;

  MathsUtils::makeDHTransformation(
    t6I,
    (Scalar) 0.0,
    (Scalar) -M_PI_2,
    (Scalar) 0.0,
    theta6);
  t6I *= rotRLeg;
  //try
  //{
  t6I = MathsUtils::getTInverse(t6I);
  tStart *= t6I;
  tTempTheta5 = tStart;
  tTempTheta5 = MathsUtils::getTInverse(tTempTheta5);
  //  }
  //catch(KMath::KMat::SingularMatrixInvertionException d)
  //{
  //return returnResult;
  //}
  for (int itter = 0; itter < 2; itter++) {
    theta4 = (itter == 0) ? theta4 : -theta4;
    if (theta4 < rKneePitchLow || theta4 > rKneePitchHigh) continue;
    MathsUtils::makeDHTransformation(
      t4I,
      (Scalar) -thighLength,
      (Scalar) 0.0,
      (Scalar) 0.0,
      theta4);
    Scalar up =
      tTempTheta5(1, 3) * (tibiaLength + thighLength * cos(theta4)) + thighLength * tTempTheta5(
        0,
        3) * sin(theta4);
    Scalar down = pow(thighLength, 2) * pow(sin(theta4), 2) + pow(
      tibiaLength + thighLength * cos(theta4),
      2);
    Scalar theta5 = asin(-up / down);
    Scalar posOrNegPIt5 = (theta5 >= 0) ? M_PI : -M_PI;
    if (theta5 != theta5 && up / down < 0) theta5 = -M_PI_2;
    else if (theta5 != theta5) theta5 = M_PI_2;
    for (int i = 0; i < 2; i++) {
      if (i == 0 && (theta5 > lAnklePitchHigh || theta5 < lAnklePitchLow)) continue;
      else if (i == 1 && (posOrNegPIt5 - theta5 > lAnklePitchHigh || posOrNegPIt5 - theta5 < lAnklePitchLow)) continue;
      else if (i == 1) theta5 = posOrNegPIt5 - theta5;
      MathsUtils::makeDHTransformation(
        t5I,
        (Scalar) -tibiaLength,
        (Scalar) 0.0,
        (Scalar) 0.0,
        theta5);
      tTemp = t4I;
      tTemp *= t5I;
      //try
      //  {
      tTemp = MathsUtils::getTInverse(tTemp);
      //}
      //catch(KMath::KMat::SingularMatrixInvertionException d)
      //{
      //  continue;
      //}
      tTemp2 = tStart;
      tTemp2 *= tTemp;
      Scalar temptheta2 = MathsUtils::safeAcos(tTemp2(1, 2));
      Scalar theta2;
      for (int l = 0; l < 2; l++) {
        if (l == 0 && (temptheta2 - M_PI_4 > lHipRollHigh || temptheta2 - M_PI_4 < lHipRollLow)) continue;
        else if (l == 1 && (-temptheta2 - M_PI_4 > lHipRollHigh || -temptheta2 - M_PI_4 < lHipRollLow)) continue;
        else if (l == 0) theta2 = temptheta2 - M_PI_4;
        else if (l == 1) theta2 = -temptheta2 - M_PI_4;
        Scalar theta3 = asin(tTemp2(1, 1) / sin(theta2 + M_PI_4));
        Scalar posOrNegPIt3 = (theta3 >= 0) ? M_PI : -M_PI;
        if (theta3 != theta3 && tTemp2(1, 1) / sin(theta2 + M_PI_4) < 0) theta3 =
          -M_PI_2;
        else if (theta3 != theta3) theta3 = M_PI_2;
        for (int k = 0; k < 2; k++) {
          if (k == 0 && (theta3 > lHipPitchHigh || theta3 < lHipPitchLow)) continue;
          else if (k == 1 && (posOrNegPIt3 - theta3 > lHipPitchHigh || posOrNegPIt3 - theta3 < lHipPitchLow)) continue;
          else if (k == 1) theta3 = posOrNegPIt3 - theta3;
          Scalar temptheta1 = MathsUtils::safeAcos(
            tTemp2(0, 2) / sin(theta2 + M_PI_4));
          if (temptheta1 != temptheta1) temptheta1 = 0;
          for (int p = 0; p < 2; p++) {
            Scalar theta1;

            if (p == 0 && (temptheta1 + M_PI_2 > lHipYawPitchHigh || -temptheta1 + M_PI_2 < lHipYawPitchLow)) continue;
            else if (p == 1 && (-temptheta1 + M_PI_2 > lHipYawPitchHigh || -temptheta1 + M_PI_2 < lHipYawPitchLow)) continue;
            else if (p == 0) theta1 = temptheta1 + M_PI_2;
            else if (p == 1) theta1 = -temptheta1 + M_PI_2;

            //!Forward VALID step
            JOINT_STATE(L_HIP_YAW_PITCH, type)->position = theta1;
            JOINT_STATE(L_HIP_ROLL, type)->position = theta2;
            JOINT_STATE(L_HIP_PITCH, type)->position = theta3;
            JOINT_STATE(L_KNEE_PITCH, type)->position = theta4;
            JOINT_STATE(L_ANKLE_PITCH, type)->position = theta5;
            JOINT_STATE(L_ANKLE_ROLL, type)->position = theta6;
            prepareDHTransforms(CHAIN_L_LEG, type);
            Matrix<Scalar, 4, 4> test = getForwardEffector(CHAIN_L_LEG, endEffector, type);
            if (MathsUtils::almostEqual(test, tInit)) {
              Matrix<Scalar, Dynamic, 1> r(R_LEG_SIZE);
              r[0] = theta1;
              r[1] = theta2;
              r[2] = theta3;
              r[3] = theta4;
              r[4] = theta5;
              r[5] = theta6;
              returnResult.push_back(r);
            }
          }
        }
      }
    }
  }
  return returnResult;
}

template <typename Scalar>
vector<Matrix<Scalar, Dynamic, 1> >
KinematicsModule<Scalar>::inverseRightLeg(const Matrix<Scalar, 4, 4>& endEffector,
  const Matrix<Scalar, 4, 4>& targetT)
{
  Matrix<Scalar, 4, 4> mirrored = MathsUtils::mirrorTransformation(targetT);
  vector<Matrix<Scalar, Dynamic, 1> > res = inverseLeftLeg(endEffector, mirrored);
  for (size_t i = 0; i < res.size(); i++) {
    res[i][1] = -res[i][1]; //HIP_ROLL
    res[i][5] = -res[i][5]; //ANKLE_ROLL
  }
  return res;
}

template <typename Scalar>
void KinematicsModule<Scalar>::setStateFromTo(
  const JointStateType& from, 
  const JointStateType& to)
{
  for (size_t i = 0; i < joints.size(); ++i) {
    joints[i]->states[(unsigned)to] = 
      joints[i]->states[(unsigned)from];
  }
  prepareDHTransforms(CHAINS_SIZE, to);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setJointPositions(
  const unsigned& startIndex, 
  const Matrix<Scalar, Dynamic, 1>& simPosition, 
  const JointStateType& type)
{
  ASSERT(startIndex + simPosition.size() <= NUM_JOINTS);
  for (size_t i = 0; i < simPosition.size(); ++i) {
    joints[startIndex + i]->states[(unsigned)type]->position = simPosition[i];
  }
  prepareDHTransforms(CHAINS_SIZE, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setChainPositions(
  const unsigned& chainIndex,
  const Matrix<Scalar, Dynamic, 1>& simPosition,
  const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  ASSERT(simPosition.size() == size);
  for (size_t i = 0; i < simPosition.size(); ++i) {
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->position = 
      simPosition[i];
  }
  prepareDHTransforms(chainIndex, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setJointVelocities(
  const unsigned& startIndex,
  const Matrix<Scalar, Dynamic, 1>& simVelocities,
  const JointStateType& type)
{
  ASSERT(startIndex + simVelocities.size() <= NUM_JOINTS);
  for (size_t i = 0; i < simVelocities.size(); ++i) {
    joints[startIndex + i]->states[(unsigned)type]->velocity = simVelocities[i];
  }
  prepareDHTransforms(CHAINS_SIZE, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setChainVelocities(
  const unsigned& chainIndex,
  const Matrix<Scalar, Dynamic, 1>& simVelocities,
  const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  ASSERT(simVelocities.size() == size);
  for (size_t i = 0; i < simVelocities.size(); ++i) {
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->velocity = 
      simVelocities[i];
  }
  prepareDHTransforms(chainIndex, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setJointAccelerations(
  const unsigned& startIndex,
  const Matrix<Scalar, Dynamic, 1>& simAccelerations,
  const JointStateType& type)
{
  ASSERT(startIndex + simAccelerations.size() <= NUM_JOINTS);
  for (size_t i = 0; i < simAccelerations.size(); ++i) {
    joints[startIndex + i]->states[(unsigned)type]->accel = simAccelerations[i];
  }
  prepareDHTransforms(CHAINS_SIZE, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setChainAccelerations(
  const unsigned& chainIndex,
  const Matrix<Scalar, Dynamic, 1>& simAccelerations,
  const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  ASSERT(simAccelerations.size() == size);
  for (size_t i = 0; i < simAccelerations.size(); ++i) {
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->accel = 
      simAccelerations[i];
  }
  prepareDHTransforms(chainIndex, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setJointState(
  const unsigned& startIndex,
  const Matrix<Scalar, Dynamic, 1>& simPosition, 
  const Matrix<Scalar, Dynamic, 1>& simVelocity,
  const Matrix<Scalar, Dynamic, 1>& simAcceleration,
  const JointStateType& type)
{
  ASSERT(startIndex + simPosition.size() <= NUM_JOINTS);
  ASSERT(
    simPosition.size() == simVelocity.size() && 
    simPosition.size() == simAcceleration.size());
  for (size_t i = 0; i < simPosition.size(); ++i) {
    joints[startIndex + i]->states[(unsigned)type]->position = simPosition[i];
    joints[startIndex + i]->states[(unsigned)type]->velocity = simVelocity[i];
    joints[startIndex + i]->states[(unsigned)type]->accel = simAcceleration[i];
  }
  prepareDHTransforms(CHAINS_SIZE, type);
}

template <typename Scalar>
void KinematicsModule<Scalar>::setChainState(
  const unsigned& chainIndex,
  const Matrix<Scalar, Dynamic, 1>& simPosition, 
  const Matrix<Scalar, Dynamic, 1>& simVelocity,
  const Matrix<Scalar, Dynamic, 1>& simAcceleration,
  const JointStateType& type)
{
  unsigned size = linkChains[chainIndex]->size;
  ASSERT(simPosition.size() == size);
  ASSERT(
    simPosition.size() == simVelocity.size() && 
    simPosition.size() == simAcceleration.size());
  for (size_t i = 0; i < simPosition.size(); ++i) {
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->position = 
      simPosition[i];
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->velocity = 
      simVelocity[i];
    joints[linkChains[chainIndex]->start + i]->states[(unsigned)type]->accel = 
      simAcceleration[i];
  }
  prepareDHTransforms(CHAINS_SIZE, type);  
}

template <typename Scalar>
boost::shared_ptr<Joint<Scalar> > 
KinematicsModule<Scalar>::getJoint(const unsigned& index)
{
  return joints[index];
}
  
template <typename Scalar>
boost::shared_ptr<JointState<Scalar> > 
KinematicsModule<Scalar>::getJointState(
  const unsigned& index, 
  const JointStateType& type)
{
  return joints[index]->states[(unsigned)type];
}

template <typename Scalar>
vector<boost::shared_ptr<Joint<Scalar> > > 
KinematicsModule<Scalar>::getJoints(
  const unsigned& startIndex,
  const unsigned& nElements)
{
  ASSERT(startIndex + nElements <= NUM_JOINTS);
  return 
    vector<boost::shared_ptr<Joint<Scalar> > >(
      joints.begin() + startIndex, 
      joints.begin() + startIndex + nElements
    );
}

template <typename Scalar>
vector<boost::shared_ptr<JointState<Scalar> > > 
KinematicsModule<Scalar>::getJointStates(
  const unsigned& startIndex,
  const unsigned& nElements,
  const JointStateType& type)
{
  ASSERT(startIndex + nElements <= NUM_JOINTS);
  vector<boost::shared_ptr<JointState<Scalar> > > states;
  for (size_t i = startIndex; i < startIndex + nElements; ++i)
    states.push_back(joints[i]->states[(unsigned)type]);
  return states;
}

template <typename Scalar>
vector<boost::shared_ptr<JointState<Scalar> > > 
KinematicsModule<Scalar>::getChainStates(
  const unsigned& chainIndex, 
  const JointStateType& type)
{
  unsigned start = linkChains[chainIndex]->start;
  unsigned size = linkChains[chainIndex]->size;
  vector<boost::shared_ptr<JointState<Scalar> > > states;
  for (size_t i = start; i < start + size; ++i)
    states.push_back(joints[i]->states[(unsigned)type]);
  return states;
}

template <typename Scalar>
boost::shared_ptr<LinkInfo<Scalar> > 
KinematicsModule<Scalar>::getLink(const unsigned& index)
{
  return links[index];
}

template <typename Scalar>
boost::shared_ptr<LinkChain<Scalar> > 
KinematicsModule<Scalar>::getLinkChain(const unsigned& index)
{
  return linkChains[index];
}

template <typename Scalar>
Matrix<Scalar, 4, 4>  KinematicsModule<Scalar>::getEndEffector(
  const unsigned& chain, const unsigned& index)
{
  return linkChains[chain]->endEffectors[index];
}

template <typename Scalar>
boost::shared_ptr<TorsoState<Scalar> > 
KinematicsModule<Scalar>::getTorsoState() 
{ 
  return torsoState; 
}

template <typename Scalar>
int KinematicsModule<Scalar>::getFootOnGround()
{
  return footOnGround;
}

template <typename Scalar>
Scalar KinematicsModule<Scalar>::getCycleTime()
{
  return cycleTime;
}

template class KinematicsModule<MType>;
