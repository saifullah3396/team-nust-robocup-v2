#pragma once

enum class HeadTargetTypes : unsigned int 
{
  BALL,
  GOAL,
  LANDMARKS,
  COUNT
};
