/**
 * @file MotionModule/include/KinematicsModule/LinkInfo.h
 *
 * This file defines the struct LinkInfo
 * 
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date Jul 22 2018
 */

#pragma once

#include <boost/make_shared.hpp>
#include "Utils/include/MathsUtils.h"

/**
 * @struct LinkInfo
 * @brief A struct that holds information about the link properties
 */
template<typename Scalar>
struct LinkInfo
{
  /**
   * Constructor
   */ 
  LinkInfo() 
  {
  }
  
  //! Link mass
  Scalar mass;
  
  //! Link inertia tensor matrix
  Matrix<Scalar, 3, 3> inertia;
  
  //! Link center of mass vector
  Matrix<Scalar, 4, 1> com;
};
template struct LinkInfo<float>;
template struct LinkInfo<double>;
