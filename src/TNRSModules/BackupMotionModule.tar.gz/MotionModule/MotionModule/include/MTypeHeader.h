/**
 * @file MotionModule/include/MTypeHeader.h
 *
 * This file declares the typedef floatingType
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 04 Feb 2017
 */

#pragma once

typedef double MType;
