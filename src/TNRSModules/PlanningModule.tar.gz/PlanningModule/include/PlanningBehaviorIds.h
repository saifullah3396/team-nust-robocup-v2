/**
 * @file PlanningModule/include/PlanningBehaviorIds.h
 *
 * This file declares the enumeration for all the behavior planning 
 * behaviors and their childs
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 10 Sep 2017
 */

#pragma once

/**
 * Enumeration for all the planning behaviors
 *
 * @enum PBIds
 */
enum class PBIds
: unsigned int {
  STARTUP = 0,
  NAVIGATION,
  ROBOCUP,
  KICK_SEQUENCE,
  EXTERNAL_INTERFACE,
  TEST_SUITE
};

/**
 * Enumeration for all possible types of startup behavior
 *
 * @enum PBStartupTypes
 */
enum class PBStartupTypes
: unsigned int
{
  REQUEST_BEHAVIOR = 0
};

/**
 * Enumeration for all possible types of navigation behaviors
 *
 * @enum PBNavigationTypes
 */
enum class PBNavigationTypes
: unsigned int
{
  GO_TO_TARGET = 0
};

/**
 * Enumeration for all possible types of robocup behavior
 *
 * @enum PBRobocupTypes
 */
enum class PBRobocupTypes
: unsigned int
{
  ROBOCUP_SETUP = 0,
  GOAL_KEEPER,
  DEFENDER,
  ATTACKER,
  PENALTIES
};

/**
 * Enumeration for all possible types of kick sequence behavior
 *
 * @enum PBKickSequenceTypes
 */
enum class PBKickSequenceTypes
: unsigned int
{
  BALL_INTERCEPT = 0,
  FIND_AND_KICK
};

/**
 * Enumeration for all possible types of external interface behaviors
 *
 * @enum PBExternalInterfaceTypes
 */
enum class PBExternalInterfaceTypes
: unsigned int
{
  NIHA_COGNITION = 0,
  USER_REQ_HANDLER
};

/**
 * Enumeration for all possible types of TestSuite behaviors
 *
 * @enum TestSuiteTypes
 */
enum class TestSuiteTypes
: unsigned int
{
  VISION = 0,
  LOCALIZATION,
  MOTION,
  NAVIGATION
};

/**
 * Enumeration for all the goal keeper behavior types.
 *
 * @enum PBGoalKeeperTypes
 */
/*enum class PBGoalKeeperTypes
: unsigned int
{
  PASSIVE_GK,
  COUNT
};*/

/**
 * Enumeration for all defender behavior types.
 *
 * @enum PBDefenderTypes
 */
/*enum class PBDefenderTypes
: unsigned int
{
  MAIN_DEF,
  SUPPORT_DEF,
  COUNT
};*/

/**
 * Enumeration for all attacker behavior types.
 *
 * @enum PBAttackerTypes
 */
/*enum class PBAttackerTypes
: unsigned int
{
  MAIN_ATT,
  SUPPORT_ATT,
  COUNT
};*/
