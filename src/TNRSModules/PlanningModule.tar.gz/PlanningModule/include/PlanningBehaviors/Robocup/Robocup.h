/**
 * @file PlanningModule/PlanningBehaviors/Robocup.h
 *
 * This file declares the class Robocup.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 16 Nov 2017 
 */

#pragma once

#include "BehaviorManager/include/StateMachineMacros.h"
#include "PlanningModule/include/PlanningBehavior.h"
#include "Utils/include/Behaviors/PBConfigs/PBRobocupConfig.h"

enum class KeyFrameGetupTypes : unsigned int;
struct MBHeadControlConfig;

#define BALL_INFO IVAR(BallInfo, PlanningModule::ballInfo)
#define ROBOT_LOCALIZED IVAR(bool, PlanningModule::robotLocalized)
#define ROBOT_POSE_2D IVAR(RobotPose2D<float>, PlanningModule::robotPose2D)
#define TEAM_ROBOTS IVAR(vector<TeamRobot>, PlanningModule::teamRobots)
#define PLAYER_NUMBER IVAR(int, PlanningModule::playerNumber)
#define TEAM_NUMBER IVAR(int, PlanningModule::teamNumber)
#define OBS_OBSTACLES IVAR(ObsObstacles, PlanningModule::obstaclesObs)
#define GAME_DATA OVAR(RoboCupGameControlData, PlanningModule::gameData)
#define WORLD_BALL_INFO OVAR(WorldBallInfo, PlanningModule::worldBallInfo)
#define ROBOCUP_ROLE OVAR(int, PlanningModule::robocupRole)
#define ROBOT_INTENTION OVAR(int, PlanningModule::robotIntention)

#define BALL_INFO_REL(base) IVAR_REL(base, BallInfo, PlanningModule::ballInfo)
#define ROBOT_LOCALIZED_REL(base) IVAR_REL(base, bool, PlanningModule::robotLocalized)
#define ROBOT_POSE_2D_REL(base) IVAR_REL(base, RobotPose2D<float>, PlanningModule::robotPose2D)
#define TEAM_ROBOTS_REL(base) IVAR_REL(base, vector<TeamRobot>, PlanningModule::teamRobots)
#define PLAYER_NUMBER_REL(base) IVAR_REL(base, int, PlanningModule::playerNumber)
#define TEAM_NUMBER_REL(base) IVAR_REL(base, int, PlanningModule::teamNumber)
#define OBS_OBSTACLES_REL(base) IVAR_REL(base, ObsObstacles, PlanningModule::obstaclesObs)
#define GAME_DATA_REL(base) OVAR_REL(base, RoboCupGameControlData, PlanningModule::gameData)
#define WORLD_BALL_INFO_REL(base) OVAR_REL(base, WorldBallInfo, PlanningModule::worldBallInfo)
#define ROBOCUP_ROLE_REL(base) OVAR_REL(base, int, PlanningModule::robocupRole)
#define ROBOT_INTENTION_REL(base) OVAR_REL(base, int, PlanningModule::robotIntention)

class Robocup : public PlanningBehavior
{
public:
  /**
   * Constructor
   *
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   * @param name: Name of this behavior
   */
  Robocup(
    PlanningModule* planningModule,
    const BehaviorConfigPtr& config,
    const string& name = "Robocup") :
    PlanningBehavior(planningModule, config, name),
    inFallRecovery(false),
    readyToGetup(false),
    waitForUnpenalise(false),
    penaliseMotion(false),
    moveTarget(RobotPose2D<float>(100, 100, 100)),
    ballMotionModel(BallMotionModel::DAMPED)
  {
  }

  /**
   * Default destructor for this class.
   */
  virtual
  ~Robocup()
  {
  }
  
  static boost::shared_ptr<Robocup> getType(
    PlanningModule* planningModule, const BehaviorConfigPtr& cfg);

private:
  boost::shared_ptr<PBRobocupConfig> getBehaviorCast();

protected:
  bool isLocalized();
  bool ballFound();
  bool otherRobotOnBall();
  void updateRobotData();
  bool robotIsPenalised();
  bool robotIsFalling();
  bool waitForPenalty();
  void setRobotIntention();
  void setRobotSuggestions();
  void fallenRobotAction();
  void fallRecoveryAction();
  void getupFront();
  void getupBack();
  void getupSit();
  void printGameData();
  void setNavigationConfig(
    const RobotPose2D<float>& target,
    const boost::shared_ptr<MBPostureConfig>& startPosture = boost::shared_ptr<MBPostureConfig>(),
    const boost::shared_ptr<MBPostureConfig>& endPosture = boost::shared_ptr<MBPostureConfig>());
  void resetLocalizer();
  bool getupFromGround(
    const KeyFrameGetupTypes& getupType,
    const StiffnessState& desStiffness,
    const unsigned& mbManagerId);

  //! Whether robot is supposed to get into penalised posture
  bool penaliseMotion;
  bool inFallRecovery;
  bool readyToGetup;
  //! Whether to wait to get unpenalised
  bool waitForUnpenalise;
  RobotPose2D<float> moveTarget;

  enum MBManagerIds {
    MOTION_1,
  };

  enum class BallMotionModel {
    DAMPED,
    FRICTION
  } ballMotionModel;
};

typedef boost::shared_ptr<Robocup> RobocupPtr;
