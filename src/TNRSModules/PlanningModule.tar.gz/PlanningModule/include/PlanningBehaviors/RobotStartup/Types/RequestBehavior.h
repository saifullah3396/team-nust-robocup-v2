/**
 * @file PlanningBehaviors/RobotStartup/Types/RequestBehavior.h
 *
 * This file declares the class RequestBehavior
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#pragma once

#include "BehaviorManager/include/StateMachineMacros.h"
#include "PlanningModule/include/PlanningBehaviors/RobotStartup/RobotStartup.h"

/** 
 * @class RequestBehavior
 * @brief The class for requesting a particular planning behavior at
 *   startup
 */
class RequestBehavior : public RobotStartup
{
public:
  /**
   * Constructor
   * 
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   */
  RequestBehavior(
    PlanningModule* planningModule, 
    const BehaviorConfigPtr& config) :
    RobotStartup(planningModule, config, "RequestBehavior")
  {
    DEFINE_FSM_STATE(RequestBehavior, SetPosture, setPosture)
    DEFINE_FSM_STATE(RequestBehavior, ChestButtonWait, chestButtonWait)
    DEFINE_FSM_STATE(RequestBehavior, StartRequested, startRequested)
    DEFINE_FSM(fsm, RequestBehavior, setPosture)
  }

  /**
   * Destructor
   */
  ~RequestBehavior()
  {
  }
  
  /**
   * Derived from Behavior
   */ 
  void initiate();
  void update();
  void finish();
  void loadExternalConfig();

private:
  /**
   * Returns the config casted as RequestBehaviorConfigPtr
   */
  RequestBehaviorConfigPtr getBehaviorCast();

  /**
   * Sets the start posture from configuration. Sets start posture to 
   * crouch in case of an error.
   * 
   * @throws BehaviorException if the given posture in configuration file
   *   is invalid
   */ 
  void setStartPosture();
  
  //! Posture to reach on startup before requesting the desired behavior
  PostureState startPosture;
protected:
  DECLARE_FSM(fsm, RequestBehavior)
  DECLARE_FSM_STATE(RequestBehavior, SetPosture, setPosture, onRun)
  DECLARE_FSM_STATE(RequestBehavior, ChestButtonWait, chestButtonWait, onRun)
  DECLARE_FSM_STATE(RequestBehavior, StartRequested, startRequested, onRun)
  enum MBManagerIds {
    MOTION_1
  };
};

typedef boost::shared_ptr<RequestBehavior> RequestBehaviorPtr;
