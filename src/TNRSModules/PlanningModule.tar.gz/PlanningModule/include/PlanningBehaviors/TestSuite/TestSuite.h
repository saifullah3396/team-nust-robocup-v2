/**
 * @file PlanningModule/PlanningBehaviors/TestSuite.h
 *
 * This file declares the class TestSuite.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 16 Nov 2017 
 */

#pragma once

#include "PlanningModule/include/PlanningBehavior.h"
#include "Utils/include/Behaviors/PBConfigs/TestSuiteConfig.h"

/** 
 * @class TestSuite
 * @brief A base class for defining test sequences 
 */
class TestSuite : public PlanningBehavior
{

public:
  /**
   * Constructor
   * 
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   * @param name: Name of this behavior
   */
  TestSuite(
    PlanningModule* planningModule, 
    const BehaviorConfigPtr& config,
    const string& name = "TestSuite") :
    PlanningBehavior(planningModule, config, name)
  {
  }

  /**
   * Destructor
   */
  ~TestSuite()
  {
  }

  /**
   * Returns its own child based on the given type
   * 
   * @param planningModule: Pointer to base planning module
   * @param cfg: Config of the requested behavior
   * 
   * @return BehaviorConfigPtr
   */
  static boost::shared_ptr<TestSuite> getType(
    PlanningModule* planningModule, const BehaviorConfigPtr& cfg);
    
  virtual void loadExternalConfig() {}
private:
  /**
   * Returns the cast of config as TestSuiteConfigPtr
   */ 
  TestSuiteConfigPtr getBehaviorCast();
};

typedef boost::shared_ptr<TestSuite> TestSuitePtr;
