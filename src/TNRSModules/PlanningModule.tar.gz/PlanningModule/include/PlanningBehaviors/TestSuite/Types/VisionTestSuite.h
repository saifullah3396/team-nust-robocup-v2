/**
 * @file PlanningBehaviors/TestSuite/Types/VisionTestSuite.h
 *
 * This file declares the class VisionTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#pragma once

#include "PlanningModule/include/PlanningBehaviors/TestSuite/TestSuite.h"

/** 
 * @class VisionTestSuite
 * @brief The class for testing vision module functionality
 */
class VisionTestSuite : public TestSuite
{
public:
  /**
   * Constructor
   * 
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   */
  VisionTestSuite(
    PlanningModule* planningModule, 
    const BehaviorConfigPtr& config) :
    TestSuite(planningModule, config, "VisionTestSuite"),
    behaviorState(testSegmentation)
  {
  }

  /**
   * Destructor
   */
  ~VisionTestSuite()
  {
  }
  
  /**
   * Derived from Behavior
   */ 
  void initiate();
  void update();
  void finish();
  
private:
  /**
   * Returns the config casted as VisionTestSuiteConfigPtr
   */ 
  VisionTestSuiteConfigPtr getBehaviorCast();

  void testSegmentationAction();
  void testFieldExtractionAction();
  void testGoalExtractionAction();
  void testBallExtractionAction();
  void testRobotExtractionAction();
  void testLinesExtractionAction();
  void testAllAction();

  unsigned behaviorState;
  enum BehaviorState {
    testSegmentation,
    testFieldExtraction,
    testGoalExtraction,
    testBallExtraction,
    testRobotExtraction,
    testLinesExtraction,
    testAll
  };
};

typedef boost::shared_ptr<VisionTestSuite> VisionTestSuitePtr;
