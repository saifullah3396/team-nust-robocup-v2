/**
 * @file PlanningBehaviors/TestSuite/Types/MotionTestSuite.h
 *
 * This file declares the class MotionTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#pragma once

#include "PlanningModule/include/PlanningBehaviors/TestSuite/TestSuite.h"

/**
 * @class MotionTestSuite
 * @brief The class for testing Motion module functionality
 */
class MotionTestSuite : public TestSuite
{
public:
  /**
   * Constructor
   *
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   */
  MotionTestSuite(
    PlanningModule* planningModule,
    const BehaviorConfigPtr& config) :
    TestSuite(planningModule, config, "MotionTestSuite")
  {
  }

  /**
   * Destructor
   */
  ~MotionTestSuite()
  {
  }

  /**
   * Derived from Behavior
   */
  void initiate();
  void update();
  void finish();

private:
  /**
   * Returns the config casted as MotionTestSuiteConfigPtr
   */
  MotionTestSuiteConfigPtr getBehaviorCast();

  enum MBManagerIds {
    MOTION_1
  };
};

typedef boost::shared_ptr<MotionTestSuite> MotionTestSuitePtr;
