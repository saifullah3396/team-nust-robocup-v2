/**
 * @file PlanningBehaviors/TestSuite/Types/NavigationTestSuite.h
 *
 * This file declares the class NavigationTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#pragma once

#include "BehaviorManager/include/StateMachineMacros.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/TestSuite.h"

/**
 * @class NavigationTestSuite
 * @brief The class for testing localization module functionality
 */
class NavigationTestSuite : public TestSuite
{
public:
  /**
   * Constructor
   *
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   */
  NavigationTestSuite(
    PlanningModule* planningModule,
    const BehaviorConfigPtr& config) :
    TestSuite(planningModule, config, "NavigationTestSuite")
  {
    DEFINE_FSM_STATE(NavigationTestSuite, GoToTarget, goToTarget)
    DEFINE_FSM_STATE(NavigationTestSuite, GoalChangedReplan, goalChangedReplan)
    DEFINE_FSM_STATE(NavigationTestSuite, InvalidPathReplan, invalidPathReplan)
    DEFINE_FSM(fsm, NavigationTestSuite, goToTarget)
  }

  /**
   * Destructor
   */
  ~NavigationTestSuite()
  {
  }

  /**
   * Derived from Behavior
   */
  void initiate();
  void update();
  void finish();

protected:
  /**
   * Returns the config casted as NavigationTestSuiteConfigPtr
   */
  NavigationTestSuiteConfigPtr getBehaviorCast();

  DECLARE_FSM(fsm, NavigationTestSuite)
  DECLARE_FSM_STATE(NavigationTestSuite, GoToTarget, goToTarget, onStart, onRun,)
  DECLARE_FSM_STATE(NavigationTestSuite, GoalChangedReplan, goalChangedReplan, onStart, onRun,)
  DECLARE_FSM_STATE(NavigationTestSuite, InvalidPathReplan, invalidPathReplan, onStart, onRun,)

  enum MBManagerIds {
    MOTION_1
  };
};

typedef boost::shared_ptr<NavigationTestSuite> NavigationTestSuitePtr;
