/**
 * @file PlanningBehaviors/TestSuite/Types/LocalizationTestSuite.h
 *
 * This file declares the class LocalizationTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#pragma once

#include "PlanningModule/include/PlanningBehaviors/TestSuite/TestSuite.h"

/**
 * @class LocalizationTestSuite
 * @brief The class for testing localization module functionality
 */
class LocalizationTestSuite : public TestSuite
{
public:
  /**
   * Constructor
   *
   * @param planningModule: pointer to parent planning module
   * @param config: Configuration of this behavior
   */
  LocalizationTestSuite(
    PlanningModule* planningModule,
    const BehaviorConfigPtr& config) :
    TestSuite(planningModule, config, "LocalizationTestSuite"),
    behaviorState(testSideLineLocalization)
  {
  }

  /**
   * Destructor
   */
  ~LocalizationTestSuite()
  {
  }

  /**
   * Derived from Behavior
   */
  void initiate();
  void update();
  void finish();

private:
  /**
   * Returns the config casted as LocalizationTestSuiteConfigPtr
   */
  LocalizationTestSuiteConfigPtr getBehaviorCast();

  /**
   * @brief testSideLineLocalizationAction Tests localization for robot standing
   *   on sidelines
   */
  void testSideLineLocalizationAction();

  /**
   * @brief testLocalizationStandingAction Tests localization for robot standing anywhere
   *   without information that robot is on sidelines
   */
  void testLocalizationStandingAction();

  /**
   * @brief testLocalizationPredictionAction Tests the prediction step of localization
   */
  void testLocalizationPredictionAction();

  /**
   * @brief testLocalizationWithMovementAction Tests localization for robot starting from
   *   sidelines and moving to a goal spot
   */
  void testLocalizationWithMovementAction();

  unsigned behaviorState;
  enum BehaviorState {
    testSideLineLocalization,
    testLocalizationStanding,
    testLocalizationPrediction,
    testLocalizationWithMovement
  };

  enum MBManagerIds {
    MOTION_1
  };
};

typedef boost::shared_ptr<LocalizationTestSuite> LocalizationTestSuitePtr;
