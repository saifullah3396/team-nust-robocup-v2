/**
 * @file PlanningModule/PlanningBehavior.cpp
 *
 * This file implements the base class for all types of planning behaviors.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 12 Sep 2017
 */

#include "PlanningModule/include/PlanningBehavior.h"
#include "Utils/include/PathPlanner/PathPlanner.h"
#include "SBModule/include/SBRequest.h"
#include "MotionModule/include/MotionRequest.h"
#include "Utils/include/Behaviors/MBConfigs/MBPostureConfig.h"
#include "Utils/include/Behaviors/SBConfigs/SBStiffnessConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBConfig.h"
#include "Utils/include/MathsUtils.h"

using namespace PathPlannerSpace;
typedef map<unsigned, BehaviorInfo> BehaviorInfoMap;
void PlanningBehavior::updatePostureAndStiffness()
{
  posture = IVAR(PostureState, PlanningModule::postureState);
  stiffness = IVAR(StiffnessState, PlanningModule::stiffnessState);
}

bool PlanningBehavior::setPostureAndStiffness(
  const PostureState& desPosture, 
  const StiffnessState& desStiffness,
  const unsigned& mbManagerId,
  const float& postureTime)
{
  if (posture == desPosture && 
      stiffness == desStiffness) 
  {
    return true;
  } else if (stiffness != desStiffness) {
    if (!sbInProgress()) {
      auto sConfig =
        boost::make_shared <SBStiffnessConfig> (
          desStiffness);
      setupSBRequest(sConfig);
    }
    return false;
  } else if (posture != desPosture) {
    if (!mbInProgress()) {
      auto pConfig = 
        boost::make_shared<MBPostureConfig>(
          desPosture, postureTime);
      setupMBRequest(mbManagerId, pConfig);
    }
    return false;
  }
}

void PlanningBehavior::killStaticBehavior() {
  auto request = boost::make_shared<KillStaticBehavior>();
  BaseModule::publishModuleRequest(request);
}

void PlanningBehavior::killMotionBehavior(const unsigned& mbManagerId) {
  int id = mbManagerId + mbIdOffset;
  auto request = boost::make_shared<KillMotionBehavior>(id);
  BaseModule::publishModuleRequest(request);
}

void PlanningBehavior::killAllMotionBehaviors() {
  for (size_t i = 0; i < mbManagerIds.size(); ++i) {
    auto request = boost::make_shared<KillMotionBehavior>(mbManagerIds[i]);
    BaseModule::publishModuleRequest(request);
  }
}

bool PlanningBehavior::matchLastMotionRequest(
  const unsigned& mbId)
{
  return lastMBConfig &&
         lastMBConfig->id == mbId;
}

bool PlanningBehavior::matchLastMotionRequest(
  const unsigned& mbId, const unsigned& mbType)
{
  return
    lastMBConfig &&
    lastMBConfig->id == mbId &&
    lastMBConfig->type == mbType;
}

bool PlanningBehavior::matchLastStaticRequest(
  const unsigned& sbId, const unsigned& sbType)
{
  return
    lastSBConfig &&
    lastSBConfig->id == sbId &&
    lastSBConfig->type == sbType;
}


void PlanningBehavior::setupSBRequest(const SBConfigPtr& config)
{
  auto rsb = boost::make_shared<RequestStaticBehavior>(config);
  lastStaticRequest = rsb;
  BaseModule::publishModuleRequest(rsb);
  sRequestTime = pModule->getModuleTime();
}

void PlanningBehavior::setupMBRequest(
  const unsigned& mbManagerId, const MBConfigPtr& config)
{
  int id = mbManagerId + mbIdOffset;
  auto rmb = boost::make_shared<RequestMotionBehavior>(id, config);
  lastMotionRequest = rmb;
  BaseModule::publishModuleRequest(rmb);
  mRequestTime = pModule->getModuleTime();
  if (std::find(mbManagerIds.begin(), mbManagerIds.end(), id) == mbManagerIds.end()) {
    mbManagerIds.push_back(id);
  }
}

bool PlanningBehavior::sbInProgress()
{
  return behaviorInProgress(
    IVAR(BehaviorInfo, PlanningModule::sBehaviorInfo));
}

bool PlanningBehavior::mbInProgress()
{
  auto& mbInfo = IVAR(BehaviorInfoMap, PlanningModule::mBehaviorInfo);
  for (size_t i = 0; i < mbManagerIds.size(); ++i)
  {
    if (mbInfo.find(mbManagerIds[i]) != mbInfo.end()) {
      if (behaviorInProgress(mbInfo[mbManagerIds[i]]))
        return true;
    }
  }
  return false;
}

bool PlanningBehavior::behaviorInProgress(const BehaviorInfo& info)
{
  if(info.isInitiated())
  {
    if (info.isRunning()) 
      return true;
  }
  return false;
}

bool PlanningBehavior::requestInProgress()
{
  bool inProgress = false;
  auto& sbInfo = IVAR(BehaviorInfo, PlanningModule::sBehaviorInfo);
  if(requestInProgress(lastStaticRequest, lastSBConfig, sbInfo, sRequestTime))
    inProgress = true;
  auto& mbInfo = IVAR(BehaviorInfoMap, PlanningModule::mBehaviorInfo);
  for (size_t i = 0; i < mbManagerIds.size(); ++i)
  {
    if (mbInfo.find(mbManagerIds[i]) == mbInfo.end()) {
      mbManagerIds.erase(mbManagerIds.begin()+i);
    } else {
      if (i == mbManagerIds.size()-1) {
        if(requestInProgress(lastMotionRequest, lastMBConfig, mbInfo[mbManagerIds[i]], mRequestTime))
          inProgress = true;
      }
    }
  }
  return inProgress;
}

bool PlanningBehavior::requestInProgress(
  BehaviorRequestPtr& req,
  BehaviorConfigPtr& acceptedBehavior,
  const BehaviorInfo& feedback,
  const float& requestStartTime)
{
  if (!req)
    return false;
    
  if (
    pModule->getModuleTime() - requestStartTime >
    maxRequestTimeout)
  {
    req.reset();
    return false;
  }
    
  if (req->isReceived()) {
    //! Request received on the other end
    if (req->getAccepted()) {
      //cout << "Accepted request" << endl;
      if (feedback.isInitiated() && 
          req->getReqConfig()->id == feedback.getConfig()->id) 
      {
        //cout << "Behavior initiated on request" << endl;
        acceptedBehavior = feedback.getConfig();
        req.reset();
        return false;
      }
      return true;
    } else {
      acceptedBehavior.reset();
      req.reset();
    }
    return false;
  }
  return true;
}

PathPlannerSpace::PathPlannerPtr PlanningBehavior::getPathPlanner()
{
  return pModule->getPathPlanner();
}

