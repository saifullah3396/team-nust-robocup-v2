/**
 * @file PlanningModule/PlanningBehaviors/RobocupSetupSetup.h
 *
 * This file implements the class RobocupSetupSetup.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 27 Jul 2018
 */

#include "PlanningModule/include/PlanningBehaviors/Robocup/Types/RobocupSetup.h"
#include "PlanningModule/include/PlanningBehaviors/NavigationBehavior/Types/GoToTarget.h"
#include "Utils/include/Behaviors/MBConfigs/MBPostureConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBHeadControlConfig.h"
#include "Utils/include/Behaviors/SBConfigs/SBWDConfig.h"
#include "Utils/include/RobocupRole.h"
#include "Utils/include/TeamPositions.h"
#include "VisionModule/include/VisionRequest.h"
#include "LocalizationModule/include/LocalizationRequest.h"

boost::shared_ptr<RobocupSetupConfig> RobocupSetup::getBehaviorCast()
{
  return boost::static_pointer_cast <RobocupSetupConfig> (config);
}

void RobocupSetup::initiate()
{
  LOG_INFO("RobocupSetup.initiate() called...");
  //! Enable all feature extraction modules
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::BALL));
  inBehavior = true;
}

void RobocupSetup::update()
{
  LOG_INFO("In RobocupSetup.update()...");
  // Update required input data
  updateRobotData(); /// Tested
  //printGameData();
  if(waitForPenalty()) { /// Tested
    LOG_INFO("In waitForPenalty()...");
    // Robot is penalised so turn off vision and localization modules
    BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(false));
    BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(false));
    // Localization has to be resetted as well
    OVAR(bool, PlanningModule::localizeWithLastKnown) = false;
    return;
  }

  // Check if the robot is fallen or about to fall
  if (!inFallRecovery && robotIsFalling()) { /// Tested
    LOG_INFO("In robotIsFalling()...");
    // Get ready to recover since the robot has fallen
    fallenRobotAction(); /// Tested
  }

  // Stop if a motion or static behavior request is in progress
  if (requestInProgress()) return; /// Tested

  // Just for debugging individual behaviors bypassing this behavior
  //behaviorState = gameplaySequence;
  // If the robot is recovering from a fall
  if (inFallRecovery) { /// Tested
    LOG_INFO("In fallRecoveryAction()...");
    // Perform fall recovery action
    fallRecoveryAction(); /// Tested
  } else {
    // Robot is standing and able to perform actions
    if (behaviorState == startup) {
      LOG_INFO("BehaviorState: startup");
      startupAction(); /// Tested
    } else if (behaviorState == robocupCfg) {
      LOG_INFO("BehaviorState: robocupCfg");
      cfgHandlingAction();
    } else if (behaviorState == readySequence) {
      LOG_INFO("BehaviorState: readySequence");
      readySequenceAction();
    } else if (behaviorState == getInPosition) {
      LOG_INFO("BehaviorState: getInPosition");
      getInPositionAction();
    }else if (behaviorState == setSequence) {
      LOG_INFO("BehaviorState: setSequence");
      setSequenceAction();
    } else if (behaviorState == gameplaySequence) {
      LOG_INFO("BehaviorState: gameplaySequence");
      gameplaySequenceAction();
    }
  }
}

void RobocupSetup::finish()
{
  LOG_INFO("RobocupSetup::finish() called...")
  inBehavior = false;
}

void RobocupSetup::startupAction()
{
  if (setPostureAndStiffness(PostureState::STAND, StiffnessState::ROBOCUP, MOTION_1))
    behaviorState = robocupCfg;
}

void RobocupSetup::cfgHandlingAction()
{
  auto& gameData = OVAR(RoboCupGameControlData, PlanningModule::gameData);
  ///Example states for checking penalty shootout behavior
  ///gameData.state = STATE_SET;
  ///gameData.secondaryState = STATE2_PENALTYSHOOT;
  ///gameData.kickOffTeam = 30;
  ///Example states for checking gameplay behavior
  gameData.state = STATE_READY;
  gameData.secondaryState = STATE2_NORMAL;
  gameData.kickOffTeam = 30;  
  if ((unsigned) gameData.state == STATE_INITIAL) {
    LOG_INFO("GameCtrlState: STATE_INITIAL")
  } else if ((unsigned) gameData.state == STATE_READY) {
    LOG_INFO("GameCtrlState: STATE_READY")
    OVAR(bool, PlanningModule::robotOnSideLine) = true;
    BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
    BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(true));
    BaseModule::publishModuleRequest(boost::make_shared<ResetLocalizer>());
    behaviorState = readySequence;
  } else if ((unsigned) gameData.state == STATE_SET) {
    LOG_INFO("GameCtrlState: STATE_SET")
    auto secState = (unsigned) gameData.secondaryState;
    auto kickOffTeam = (unsigned) gameData.kickOffTeam;
    auto& ourTeamNumber = IVAR(int, PlanningModule::teamNumber);
    if (secState == STATE2_PENALTYSHOOT) {
      LOG_INFO("GameCtrlState: STATE2_PENALTYSHOOT")
      if (kickOffTeam == ourTeamNumber) {
        LOG_INFO("GameState: PENALTY_STRIKER")
         // auto planConfig =
         //   boost::make_shared < PBPenaltiesConfig > (PBPenaltiesTypes::PENALTY_STRIKER);
         // setupChildBehaviorRequest(planConfig);
      } else {
        LOG_INFO("GameState: PENALTY_GOALKEEPER")
         //auto planConfig =
         //   boost::make_shared < PBPenaltiesConfig > (PBPenaltiesTypes::PENALTY_GOALKEEPER);
         // setupChildBehaviorRequest(planConfig);
      }
    } else if (secState == STATE2_NORMAL) {
      behaviorState = setSequence;
    }
  }
}

void RobocupSetup::readySequenceAction()
{
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (!localized) {
    LOG_INFO("Trying to localize...")
    if (!mbInProgress()) {
      LOG_INFO("Setting HeadTargetSearch motion config to find HeadTargetTypes::GOAL...")
      auto mConfig =
        boost::make_shared <HeadTargetSearchConfig> (HeadTargetTypes::GOAL);
      // Robot is on sidelines with other robots so keep scan range minimum.
      mConfig->scanMaxYaw = 75.0 * M_PI / 180;
      setupMBRequest(MOTION_1, mConfig);
    }
  } else {
    LOG_INFO("Robot localized...")
    bool teamRobotOverlap = false;
    auto& robotState = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
    auto& teamRobots = IVAR(vector<TeamRobot>, PlanningModule::teamRobots);
    unsigned teamRobotsLost = 0;
    LOG_INFO("RobotPosition: " << robotState.mat);
    for (int i = 0; i < teamRobots.size(); ++i) {
      if (i == (int) IVAR(unsigned, PlanningModule::playerNumber) - 1) {
        //! This robot itself
        continue;
      }
      // Wait for team to get localized
      if (teamRobots[i].positionConfidence < 50) {
        ++teamRobotsLost;
        continue;
      }
      float dist = (robotState.mat - teamRobots[i].pose.mat).norm();
      // Check if another team member has overlapping position 
      if (dist < 0.2) {
        LOG_INFO("Position overlapping with team member. Relocalizing...")
        resetLocalizer();
        teamRobotOverlap = true;
      }
    }

    if (!teamRobotOverlap && teamRobotsLost >= 1) {
      auto& gameData = OVAR(RoboCupGameControlData, PlanningModule::gameData);
      auto kickOffTeam = (unsigned) gameData.kickOffTeam;
      auto& ourTeamNumber = IVAR(int, PlanningModule::teamNumber);
      int robocupRole = (int) RobocupRole::GOALKEEPER;
      double smallestDist = 1e3;
      if (kickOffTeam == ourTeamNumber) {
        for (size_t i = (int) RobocupRole::GOALKEEPER;
          i < (int) RobocupRole::COUNT; ++i) {
          double dist = (robotState.mat - sidePositionsAtt[i].mat).norm();
          if (dist < smallestDist) {
            smallestDist = dist;
            robocupRole = i;
          }
        }
      } else {
        for (size_t i = (int) RobocupRole::GOALKEEPER;
          i < (int) RobocupRole::COUNT; ++i) {
          double dist = (robotState.mat - sidePositionsDef[i].mat).norm();
          if (dist < smallestDist) {
            smallestDist = dist;
            robocupRole = i;
          }
        }
      }
      // Chnage this varaible to unsigned or RobocupRole
      OVAR(int, PlanningModule::robocupRole) = robocupRole;
      LOG_INFO("Robocup role: " << robocupRole);
      setRobotIntention();
      OVAR(bool, PlanningModule::robotOnSideLine) = false;
      OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
      this->killMotionBehavior(MOTION_1);
      behaviorState = getInPosition;
    }
  }
}

void RobocupSetup::getInPositionAction()
{
  auto& gameData = OVAR(RoboCupGameControlData, PlanningModule::gameData);
  // If the ready sequence time is up and game controller sent set 
  // command
  if ((unsigned) gameData.state == STATE_SET) {
    killMotionBehavior(MOTION_1);
    behaviorState = setSequence;
  } else {
    // Else keep trying to get in correct position
    auto& localized = IVAR(bool, PlanningModule::robotLocalized);
    if (!localized) {
      cout << "Robot not localized. Trying to scan and get localized...\n";
      OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
      if (!mbInProgress()) {
        auto mConfig =
          boost::make_shared <HeadTargetSearchConfig> (
            HeadTargetTypes::GOAL);
        // If robot is on Sidelines alone. Better to find T or L corners too. 
        if (OVAR(bool, PlanningModule::robotOnSideLine)) mConfig->scanMaxYaw =
          75.0 * M_PI / 180;
        else // If robot is in the field.
          mConfig->scanMaxYaw = 75.0 * M_PI / 180;
        setupMBRequest(MOTION_1, mConfig);
      }
    } else {
      cout << "robot localized" << endl;
      // After the walk finishes reset the localizer to find its
      // position estimate from landmarks
      if (!mbInProgress()) {
        cout << "Setting walk with target...\n";
        RobotPose2D<float> target;
        if (setSequenceFinished) {
          auto& role = OVAR(int, PlanningModule::robocupRole);
          if (role == (int)RobocupRole::GOALKEEPER) {
            target = positionsInGame[0];
          } else if (role == (int)RobocupRole::DEFENDER || role == (int)RobocupRole::DEFENSE_SUPPORT) {
            auto& robotState =
              IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
            double smallestDist = 1e3;
            for (int i = 1; i < 3; ++i) {
              double dist = (robotState.mat - positionsInGame[i].mat).norm();
              if (dist < smallestDist) {
                smallestDist = dist;
                target = positionsInGame[i];
              }
            }
          } else if (role == (int)RobocupRole::OFFENSE_SUPPORT || role == (int)RobocupRole::ATTACKER) {
            auto& robotState =
              IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
            double smallestDist = 1e3;
            for (int i = 3; i < 5; ++i) {
              double dist = (robotState.mat - positionsInGame[i].mat).norm();
              if (dist < smallestDist) {
                smallestDist = dist;
                target = positionsInGame[i];
              }
            }
          }
          setNavigationConfig(target);
          behaviorState = goingToPosition;
          OVAR(bool, PlanningModule::robotOnSideLine) = false;
        } else {
          auto kickOffTeam = (unsigned) gameData.kickOffTeam;
          auto& ourTeamNumber = IVAR(int, PlanningModule::teamNumber);
          if (kickOffTeam == ourTeamNumber) { // Attack team
            target = startPositionsAtt[OVAR(int, PlanningModule::robocupRole)];
          } else {
            target = startPositionsDef[OVAR(int, PlanningModule::robocupRole)];
          }
          cout << "Start position: " << target.mat << endl;
          //if (this->lastChildCfg &&
          //    this->lastChildCfg->id == (unsigned)PBIds::NAVIGATION)
          //{ // If last child running was navigation behavior
          setNavigationConfig(target);
          behaviorState = goingToPosition;
        }
      }
    }
  }
}

void RobocupSetup::goingToPositionAction()
{
  auto& robotState =
    IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
  if ((moveTarget.mat - robotState.mat).norm() < 5e-3) {
    if (setSequenceFinished)
      behaviorState = gameplaySequence;
    else
      behaviorState = setSequence;
  } else {
    if (!this->getChild()) {
      behaviorState = getInPosition;
    }
  }
}

void
RobocupSetup::setSequenceAction()
{
  cout << "Executing RobocupSetup.setSequenceAction()...\n";
  if (IVAR(PostureState, PlanningModule::postureState) != PostureState::STAND) {
    if (!mbInProgress()) {
      auto pConfig = 
        boost::make_shared<MBPostureConfig>(PostureState::STAND, 2.f);
      setupMBRequest(MOTION_1, pConfig);
    }
    //OVAR(bool, PlanningModule::runVisionModule) = false;
    //OVAR(bool, PlanningModule::runLocalizationModule) = false;
  } else {
    if (!IVAR(bool, PlanningModule::whistleDetected)) {
      if (!sbInProgress()) {
        auto sConfig = boost::make_shared<SBWDConfig>();
        setupSBRequest(sConfig);
      }
    } else {
      //OVAR(bool, PlanningModule::runVisionModule) = true;
      //OVAR(bool, PlanningModule::runLocalizationModule) = true;
      //OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
      behaviorState = gameplaySequence;
      setSequenceFinished = true;
    }
  }
}

void
RobocupSetup::gameplaySequenceAction()
{
  // Just to check individual behavior set manually.
  auto& role = OVAR(int, PlanningModule::robocupRole);
  role = (int)RobocupRole::GOALKEEPER;
  if (role == (int)RobocupRole::GOALKEEPER) {
    //auto planConfig = boost::make_shared<GoalKeeperConfig>();
    //setupChildBehaviorRequest(planConfig);
  } else if (role == (int)RobocupRole::DEFENDER) {
    //defenderAction();
  } else if (role == (int)RobocupRole::DEFENSE_SUPPORT) {
    //defSupportAction();
  } else if (role == (int)RobocupRole::OFFENSE_SUPPORT) {
    //offSupportAction();
  } else if (role == (int)RobocupRole::ATTACKER) {
    //attackerAction();
  }
}
