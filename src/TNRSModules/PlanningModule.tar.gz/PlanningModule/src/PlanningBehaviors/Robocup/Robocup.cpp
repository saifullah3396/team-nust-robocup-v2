/**
 * @file PlanningModule/PlanningBehaviors/Robocup.h
 *
 * This file implements the class Robocup.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 16 Nov 2017
 */

#include <boost/make_shared.hpp>
#include "LocalizationModule/include/LocalizationRequest.h"
#include "PlanningModule/include/PlanningBehaviors/Robocup/Robocup.h"
#include "PlanningModule/include/PlanningBehaviors/Robocup/Types/RobocupSetup.h"
#include "PlanningModule/include/PlanningBehaviors/Robocup/Types/GoalKeeper.h"
#include "PlanningModule/include/PlanningBehaviors/Robocup/Types/Defender.h"
#include "PlanningModule/include/PlanningBehaviors/Robocup/Types/Attacker.h"
#include "Utils/include/Behaviors/MBConfigs/MBGetupConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBHeadControlConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBKickConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBMovementConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBPostureConfig.h"
#include "Utils/include/Behaviors/PBConfigs/PBNavigationConfig.h"
#include "Utils/include/Behaviors/SBConfigs/SBStiffnessConfig.h"
#include "Utils/include/TeamPositions.h"
#include "Utils/include/TeamPositions.h"
#include "Utils/include/VisionUtils.h"
#include "VisionModule/include/VisionRequest.h"

boost::shared_ptr<Robocup> Robocup::getType(
  PlanningModule* planningModule, const BehaviorConfigPtr& cfg)
{ 
  Robocup* r;
  switch (cfg->type) {
    case (unsigned) PBRobocupTypes::ROBOCUP_SETUP:
      r = new RobocupSetup(planningModule, cfg); break;
    case (unsigned) PBRobocupTypes::GOAL_KEEPER:
      r = new GoalKeeper(planningModule, cfg); break;
    case (unsigned) PBRobocupTypes::DEFENDER:
      r = new Defender(planningModule, cfg); break;
    case (unsigned) PBRobocupTypes::ATTACKER:
      r = new Attacker(planningModule, cfg); break;
  }
  return boost::shared_ptr<Robocup>(r);
}

boost::shared_ptr<PBRobocupConfig> Robocup::getBehaviorCast()
{
  return boost::static_pointer_cast <PBRobocupConfig> (config);
}

bool Robocup::isLocalized()
{
  return ROBOT_LOCALIZED;
}

bool Robocup::ballFound()
{
  return WORLD_BALL_INFO.found && BALL_INFO.found;
}

bool Robocup::otherRobotOnBall()
{
  // Find if any other teammate is following ball right now and
  // is also closer.
  auto ballToRobot = norm(BALL_INFO.posRel);
  for (int i = 0; i < TEAM_ROBOTS.size(); ++i) {
    // If any robot is intending to play the ball
    if (TEAM_ROBOTS[i].intention == 3) {
      float dist = MathsUtils::dist(
        WORLD_BALL_INFO.posWorld.x,
        WORLD_BALL_INFO.posWorld.y,
        TEAM_ROBOTS[i].pose.getX(),
        TEAM_ROBOTS[i].pose.getY());
      // If that robot is closer to ball than this robot
      if (dist < ballToRobot) {
        return true;
      }
    }
  }
  return false;
}

void Robocup::updateRobotData()
{
  updatePostureAndStiffness();
  setRobotIntention();
}

void Robocup::setRobotSuggestions()
{
  /*auto& teamRobots = IVAR(vector<TeamRobot>, PlanningModule::teamRobots);
   for (int i = 0; i < teamRobots.size(); ++i) {
   // Wait for team to get localized
   if (teamRobots[i].intention == ) { 
   ++teamRobotsLost;
   continue;
   }
   float dist = 
   MathsUtils::dist(
   robotState.x, robotState.y,
   teamRobots[i].pose.x, teamRobots[i].pose.y
   );
   // Check if another team member has overlapping position 
   if (dist < 0.2) {
   resetLocalizer();
   teamRobotOverlap = true;
   }
   }*/
}

bool Robocup::robotIsPenalised()
{
  TeamInfo& team = GAME_DATA.teams[(int)(GAME_DATA.teams[0].teamNumber == TEAM_NUMBER ? 0 : 1)];
  return (bool) team.players[PLAYER_NUMBER-1].penalty;
}

bool Robocup::waitForPenalty()
{
  if (!waitForUnpenalise) {
    if (!penaliseMotion) {
      if (robotIsPenalised()) {
        // Start penalty motion
        penaliseMotion = true;
        // Kill all motion and static behaviors
        killAllMotionBehaviors();
        killStaticBehavior();
        return true;
      } else {
        return false;
      }
    } else {
      // Set pose to stand due to penalty
      if (this->setPostureAndStiffness(PostureState::STAND, StiffnessState::ROBOCUP, MOTION_1)) {
        penaliseMotion = false;
        waitForUnpenalise = true;
      }
      return true;
    }
  } else {
    // Wait until penalty has finished
    if (!robotIsPenalised()) {
      waitForUnpenalise = false;
      return false;
    } else {
      return true;
    }
  }
}

bool Robocup::robotIsFalling()
{
  return
    IVAR(bool, PlanningModule::robotFallen) ||
    posture == PostureState::FALLING_FRONT ||
    posture == PostureState::FALLING_BACK;
}

void Robocup::fallenRobotAction()
{
  LOG_INFO("Executing Robocup.fallenRobotAction()...")
  this->killChild();
  this->killAllMotionBehaviors();
  this->killStaticBehavior();
  // Turn off perception modules and reset when robot is stable again
  BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(false));
  BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(false));
  inFallRecovery = true;
}

void Robocup::fallRecoveryAction()
{
  cout << "Executing Robocup.inFallRecoveryAction()..." << endl;
  bool& fallen = IVAR(bool, PlanningModule::robotFallen);
  if (fallen) {
    cout << "fallen: " << endl;
    cout << "posture: " << (int)posture << endl;
    if (posture == PostureState::FALL_FRONT) {
      getupFromGround(KeyFrameGetupTypes::FRONT, StiffnessState::GETUP, MOTION_1);
    } else if (posture == PostureState::FALL_BACK) {
      getupFromGround(KeyFrameGetupTypes::BACK, StiffnessState::GETUP, MOTION_1);
    } else if (posture == PostureState::FALL_SIT) {
      getupFromGround(KeyFrameGetupTypes::SIT, StiffnessState::GETUP, MOTION_1);
    }
  } else {
    cout << "not fallen..." << endl;
    cout << "posture: " << (int)posture << endl;
    float postureTime = 2.f;
    if (posture == PostureState::FALLING_FRONT) {
      postureTime = 0.5f;
    } else if (posture == PostureState::FALLING_BACK) {
      postureTime = 0.5f;
    }
    if (posture != PostureState::STAND) {
      cout << "posture != stand" << endl;
      if (!mbInProgress()) {
        cout << "Setting posture to stand at to help robot not fall." << endl;
        auto pConfig = 
          boost::make_shared<MBPostureConfig>(
            PostureState::STAND, postureTime);
        setupMBRequest(MOTION_1, pConfig);
      }
    } else {
      BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
      BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(true));
      OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
      inFallRecovery = false;
    }
  }
}

void Robocup::setRobotIntention()
{
  auto& role = OVAR(int, PlanningModule::robocupRole);
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (localized || role == -1) {
    if (role == (int)RobocupRole::GOALKEEPER)
    OVAR(int, PlanningModule::robotIntention) = 1;
    else if (role == (int)RobocupRole::DEFENDER || role == (int)RobocupRole::DEFENSE_SUPPORT)
    OVAR(int, PlanningModule::robotIntention) = 2;
    else if (role == (int)RobocupRole::OFFENSE_SUPPORT || role == (int)RobocupRole::ATTACKER)
    OVAR(int, PlanningModule::robotIntention) = 3;
  } else {
    OVAR(int, PlanningModule::robotIntention) = 4; // robot lost
  }
}

bool Robocup::getupFromGround(
  const KeyFrameGetupTypes& getupType,
  const StiffnessState& desStiffness,
  const unsigned& mbManagerId)
{
  if (stiffness != desStiffness) {
    if (!sbInProgress()) {
      auto sConfig =
        boost::make_shared <SBStiffnessConfig> (desStiffness);
      setupSBRequest(sConfig);
    }
    return false;
  } else {
    if (!mbInProgress()) {
      auto getupConfig =
        boost::make_shared<KFMGetupConfig>(getupType);
      setupMBRequest(mbManagerId, getupConfig);
      return true;
    }
    return false;
  }
}

void Robocup::setNavigationConfig(const RobotPose2D<float>& target,
  const boost::shared_ptr<MBPostureConfig>& startPosture,
  const boost::shared_ptr<MBPostureConfig>& endPosture)
{
  //if (this->getChild())
  //  return;
  auto config =
    boost::make_shared<GoToTargetConfig>();
  config->goal = target;
  config->reachClosest = true;
  if (startPosture)
    config->startPosture = startPosture;
  if (endPosture)
    config->endPosture = endPosture;
  this->moveTarget = target;
  this->setupChildRequest(config, true);
}

void Robocup::resetLocalizer()
{
  BaseModule::publishModuleRequest(boost::make_shared<ResetLocalizer>());
}

void Robocup::printGameData()
{
  RoboCupGameControlData& gameData = OVAR(RoboCupGameControlData, PlanningModule::gameData);
  cout << "gameData:" << endl;
  cout << "gameData.state: " << (int)gameData.state << endl;
  cout << "gameData.firstHalf: " << (int)gameData.firstHalf << endl;
  cout << "gameData.kickOffTeam: " << (int)gameData.kickOffTeam << endl;
  cout << "gameData.secsRemaining: " << (int)gameData.secsRemaining << endl;
  for (size_t i = 0; i < 2; ++i) {
    cout << "gameData.teams.teamNumber: " << (int)gameData.teams[i].teamNumber << endl;
    cout << "gameData.teams.teamColour: " << (int)gameData.teams[i].teamColour << endl;
    cout << "gameData.teams.score: " << (int)gameData.teams[i].score << endl;
    cout << "gameData.teams.penaltyShot: " << (int)gameData.teams[i].penaltyShot << endl;
    cout << "gameData.teams.singleShots: " << (int)gameData.teams[i].singleShots << endl;
    cout << "gameData.teams.coachSequence: " << (int)gameData.teams[i].coachSequence << endl;
    cout << "gameData.teams.coachMessage: " << gameData.teams[i].coachMessage << endl;
    cout << "gameData.teams.players[0].penalty: " << (int)gameData.teams[i].players[0].penalty << endl;
    cout << "gameData.teams.players[1].penalty: " << (int)gameData.teams[i].players[1].penalty << endl;
    cout << "gameData.teams.players[2].penalty: " << (int)gameData.teams[i].players[2].penalty << endl;
    cout << "gameData.teams.players[3].penalty: " << (int)gameData.teams[i].players[3].penalty << endl;
    cout << "gameData.teams.players[4].penalty: " << (int)gameData.teams[i].players[4].penalty << endl;
    cout << "gameData.teams.players[0].secsTillUnpenalised: " << (int)gameData.teams[i].players[0].secsTillUnpenalised << endl;
    cout << "gameData.teams.players[1].secsTillUnpenalised: " << (int)gameData.teams[i].players[1].secsTillUnpenalised << endl;
    cout << "gameData.teams.players[2].secsTillUnpenalised: " << (int)gameData.teams[i].players[2].secsTillUnpenalised << endl;
    cout << "gameData.teams.players[3].secsTillUnpenalised: " << (int)gameData.teams[i].players[3].secsTillUnpenalised << endl;
    cout << "gameData.teams.players[4].secsTillUnpenalised: " << (int)gameData.teams[i].players[4].secsTillUnpenalised << endl;
  }
}
