/**
 * @file PlanningBehaviors/RobotStartup/Types/RequestBehavior.cpp
 *
 * This file implements the class RequestBehavior
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/PlanningBehaviors/RobotStartup/Types/RequestBehavior.h"
#include "Utils/include/Behaviors/PBConfigs/PBRobocupConfig.h"
#include "Utils/include/Behaviors/PBConfigs/PBExternalInterfaceConfig.h"
#include "Utils/include/Behaviors/PBConfigs/PBNavigationConfig.h"
#include "Utils/include/Behaviors/PBConfigs/TestSuiteConfig.h"
#include "Utils/include/Behaviors/PBConfigs/PBKickSequenceConfig.h"

#define SWITCH_SENSORS OVAR(vector<float>, PlanningModule::switchSensors)
#define SWITCH_SENSORS_REL(x) OVAR_REL(x, vector<float>, PlanningModule::switchSensors)

void RequestBehavior::SetPosture::onRun() {
  if (bPtr->setPostureAndStiffness(bPtr->startPosture, StiffnessState::MAX, MOTION_1))
    nextState = bPtr->chestButtonWait.get();
}

void RequestBehavior::ChestButtonWait::onRun() {
  #if defined(MODULE_IS_REMOTE) || defined(MODULE_IS_LOCAL_SIMULATED)
    nextState = bPtr->startRequested.get();
  #else
  if (SWITCH_SENSORS_REL(bPtr)[CHEST_BOARD_BUTTON] > 0.1)
    nextState = bPtr->startRequested.get();
  #endif
}

void RequestBehavior::StartRequested::onRun() {
  try {
    using namespace std;
    string jsonConfigPath;
    jsonConfigPath =
      ConfigManager::getPBConfigsPath() +
        bPtr->getBehaviorCast()->requestedBehavior;
    Json::Value json;
    Json::Reader reader;
    ifstream config(jsonConfigPath, ifstream::binary);
    bool success = reader.parse(config, json, false);
    if (!success)
    {
      throw
      BehaviorException(
        bPtr,
        "Unable to parse json config:\n\t" +
        ConfigManager::getPBConfigsPath() +
        "RobotStartup/RequestBehavior.json.",
        true,
        EXC_INVALID_BEHAVIOR_SETUP
      );
    }
    PBConfigPtr planningConfig =
      boost::static_pointer_cast<PBConfig>(
        BehaviorConfig::makeFromJson(json));
    if (planningConfig) {
      PlanningRequestPtr request =
        boost::make_shared<RequestPlanningBehavior>(planningConfig);
      //! Add in queue twice since first one is disregarded due to this
      //! behavior already running
      BaseModule::publishModuleRequest(request);
      BaseModule::publishModuleRequest(request);
    } else {
      throw
      BehaviorException(
        bPtr,
        "Invalid start posture requested. See " +
        ConfigManager::getPBConfigsPath() +
        "RobotStartup/RequestBehavior.json.",
        true,
        EXC_INVALID_BEHAVIOR_SETUP
      );
    }
  } catch (Json::Exception& e) {
    LOG_EXCEPTION(e.what());
  } catch (BehaviorException& e) {
    LOG_EXCEPTION(e.what());
  }
  nextState = nullptr;
}

RequestBehaviorConfigPtr RequestBehavior::getBehaviorCast()
{
  return boost::static_pointer_cast <RequestBehaviorConfig> (config);
}

void RequestBehavior::initiate()
{
  LOG_INFO("RequestBehavior.initiate() called...");
  setStartPosture();
  inBehavior = true;
}

void RequestBehavior::update() 
{
  if (requestInProgress()) return;
  updatePostureAndStiffness();
  if (fsm->update()) {
    finish();
  }
}

void RequestBehavior::finish()
{
  LOG_INFO("RequestBehavior.finish() called...")
  inBehavior = false;
}

void RequestBehavior::loadExternalConfig()
{
  static bool loaded = false;
  if (!loaded) {
    loaded = true;
  }
}

void RequestBehavior::setStartPosture()
{
  try {
    string requestedPosture = getBehaviorCast()->requestedPosture;
    if (requestedPosture == "Crouch") {
      startPosture = PostureState::CROUCH;
    } else if (requestedPosture == "Sit") {
      startPosture = PostureState::SIT;
    } else if (requestedPosture == "StandZero") {
      startPosture = PostureState::STAND_ZERO;
    } else if (requestedPosture == "Stand") {
      startPosture = PostureState::STAND;
    } else if (requestedPosture == "StandHandsBehind") {
      startPosture = PostureState::STAND_HANDS_BEHIND;
    } else {
      throw 
      BehaviorException(
        this,
        "Invalid start posture requested. See " + ConfigManager::getPBConfigsPath() + "RobotStartup/RequestBehavior.json.",
        true,
        EXC_INVALID_BEHAVIOR
      );
    } 
  } catch (BehaviorException& e) {
    cout << e.what();
    startPosture = PostureState::UNKNOWN;
  }
}
