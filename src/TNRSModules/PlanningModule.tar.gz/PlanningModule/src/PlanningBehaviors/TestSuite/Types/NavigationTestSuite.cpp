/**
 * @file PlanningBehaviors/TestSuite/Types/NavigationTestSuite.cpp
 *
 * This file implements the class NavigationTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#include "LocalizationModule/include/LocalizationRequest.h"
#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/NavigationTestSuite.h"
#include "Utils/include/Behaviors/PBConfigs/PBNavigationConfig.h"
#include "VisionModule/include/VisionRequest.h"

NavigationTestSuiteConfigPtr NavigationTestSuite::getBehaviorCast()
{
  return boost::static_pointer_cast <NavigationTestSuiteConfig> (config);
}

void NavigationTestSuite::initiate()
{
  LOG_INFO("NavigationTestSuite.initiate() called...");
  fsm->state = fsmStates[getBehaviorCast()->startState];
  // Run Localization module
  BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(true));
  BaseModule::publishModuleRequest(
    boost::make_shared<InitiateLocalizer>(getBehaviorCast()->startPose)
  );
  OVAR(bool, PlanningModule::robotOnSideLine) = false;
  inBehavior = true;
}

void NavigationTestSuite::update()
{
  //LOG_INFO("NavigationTestSuite::update() called...")
  if (requestInProgress()) return;
  updatePostureAndStiffness();
  if (fsm->update()) {
    finish();
  }
}

void NavigationTestSuite::finish()
{
  LOG_INFO("NavigationTestSuite.finish()")
  inBehavior = false;
}

void NavigationTestSuite::GoToTarget::onStart()
{
  //LOG_INFO("NavigationTestSuite::GoToTarget::onStart() called...")
  bPtr->killStaticBehavior();
  bPtr->killMotionBehavior(MOTION_1);
  auto planConfig = boost::make_shared<GoToTargetConfig>();
  planConfig->goal = bPtr->getBehaviorCast()->goalPose;
  //planConfig->reachClosest = true;
  /*planConfig->startPosture =
    boost::make_shared<MBPostureConfig>(
      PostureState::STAND_HANDS_BEHIND,
      1.0f);
  planConfig->endPosture =
    boost::make_shared<MBPostureConfig>(
      PostureState::STAND_HANDS_BEHIND,
      1.0f);*/
  bPtr->setupChildRequest(planConfig, true);
}

void NavigationTestSuite::GoToTarget::onRun()
{
  //LOG_INFO("NavigationTestSuite::GoToTarget::onRun() called...")
  if (!bPtr->getChild()) {
    nextState = nullptr;
  } else {
    static int goalResetCount = 0;
    if (goalResetCount++ > 25) {
      auto planConfig = boost::make_shared<GoToTargetConfig>();
      planConfig->goal = bPtr->getBehaviorCast()->goalPose;
      bPtr->setupChildRequest(planConfig, true);
      goalResetCount=0;
    }
  }
}

void NavigationTestSuite::GoalChangedReplan::onStart()
{
  //LOG_INFO("NavigationTestSuite::GoalChangedReplan::onStart() called...")
  bPtr->killStaticBehavior();
  bPtr->killMotionBehavior(MOTION_1);
  auto planConfig = boost::make_shared<GoToTargetConfig>();
  planConfig->goal = bPtr->getBehaviorCast()->goalPose;
  bPtr->setupChildRequest(planConfig, true);
}

void NavigationTestSuite::GoalChangedReplan::onRun()
{
  //LOG_INFO("NavigationTestSuite::GoalChangedReplan::onRun() called...")
  static int goalResetCount = 0;
  if (goalResetCount++ > 25) {
    bPtr->getBehaviorCast()->goalPose.x() += 0.1;
    bPtr->getBehaviorCast()->goalPose.y() += 0.1;
    auto planConfig = boost::make_shared<GoToTargetConfig>();
    planConfig->goal = bPtr->getBehaviorCast()->goalPose;
    bPtr->setupChildRequest(planConfig, true);
    goalResetCount=0;
  }
}

void NavigationTestSuite::InvalidPathReplan::onStart()
{
}

void NavigationTestSuite::InvalidPathReplan::onRun()
{
  //Do nothing
}
