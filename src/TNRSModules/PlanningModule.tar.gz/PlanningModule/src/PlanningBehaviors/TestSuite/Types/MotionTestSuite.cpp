/**
 * @file PlanningBehaviors/TestSuite/Types/MotionTestSuite.cpp
 *
 * This file implements the class MotionTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#include <fstream>
#include "Utils/include/Behaviors/PBConfigs/PBNavigationConfig.h"
#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/MotionTestSuite.h"
#include "VisionModule/include/VisionRequest.h"
#include "LocalizationModule/include/LocalizationRequest.h"
#include "MotionModule/include/MotionRequest.h"
#include "Utils/include/Behaviors/MBConfigs/MBPostureConfig.h"
#include "Utils/include/Behaviors/MBConfigs/MBMovementConfig.h"
#include "TNRSBase/include/DebugBase.h"
#include "Utils/include/ConfigMacros.h"
#include "Utils/include/JsonUtils.h"

MotionTestSuiteConfigPtr MotionTestSuite::getBehaviorCast()
{
  return boost::static_pointer_cast <MotionTestSuiteConfig> (config);
}

void MotionTestSuite::initiate()
{
  LOG_INFO("MotionTestSuite.initiate() called...");
  /*BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::BALL));
  DebugBase::processDebugMsg("BallExtraction:drawBallContour:1");
  DebugBase::processDebugMsg("BallExtraction:displayOutput:1");*/
  using namespace std;
  string jsonConfigPath;
  jsonConfigPath =
    ConfigManager::getMBConfigsPath() + getBehaviorCast()->requestedBehavior;
  Json::Value json;
  ifstream config(jsonConfigPath, ifstream::binary);
  config >> json;
  if (!mbInProgress()) {
    using namespace std;
    MBConfigPtr motionConfig =
      boost::static_pointer_cast<MBConfig>(BehaviorConfig::makeFromJson(json));
    if (motionConfig) {
      setupMBRequest(MOTION_1, boost::static_pointer_cast<MBConfig>(motionConfig));
    }
  }
  inBehavior = true;
}

void MotionTestSuite::update()
{
}

void MotionTestSuite::finish()
{
  LOG_INFO("MotionTestSuite.finish() called...")
  inBehavior = false;
}
