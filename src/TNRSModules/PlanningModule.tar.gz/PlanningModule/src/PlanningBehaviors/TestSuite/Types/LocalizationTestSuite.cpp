/**
 * @file PlanningBehaviors/TestSuite/Types/LocalizationTestSuite.cpp
 *
 * This file implements the class LocalizationTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#include "LocalizationModule/include/LocalizationRequest.h"
#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/LocalizationTestSuite.h"
#include "TNRSBase/include/DebugBase.h"
#include "Utils/include/Behaviors/PBConfigs/PBNavigationConfig.h"
#include "Utils/include/ConfigMacros.h"
#include "VisionModule/include/VisionRequest.h"

LocalizationTestSuiteConfigPtr LocalizationTestSuite::getBehaviorCast()
{
  return boost::static_pointer_cast <LocalizationTestSuiteConfig> (config);
}

void LocalizationTestSuite::initiate()
{
  LOG_INFO("LocalizationTestSuite.initiate() called...");
  behaviorState = getBehaviorCast()->startState;
  // Run Localization module
  BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::BALL));
  BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(true));
  inBehavior = true;
}

void LocalizationTestSuite::update()
{
  if (behaviorState == testSideLineLocalization) {
    testSideLineLocalizationAction();
  } else if (behaviorState == testLocalizationStanding) {
    testLocalizationStandingAction();
  } else if (behaviorState == testLocalizationPrediction) {
    testLocalizationPredictionAction();
  } else if (behaviorState == testLocalizationWithMovement) {
    testLocalizationWithMovementAction();
  }
}

void LocalizationTestSuite::finish()
{
  LOG_INFO("LocalizationTestSuite.finish()")
  inBehavior = false;
}

void LocalizationTestSuite::testSideLineLocalizationAction()
{
  static bool setup = false;
  if (!setup) {
    OVAR(bool, PlanningModule::robotOnSideLine) = true;
    setup = true;
  }
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (!localized) {
    //LOG_INFO("Trying to localize based on goal information...")
    if (!mbInProgress()) {
      //LOG_INFO("Setting HeadTargetSearch motion config to find HeadTargetTypes::GOAL...")
      auto mConfig =
        boost::make_shared <HeadTargetSearchConfig> (HeadTargetTypes::GOAL);
      // Robot is on sidelines with other robots so keep scan range minimum.
      mConfig->scanMaxYaw = 45 * M_PI / 180;
      setupMBRequest(MOTION_1, mConfig);
    }
  } else {
    //LOG_INFO("Robot localized...")
    //auto& robotState = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
    //LOG_INFO("RobotPosition: ["
    //          << robotState.x << ","
    //          << robotState.y << ","
    //          << robotState.theta * 180.0 / M_PI << "]")
    OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
  }
}

void LocalizationTestSuite::testLocalizationStandingAction()
{
  static bool setup = false;
  if (!setup) {
    OVAR(bool, PlanningModule::robotOnSideLine) = false;
    OVAR(bool, PlanningModule::localizeWithLastKnown) = false;
    setup = true;
  }
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (!localized) {
    //LOG_INFO("Trying to localize based on goal information...")
    if (!mbInProgress()) {
      //LOG_INFO("Setting HeadTargetSearch motion config to find HeadTargetTypes::GOAL...")
      auto mConfig =
        boost::make_shared <HeadScanConfig> ();
      // Robot is on sidelines with other robots so keep scan range minimum.
      mConfig->scanMaxYaw = 90 * M_PI / 180;
      setupMBRequest(MOTION_1, mConfig);
    }
  } else {
    //LOG_INFO("Robot localized...")
    //auto& robotState = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
    /*LOG_INFO("RobotPosition: ["
              << robotState.getX() << ","
              << robotState.getY() << ","
              << robotState.getTheta() * 180.0 / M_PI << "]")*/
    //OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
    //OVAR(bool, PlanningModule::robotOnSideLine) = false;
  }
}

void LocalizationTestSuite::testLocalizationPredictionAction()
{
  if (this->getChild())
    boost::static_pointer_cast<PlanningBehavior>(this->getChild())->setMBIdOffset(MOTION_1 + 1);
  static bool setup = false;
  if (!setup) {
    BaseModule::publishModuleRequest(
      boost::make_shared<InitiateLocalizer>(RobotPose2D<float>(-4.25, 0.0, 0.0)));
    setup = true;
  }
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (localized) {
    static bool setupNav = false;
    if (!setupNav) {
      auto& rPose = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
      RobotPose2D<float> goalPose;
      RobotPose2D<float> relPose = RobotPose2D<float>(0.0, 1.0, 0.0);
      goalPose.x() = rPose.getX() + relPose.getX() * cos(rPose.getTheta()) - relPose.getY() * sin(rPose.getTheta());
      goalPose.y() = rPose.getY() + relPose.getX() * sin(rPose.getTheta()) + relPose.getY() * cos(rPose.getTheta());
      cout << "goalPose: " << goalPose.mat.transpose() << endl;
      this->killStaticBehavior();
      this->killMotionBehavior(MOTION_1);
      //auto hcConfig =
      //  boost::make_shared <HeadTargetTrackConfig> (HeadTargetTypes::GOAL);
      //setupMBRequest(MOTION_1, hcConfig);
      auto planConfig =
        boost::make_shared<GoToTargetConfig>();
      planConfig->goal = goalPose;
      planConfig->reachClosest = true;
      planConfig->startPosture =
        boost::make_shared<MBPostureConfig>(
          PostureState::STAND_HANDS_BEHIND,
          1.0f);
      planConfig->endPosture =
        boost::make_shared<MBPostureConfig>(
          PostureState::STAND_HANDS_BEHIND,
          1.0f);
      this->setupChildRequest(planConfig, true);
      setupNav = true;
      OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
    }
  }
}

void LocalizationTestSuite::testLocalizationWithMovementAction()
{
  if (this->getChild())
    boost::static_pointer_cast<PlanningBehavior>(this->getChild())->setMBIdOffset(MOTION_1 + 1);
  static bool setup = false;
  if (!setup) {
    OVAR(bool, PlanningModule::robotOnSideLine) = true;
    setup = true;
  }
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  if (!localized) {
    //LOG_INFO("Trying to localize based on goal information...")
    if (!mbInProgress()) {
      //LOG_INFO("Setting HeadTargetSearch motion config to find HeadTargetTypes::GOAL...")
      auto mConfig =
        boost::make_shared <HeadTargetSearchConfig> (HeadTargetTypes::GOAL);
      // Robot is on sidelines with other robots so keep scan range minimum.
      mConfig->scanMaxYaw = 45 * M_PI / 180;
      setupMBRequest(MOTION_1, mConfig);
    }
  } else {
    auto& rPose = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
    RobotPose2D<float> goalPose;
    RobotPose2D<float> relPose = RobotPose2D<float>(1.0, 2.0, 0.0);
    goalPose.x() = rPose.getX() + relPose.getX() * cos(rPose.getTheta()) - relPose.getY() * sin(rPose.getTheta());
    goalPose.y() = rPose.getY() + relPose.getX() * sin(rPose.getTheta()) + relPose.getY() * cos(rPose.getTheta());
    cout << "goalPose: " << goalPose.mat.transpose() << endl;
    this->killStaticBehavior();
    this->killMotionBehavior(MOTION_1);
    auto hcConfig =
      boost::make_shared <HeadTargetTrackConfig> (HeadTargetTypes::GOAL);
    setupMBRequest(MOTION_1, hcConfig);
    auto planConfig =
      boost::make_shared<GoToTargetConfig>();
    planConfig->goal = goalPose;
    planConfig->reachClosest = true;
    planConfig->startPosture =
      boost::make_shared<MBPostureConfig>(
        PostureState::STAND_HANDS_BEHIND,
        1.0f);
    planConfig->endPosture =
      boost::make_shared<MBPostureConfig>(
        PostureState::STAND_HANDS_BEHIND,
        1.0f);
    this->setupChildRequest(planConfig, true);
    OVAR(bool, PlanningModule::robotOnSideLine) = false;
    OVAR(bool, PlanningModule::localizeWithLastKnown) = true;
  }
}
