/**
 * @file PlanningBehaviors/TestSuite/Types/VisionTestSuite.cpp
 *
 * This file implements the class VisionTestSuite
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 21 Jul 2018
 */

#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/VisionTestSuite.h"
#include "VisionModule/include/VisionRequest.h"
#include "LocalizationModule/include/LocalizationRequest.h"
#include "TNRSBase/include/DebugBase.h"
#include "Utils/include/ConfigMacros.h"

VisionTestSuiteConfigPtr VisionTestSuite::getBehaviorCast()
{
  return boost::static_pointer_cast <VisionTestSuiteConfig> (config);
}

void VisionTestSuite::initiate()
{
  LOG_INFO("VisionTestSuite.initiate() called...");
  behaviorState = getBehaviorCast()->startState;
  OVAR(bool, PlanningModule::robotOnSideLine) = false;
  // Run vision module
  BaseModule::publishModuleRequest(boost::make_shared<SwitchVision>(true));
  BaseModule::publishModuleRequest(boost::make_shared<SwitchLocalization>(true));
  if (behaviorState == testSegmentation) {
    testSegmentationAction();
  } else if (behaviorState == testFieldExtraction) {
    testFieldExtractionAction();
  } else if (behaviorState == testGoalExtraction) {
    testGoalExtractionAction();
  } else if (behaviorState == testBallExtraction) {
    testBallExtractionAction();
  } else if (behaviorState == testRobotExtraction) {
    testRobotExtractionAction();
  } else if (behaviorState == testLinesExtraction) {
    testLinesExtractionAction();
  } else if (behaviorState == testAll) {
    testAllAction();
  }
  inBehavior = true;
}

void VisionTestSuite::update() 
{
}

void VisionTestSuite::finish()
{
  LOG_INFO("VisionTestSuite.finish()")
  inBehavior = false;
}

void VisionTestSuite::testSegmentationAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  //DebugBase::processDebugMsg("RegionSegmentation:drawRegions:1");
  //DebugBase::processDebugMsg("RegionSegmentation:displayInfo:1");
  //DebugBase::processDebugMsg("RegionSegmentation:displayOutput:1");
}

void VisionTestSuite::testFieldExtractionAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  //DebugBase::processDebugMsg("FieldExtraction:drawBorder:1");
  //DebugBase::processDebugMsg("FieldExtraction:drawBorderLines:1");
  //DebugBase::processDebugMsg("FieldExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("FieldExtraction:displayOutput:1");
}

void VisionTestSuite::testGoalExtractionAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  //DebugBase::processDebugMsg("GoalExtraction:drawScannedLines:1");
  //DebugBase::processDebugMsg("GoalExtraction:drawScannedRegions:1");
  //DebugBase::processDebugMsg("GoalExtraction:drawGoalBaseWindows:1");
  //DebugBase::processDebugMsg("GoalExtraction:drawGoalPostBases:1");
  //DebugBase::processDebugMsg("GoalExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("GoalExtraction:displayOutput:1");
}

void VisionTestSuite::testBallExtractionAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::BALL));
  //DebugBase::processDebugMsg("BallExtraction:drawPredictionState:1");
  //DebugBase::processDebugMsg("BallExtraction:drawScannedRegions:1");
  //DebugBase::processDebugMsg("BallExtraction:drawBallContour:1");
  //DebugBase::processDebugMsg("BallExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("BallExtraction:displayOutput:1");
}

void VisionTestSuite::testRobotExtractionAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  //DebugBase::processDebugMsg("RobotExtraction:drawScannedLines:1");
  //DebugBase::processDebugMsg("RobotExtraction:drawJerseyRegions:1");
  //DebugBase::processDebugMsg("RobotExtraction:drawRobotRegions:1");
  //DebugBase::processDebugMsg("RobotExtraction:drawStrayRegions:1");
  //DebugBase::processDebugMsg("RobotExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("RobotExtraction:displayOutput:1");
}

void VisionTestSuite::testLinesExtractionAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  //DebugBase::processDebugMsg("LinesExtraction:drawScannedEdges:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawBorderLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawWorldLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawFiltWorldLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawCircle:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawCorners:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawUnknownLandmarks:1");
  //DebugBase::processDebugMsg("LinesExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("LinesExtraction:displayOutput:1");
}

void VisionTestSuite::testAllAction()
{
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::SEGMENTATION));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::FIELD));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::ROBOT));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::BALL));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::GOAL));
  BaseModule::publishModuleRequest(
    boost::make_shared<SwitchFeatureExtModule>(true, FeatureExtractionIds::LINES));
  //DebugBase::processDebugMsg("LinesExtraction:drawScannedEdges:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawBorderLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawWorldLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawFiltWorldLines:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawCircle:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawCorners:1");
  //DebugBase::processDebugMsg("LinesExtraction:drawUnknownLandmarks:1");
  //DebugBase::processDebugMsg("LinesExtraction:displayInfo:1");
  //DebugBase::processDebugMsg("LinesExtraction:displayOutput:1");
}
