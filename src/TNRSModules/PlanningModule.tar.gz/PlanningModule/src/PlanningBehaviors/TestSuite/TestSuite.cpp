/**
 * @file PlanningModule/src/PlanningBehaviors/TestSuite/TestSuite.cpp
 *
 * This file implements the class TestSuite
 *
 * @author <A href="mailto:saifullah3396@rsail.com">Saifullah</A>
 * @date 16 Nov 2017
 */

#include "PlanningModule/include/PlanningBehaviors/TestSuite/TestSuite.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/VisionTestSuite.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/LocalizationTestSuite.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/MotionTestSuite.h"
#include "PlanningModule/include/PlanningBehaviors/TestSuite/Types/NavigationTestSuite.h"

boost::shared_ptr<TestSuite> TestSuite::getType(
  PlanningModule* planningModule, const BehaviorConfigPtr& cfg) 
{ 
  TestSuite* ts;
  switch (cfg->type) {
      case (unsigned) TestSuiteTypes::VISION:
        ts = new VisionTestSuite(planningModule, cfg); break;
      case (unsigned) TestSuiteTypes::LOCALIZATION:
        ts = new LocalizationTestSuite(planningModule, cfg); break;
      case (unsigned) TestSuiteTypes::MOTION:
        ts = new MotionTestSuite(planningModule, cfg); break;
      case (unsigned) TestSuiteTypes::NAVIGATION:
        ts = new NavigationTestSuite(planningModule, cfg); break;
  }
  return boost::shared_ptr<TestSuite>(ts);
}

TestSuiteConfigPtr TestSuite::getBehaviorCast()
{
  return boost::static_pointer_cast <TestSuiteConfig> (config);
}
