/**
 * @file PlanningModule/PlanningModule.h
 *
 * This file implements the class for behavior planning.
 * All the functions and algorithms for adding intelligence to the
 * robot will be defined under this module.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 04 Feb 2017
 */

#include <boost/make_shared.hpp>
#include "TeamNUSTSPL/include/TNSPLModuleIds.h"
#include "PlanningModule/include/PlanningModule.h"
#include "PlanningModule/include/PlanningRequest.h"
#include "PlanningModule/include/WorldBallTracker.h"
#include "Utils/include/PathPlanner/PathPlanner.h"
#include "Utils/include/PathPlanner/GridMap2D.h"
#include "Utils/include/Behaviors/PBConfigs/PBStartupConfig.h"
#include "Utils/include/HardwareIds.h"

using namespace PathPlannerSpace;

PlanningModule::PlanningModule(void* parent, const ALMemoryProxyPtr& memoryProxy) :
  BaseModule(
    parent, 
    (unsigned) TNSPLModules::PLANNING, 
    "PlanningModule"
  ), memoryProxy(memoryProxy)
{
}

void PlanningModule::setThreadPeriod()
{
  setPeriodMinMS(IVAR(int, planningThreadPeriod));
}

void PlanningModule::initMemoryConn()
{
  ASSERT_MSG(sharedMemory, "Shared Memory not found.");
  genericInputConnector = 
    new InputConnector(this, getModuleName() + "InputConnector");
  genericOutputConnector = 
    new OutputConnector(this, getModuleName() + "OutputConnector");
  genericInputConnector->initConnector();
  genericOutputConnector->initConnector();
}

void PlanningModule::init()
{
  LOG_INFO("Initializing planning behavior manager...")
  pbManager = boost::make_shared<PBManager>(this);
  LOG_INFO("Initializing roboCup data handles...")
  setupRoboCupDataHandler();
  LOG_INFO("Initializing planning module sensor layers...")
  sensorLayers.resize((unsigned)PlanningSensors::COUNT);
  sensorLayers[(unsigned)PlanningSensors::JOINT_TEMP] =
  SensorLayer::makeSensorHandle(
    SensorTypes::JOINTS + JointSensorTypes::TEMPERATURE,
    OVAR_PTR(vector<float>, jointTemperatureSensors),
    memoryProxy);
  sensorLayers[(unsigned)PlanningSensors::JOINT_CURRENT] =
  SensorLayer::makeSensorHandle(
    SensorTypes::JOINTS + JointSensorTypes::CURRENT,
    OVAR_PTR(vector<float>, jointCurrentSensors),
    memoryProxy);
  sensorLayers[(unsigned)PlanningSensors::TOUCH] =
    SensorLayer::makeSensorHandle(
      TOUCH_SENSORS,
      OVAR_PTR(vector<float>, touchSensors),
      memoryProxy);
  sensorLayers[(unsigned)PlanningSensors::SWITCH] =
    SensorLayer::makeSensorHandle(
      SWITCH_SENSORS,
      OVAR_PTR(vector<float>, switchSensors),
      memoryProxy);
  sensorLayers[(unsigned)PlanningSensors::BATTERY] =
    SensorLayer::makeSensorHandle(
      BATTERY_SENSORS,
      OVAR_PTR(vector<float>, batterySensors),
      memoryProxy);
  sensorsUpdate();
  LOG_INFO("Initializing world ball tracker...")
  wbTracker = boost::make_shared <WorldBallTracker> (this);
  wbTracker->init();
  //! Create path planner
  LOG_INFO("Initializing PathPlanner...")
  pathPlanner = PathPlannerPtr(new PathPlanner());
  pathPlanner->setMapPtr(
    boost::make_shared <GridMap2D>(
      IVAR(OccupancyMap, PlanningModule::occupancyMap)
    )
  );
  LOG_INFO("Setting request for RobotStartup behavior...")
  using namespace std;
  string jsonConfigPath;
  jsonConfigPath = ConfigManager::getPBConfigsPath() + "RobotStartup/RequestBehavior.json";
  Json::Value json;
  LOG_INFO("Loading json config: " << jsonConfigPath)
  ifstream config(jsonConfigPath, ifstream::binary);
  config >> json;
  PBConfigPtr planningConfig = boost::static_pointer_cast<PBConfig>(BehaviorConfig::makeFromJson(json));
  PlanningRequestPtr planningRequest =
    boost::make_shared<RequestPlanningBehavior>(planningConfig);
  addRequest(planningRequest); // publish to itself
  LOG_INFO("Initializing PlanningModule Output Variables...")
  OVAR(PlanningState, PlanningModule::planningState) = PlanningState::STARTUP;
  OVAR(int, PlanningModule::robocupRole) = -1;
  OVAR(int, PlanningModule::robotIntention) = -1;
  OVAR(bool, PlanningModule::robotOnSideLine) = false;
  OVAR(bool, PlanningModule::localizeWithLastKnown) = false;
  OVAR(BehaviorInfo, PlanningModule::pBehaviorInfo) = BehaviorInfo();
  OVAR(vector<float>, PlanningModule::jointTemperatureSensors) = vector<float>(NUM_JOINTS, 0.f);
  OVAR(vector<float>, PlanningModule::jointCurrentSensors) = vector<float>(NUM_JOINTS, 0.f);
  OVAR(vector<float>, PlanningModule::touchSensors) = vector<float>(NUM_TOUCH_SENSORS, 0.f);
  OVAR(vector<float>, PlanningModule::switchSensors) = vector<float>(NUM_SWITCH_SENSORS, 0.f);
  OVAR(vector<float>, PlanningModule::batterySensors) = vector<float>(NUM_BATTERY_SENSORS, 0.f);
  OVAR(vector<float>, PlanningModule::sonarSensors) = vector<float>(NUM_SONAR_SENSORS, 0.f);
  OVAR(RoboCupGameControlData, PlanningModule::gameData) = RoboCupGameControlData();
  OVAR(RobotPose2D<float>, PlanningModule::moveTarget) = RobotPose2D<float>(0.0, 0.0, 0.0);
}

void
PlanningModule::handleRequests()
{
  if (inRequests.isEmpty())
    return;
  auto request = inRequests.queueFront();
  if (boost::static_pointer_cast <PlanningRequest>(request)) {
    auto reqId = request->getId();
    if (reqId == (unsigned)PlanningRequestIds::BEHAVIOR_REQUEST) {
      auto rpb = 
        boost::static_pointer_cast<RequestPlanningBehavior>(request);
      pbManager->manageRequest(rpb);
    } else if (reqId == (unsigned)PlanningRequestIds::KILL_BEHAVIOR) {
      pbManager->killBehavior();
    }
  }
  inRequests.popQueue();
}

void PlanningModule::mainRoutine()
{    
  sensorsUpdate();
  updateWorldBallInfo();
  pbManager->update();
  OVAR(BehaviorInfo, PlanningModule::pBehaviorInfo) =
    pbManager->getBehaviorInfo();
}

void PlanningModule::sensorsUpdate()
{
  for (size_t i = 0; i < sensorLayers.size(); ++i) {
    sensorLayers[i]->update();
  }
  RoboCupGameControlData gameControlData;
  AL::ALValue value = memoryProxy->getData("GameCtrl/RoboCupGameControlData");
  if (value.isBinary() && value.getSize() == sizeof(RoboCupGameControlData)) memcpy(
    &gameControlData,
    value,
    sizeof(RoboCupGameControlData));
  gameControlData.teams[1].teamColour = 2;
  OVAR(RoboCupGameControlData, PlanningModule::gameData) = gameControlData;
}

void
PlanningModule::updateWorldBallInfo()
{
  vector<float> measurements;
  auto& localized = IVAR(bool, PlanningModule::robotLocalized);
  auto& ballInfo = IVAR(BallInfo, PlanningModule::ballInfo);
  wbTracker->predict();
  if (localized && ballInfo.found) {
    auto& rP = IVAR(RobotPose2D<float>, PlanningModule::robotPose2D);
    // Position is translated & rotated with robot's angle
    auto posWorld = rP.transform(ballInfo.posRel);
    measurements.push_back(posWorld.x);
    measurements.push_back(posWorld.y);
  }
  if (measurements.empty()) {
    auto& teamRobots = IVAR(vector<TeamRobot>, PlanningModule::teamRobots);
    for (int i = 0; i < teamRobots.size(); ++i) {
      if (!measurements.empty()) break;
      if (!teamRobots[i].dataReceived) continue;
      if (teamRobots[i].ballAge > 0 && teamRobots[i].ballAge < 0.50f) {
        if (teamRobots[i].positionConfidence >= 50 && teamRobots[i].ballAge <= 1.f) {
          auto posRel = teamRobots[i].ballPos;
          auto rP = teamRobots[i].pose;
          auto ct = cos(rP.getTheta());
          auto st = sin(rP.getTheta());
          Point2f teamPosWorld;
          // Position is translated & rotated with robot's angle
          teamPosWorld.x = rP.getX() + posRel.x * ct - posRel.y * st;
          teamPosWorld.y = rP.getY() + posRel.x * st + posRel.y * ct;
          measurements.push_back(teamPosWorld.x / 1e3);
          measurements.push_back(teamPosWorld.y / 1e3);
        }
      }
    }
  }
  wbTracker->updateFilter(measurements);
  Mat ballState = wbTracker->getEstimatedState();
  WorldBallInfo wbInfo;
  wbInfo.found = wbTracker->getBallFound();
  wbInfo.posWorld.x = ballState.at<float>(0);
  wbInfo.posWorld.y = ballState.at<float>(1);
  wbInfo.velWorld.x = ballState.at<float>(2);
  wbInfo.velWorld.y = ballState.at<float>(3);
  OVAR(WorldBallInfo, PlanningModule::worldBallInfo) = wbInfo;
}


void PlanningModule::setupRoboCupDataHandler()
{
  #ifdef MODULE_IS_REMOTE
  RoboCupGameControlData gameCtrlData;
  AL::ALValue value((const char*) &gameCtrlData, sizeof(gameCtrlData));
  memoryProxy->insertData("GameCtrl/RoboCupGameControlData", value);
  #endif
  memoryProxy->insertData(
    "GameCtrl/teamNumber",
    (int) IVAR(unsigned, PlanningModule::teamNumber));
  memoryProxy->insertData(
    "GameCtrl/teamColour",
    (int) IVAR(unsigned, PlanningModule::teamColor));
  memoryProxy->insertData(
    "GameCtrl/playerNumber",
    (int) IVAR(unsigned, PlanningModule::playerNumber));
}

PathPlannerSpace::PathPlannerPtr PlanningModule::getPathPlanner()
{
  return pathPlanner;
}
