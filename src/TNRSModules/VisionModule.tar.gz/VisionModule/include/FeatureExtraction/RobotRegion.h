/**
 * @file FeatureExtraction/RobotRegion.h
 *
 * This file defines the struct RobotRegion.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 12 Mar 2018
 */

#pragma once

#include "Utils/include/VisionUtils.h"

/**
 * @struct RobotRegion
 * @brief Holds information about the region that defines a robot.
 */
struct RobotRegion
{
  RobotRegion(const boost::shared_ptr<ScannedRegion>& sr, const bool& ourTeam) :
    ourTeam(ourTeam), sr(sr), refresh(true), fallen(false),
      posFromJersey(false), minDistValidation(0.3f)
  {
  }

  Point2f world;
  bool refresh;
  float timeDetected;
  bool ourTeam;
  bool fallen;
  bool posFromJersey;
  boost::shared_ptr<ScannedRegion> sr;
  float minDistValidation; // 30 cms
};
typedef boost::shared_ptr<RobotRegion> RobotRegionPtr;
