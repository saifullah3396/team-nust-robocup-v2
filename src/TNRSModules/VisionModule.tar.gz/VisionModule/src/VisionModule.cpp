/**
 * @file VisionModule/VisionModule.cpp
 *
 * This file implements a class for vision planning.
 * All the functions and algorithms for image processing, object
 * detection and classification, and colorspaces will be defined
 * under this module.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 04 Feb 2017
 */

#include <boost/exception/diagnostic_information.hpp> 
#include <Eigen/Dense>
#include "TeamNUSTSPL/include/TNSPLModuleIds.h"
#include "VisionModule/include/CameraModule/CameraModule.h" 
#include "VisionModule/include/FeatureExtraction/BallExtraction.h"
#include "VisionModule/include/FeatureExtraction/FieldExtraction.h"
#include "VisionModule/include/FeatureExtraction/RegionSegmentation.h"
#include "VisionModule/include/FeatureExtraction/FeatureExtraction.h"
#include "VisionModule/include/FeatureExtraction/GoalExtraction.h"
#include "VisionModule/include/FeatureExtraction/LinesExtraction.h"
#include "VisionModule/include/FeatureExtraction/RobotExtraction.h"
#include "VisionModule/include/CameraTransform.h"
#include "VisionModule/include/VisionModule.h"
#include "VisionModule/include/VisionRequest.h"
#include "LocalizationModule/include/LocalizationRequest.h"

VisionModule::VisionModule(void* processingModule,
  const ALVideoDeviceProxyPtr& camProxy) :
  BaseModule(processingModule, (unsigned) TNSPLModules::VISION, "VisionModule"),
  DebugBase("VisionModule", this), 
  camProxy(camProxy),
  runVision(false),
  useLoggedImages(false),
  projectField(false),
  logImages(vector<bool>(NUM_CAMS, false)),
  writeVideo(vector<bool>(NUM_CAMS, false)),
  featureExtToRun(vector<bool>((unsigned)FeatureExtractionIds::COUNT, false))
{
}

void
VisionModule::setThreadPeriod()
{
  setPeriodMinMS(IVAR(int, VisionModule::visionThreadPeriod));
}

void
VisionModule::initMemoryConn()
{
  ASSERT_MSG(sharedMemory, "Shared Memory not found.");
  genericInputConnector = 
    new InputConnector(this, getModuleName() + "InputConnector");
  genericOutputConnector = 
    new OutputConnector(this, getModuleName() + "OutputConnector");
  genericInputConnector->initConnector();
  genericOutputConnector->initConnector();
}

void
VisionModule::init()
{
  LOG_INFO("Initializing vision debug base...")
  initDebugBase();
  LOG_INFO("Initializing CameraModule...")
  cameraModule =
    boost::shared_ptr<CameraModule>(new CameraModule(this));
  LOG_INFO("Initializing CameraTransform...")
  for (size_t i = 0; i < NUM_CAMS; ++i) {
    cameraTransforms.push_back(
      boost::shared_ptr<CameraTransform>(new CameraTransform(this, i))
    );
  }
  LOG_INFO("Initializing ColorHandler...")
  colorHandler = boost::shared_ptr<ColorHandler>(new ColorHandler());
  LOG_INFO("Initializing FeatureExtraction classes...")
  setupFeatureExtraction();
  LOG_INFO("Initializing VisionModule debugging variables... See" << ConfigManager::getConfigDirPath() << "VisionConfig.ini")
  int tempDebug;
  int tempDebugImageIndex;
  int tempSendKnownLandmarks;
  int tempSendUnknownLandmarks;
  GET_CONFIG(
    "VisionConfig",
    (int, VisionModule.debug, tempDebug), 
    (int, VisionModule.debugImageIndex, tempDebugImageIndex),
    (int, VisionModule.sendKnownLandmarks, tempSendKnownLandmarks),
    (int, VisionModule.sendUnknownLandmarks, tempSendUnknownLandmarks),
  )
  SET_DVAR(int, debug, tempDebug);
  SET_DVAR(int, debugImageIndex, tempDebugImageIndex);
  LOG_INFO("Initializing VisionModule Output variables...")
  OVAR(BallInfo, VisionModule::ballInfo) = BallInfo();
  OVAR(GoalInfo, VisionModule::goalInfo) = GoalInfo();
  OVAR(bool, VisionModule::landmarksFound) = false;
  OVAR(ObsObstacles, VisionModule::obstaclesObs) = ObsObstacles();
}

void VisionModule::handleRequests()
{
  while (!inRequests.isEmpty()) {
    auto request = inRequests.queueFront();
    if (boost::static_pointer_cast <VisionRequest>(request)) {
      auto reqId = request->getId();
      if (reqId == (unsigned)VisionRequestIds::SWITCH_VISION) {
        auto sv = boost::static_pointer_cast <SwitchVision>(request);
        runVision = sv->state;
      } else if (reqId == (unsigned)VisionRequestIds::SWITCH_VIDEO_WRITER) {
        auto svw = boost::static_pointer_cast <SwitchVideoWriter>(request);
        writeVideo[svw->camIndex] = svw->state;
      } else if (reqId == (unsigned)VisionRequestIds::SWITCH_FIELD_PROJECTION) {
        auto sfp = boost::static_pointer_cast <SwitchFieldProjection>(request);
        projectField = sfp->state;
      } else if (reqId == (unsigned)VisionRequestIds::SWITCH_LOG_IMAGES) {
        auto sli = boost::static_pointer_cast <SwitchLogImages>(request);
        logImages[sli->camIndex] = sli->state;
      } else if (reqId == (unsigned)VisionRequestIds::SWITCH_USE_LOGGED_IMAGES) {
        auto uli = boost::static_pointer_cast <SwitchUseLoggedImages>(request);
        useLoggedImages = uli->state;
      } else if (reqId == (unsigned)VisionRequestIds::SWITCH_FE_MODULE) {
        auto uli = boost::static_pointer_cast <SwitchFeatureExtModule>(request);
        if (uli->id != FeatureExtractionIds::COUNT) {
          featureExtToRun[(unsigned)uli->id] = uli->state;
          featureExt[(unsigned)uli->id]->setCurrentImage(uli->camIndex);
        } else {
          for (size_t i = 0; i < (unsigned)FeatureExtractionIds::COUNT; ++i) {
            featureExtToRun[i] = uli->state;
            featureExt[i]->setCurrentImage(uli->camIndex);
          }
        }
      }
    }
    inRequests.popQueue();
  }
}

void
VisionModule::mainRoutine()
{
  OVAR(ObsObstacles, VisionModule::obstaclesObs).data.clear();
  // Execution of this module is decided by planning module.
  if (runVision) {
    // update cameras and get images
    cameraUpdate();
    // save video if required
    //handleVideoWriting();
    // process image for extracting new features
    if (featureExtractionUpdate())
      updateLandmarksInfo();
    if (projectField)
      setupFieldProjection();
    if (GET_DVAR(int, debug)) { // If debugging is allowed
      sendKnownLandmarksInfo();
      sendUnknownLandmarksInfo();
      sendImages();
    }
    // Update the id of newly observed obstacles
    OVAR(ObsObstacles, VisionModule::obstaclesObs).assignId();
  }
}

void VisionModule::cameraUpdate()
{
  #ifdef MODULE_IS_REMOTE
  for (int i = 0; i < NUM_CAMS; ++i) {
    cameraModule->updateImage(i, logImages[i], useLoggedImages);
    cameraTransforms[i]->update();
  }
  #else
  for (int i = 0; i < NUM_CAMS; ++i) {
    cameraModule->updateImage(i);
    // update camera transformation matrices
    cameraTransforms[i]->update();
  }
  #endif
}

void VisionModule::handleVideoWriting()
{
  /* Video recording process is too computationally expensive for the robot
   * int& writeVideo = IVAR(int, VisionModule::writeVideo);
  if (writeVideo == 0 || writeVideo == 1) {
    cameraModule->recordVideo(writeVideo);
    return;
  } else if (writeVideo == 2) {
    for (int i = 0; i < 2; ++i)
      cameraModule->recordVideo(i);
    return;
  } else if (writeVideo == -1) {
    cameraModule->stopRecording();
    return;
  }*/
}

bool VisionModule::featureExtractionUpdate()
{
  FeatureExtraction::setupImagesAndHists();
  FeatureExtraction::clearLandmarks();
  if (colorHandler->fieldHistFormed()) {
    for (size_t i = 0; i < (unsigned)FeatureExtractionIds::COUNT; ++i) {
      if (featureExtToRun[i]) {
        featureExt[i]->processImage();
      }
    }
    return true;
  }
  return false;
}

void VisionModule::updateLandmarksInfo()
{
  auto klu =
    boost::make_shared<KnownLandmarksUpdate>(
      FeatureExtraction::getKnownLandmarks());
  auto ulu =
    boost::make_shared<UnknownLandmarksUpdate>(
      FeatureExtraction::getUnknownLandmarks());
  BaseModule::publishModuleRequest(klu);
  BaseModule::publishModuleRequest(ulu);
  if (klu->landmarks.size() > 0)// || ulu->landmarks.size() > 10)
    OVAR(bool, VisionModule::landmarksFound) = true;
  else
    OVAR(bool, VisionModule::landmarksFound) = false;
}

void VisionModule::setupFieldProjection()
{
  static bool fieldPointsSaved = false;
  if (!fieldPointsSaved) {
    float x = 4.5f;
    float y = -3.f;
    for (int i = 0; i < 13; ++i) {
      fieldPoints.push_back(Point3f(x, y, 0.0));
      y += 0.5f;
    }
    x = 4.f;
    y = -3.f;
    for (int i = 0; i < 8; ++i) {
      fieldPoints.push_back(Point3f(x, y, 0.0));
      fieldPoints.push_back(Point3f(x, -y, 0.0));
      x -= 0.5f;
    }
    float xEllipse = 0;
    float ellipseRadius = 0.75;
    for (int i = 0; i < 25; ++i) {
      xEllipse += 0.75 / 25.0;
      //cout << "xEllipse: " << xEllipse << endl;
      float yEllipse =
      sqrt(ellipseRadius * ellipseRadius - xEllipse * xEllipse);
      fieldPoints.push_back(Point3f(xEllipse, yEllipse, 0.0));
      fieldPoints.push_back(Point3f(xEllipse, -yEllipse, 0.0));
    }
    fieldPointsSaved = true;
  }
  //cout << "size: " << fieldPoints.size() << endl;
  vector<Point2f> imagePs;
  cameraTransforms[0]->worldToImage(fieldPoints, imagePs);
  VisionUtils::drawPoints(imagePs, FeatureExtraction::getBgrMat(0));
  cameraTransforms[1]->worldToImage(fieldPoints, imagePs);
  VisionUtils::drawPoints(imagePs, FeatureExtraction::getBgrMat(1));
  VisionUtils::displayImage(FeatureExtraction::getBgrMat(0), "Top");
  VisionUtils::displayImage(FeatureExtraction::getBgrMat(1), "Bottom");
}

void VisionModule::setupFeatureExtraction()
{
  RoboCupGameControlData gameData =
    IVAR(RoboCupGameControlData, VisionModule::gameData);
  unsigned ourTeam = gameData.teams[0].teamColour;
  unsigned oppTeam = gameData.teams[1].teamColour;
  Colors ourColor = Colors::YELLOW, oppColor = Colors::BLUE;
  if (ourTeam == TEAM_BLACK) ourColor = Colors::BLACK;
  else if (ourTeam == TEAM_BLUE) ourColor = Colors::BLUE;
  else if (ourTeam == TEAM_RED) ourColor = Colors::RED;
  else if (ourTeam == TEAM_YELLOW) ourColor = Colors::YELLOW;

  if (oppTeam == TEAM_BLACK) oppColor = Colors::BLACK;
  else if (oppTeam == TEAM_BLUE) oppColor = Colors::BLUE;
  else if (oppTeam == TEAM_RED) oppColor = Colors::RED;
  else if (oppTeam == TEAM_YELLOW) oppColor = Colors::YELLOW;
  bool blackJerseyExists =
    ourColor == Colors::BLACK || oppColor == Colors::BLACK;
  FeatureExtraction::setup(this);
  ourColor = Colors::BLUE;
  oppColor = Colors::YELLOW;
  FeatureExtraction::updateColorInfo(ourColor, oppColor, blackJerseyExists);

  featureExt.resize((unsigned)FeatureExtractionIds::COUNT);
  featureExt[(unsigned)FeatureExtractionIds::SEGMENTATION] =
    boost::shared_ptr<RegionSegmentation> (new RegionSegmentation(this));
  featureExt[(unsigned)FeatureExtractionIds::FIELD] =
    boost::shared_ptr<FieldExtraction> (new FieldExtraction(this));
  featureExt[(unsigned)FeatureExtractionIds::ROBOT] =
    boost::shared_ptr<RobotExtraction> (new RobotExtraction(this));
  featureExt[(unsigned)FeatureExtractionIds::GOAL] =
    boost::shared_ptr<GoalExtraction> (new GoalExtraction(this));
  featureExt[(unsigned)FeatureExtractionIds::BALL] =
    boost::shared_ptr<BallExtraction> (new BallExtraction(this));
  featureExt[(unsigned)FeatureExtractionIds::LINES] =
    boost::shared_ptr<LinesExtraction> (new LinesExtraction(this));
  try {
    boost::static_pointer_cast<RegionSegmentation>(
      featureExt[(unsigned)FeatureExtractionIds::SEGMENTATION]
    )->setFieldExtraction(
        boost::static_pointer_cast<FieldExtraction>(
          featureExt[(unsigned)FeatureExtractionIds::FIELD]
        )
      );
  } catch (boost::exception &e) {
    LOG_EXCEPTION(boost::diagnostic_information(e));
  }
}

void VisionModule::sendKnownLandmarksInfo()
{
  if (GET_DVAR(int, sendKnownLandmarks)) {
    vector<KnownLandmarkPtr> kl = FeatureExtraction::getKnownLandmarks();
    //sample data
    //kl.push_back(boost::make_shared<KnownLandmark>(FL_TYPE_GOAL_POST, Point2f(4.5, -0.9)));
    //kl.push_back(boost::make_shared<KnownLandmark>(FL_TYPE_PENALTY_MARK, Point2f(3.7, 0)));
    //kl.push_back(boost::make_shared<KnownLandmark>(FL_TYPE_CIRCLE, Point2f(0.0, 0)));
    //kl.push_back(boost::make_shared<KnownLandmark>(FL_TYPE_T_CORNER, Point2f(0.0, 3.0)));
    //kl.push_back(boost::make_shared<KnownLandmark>(FL_TYPE_L_CORNER, Point2f(4.4, 3.0)));
    if (kl.size() > 0) {
      Mat_<float> klData(kl.size(), 3);
      for (size_t i = 0; i < kl.size(); ++i) {
        klData(i, 0) = kl[i]->type;
        klData(i, 1) = kl[i]->pos.x;
        klData(i, 2) = kl[i]->pos.y;
      }
      const unsigned char* ptr = klData.data;
      int count = kl.size() * 12;
      // Change now to Comm message request
      CommMessage msg = CommMessage(DataUtils::bytesToHexString(ptr, count), CommMsgTypes::KNOWN_LANDMARKS);
      CommRequestPtr request = boost::make_shared<SendMsgRequest>(msg);
      BaseModule::publishModuleRequest(request);
    }
  }
}

void VisionModule::sendUnknownLandmarksInfo()
{
  if (GET_DVAR(int, sendUnknownLandmarks)) {
    vector<UnknownLandmarkPtr> ukl = FeatureExtraction::getUnknownLandmarks();
    //sample data
    //ukl.push_back(boost::make_shared<UnknownLandmark>(0, Point2f(1.0, 0)));
    //ukl.push_back(boost::make_shared<UnknownLandmark>(0, Point2f(2.0, 0)));
    //ukl.push_back(boost::make_shared<UnknownLandmark>(0, Point2f(3.0, 0)));
    //ukl.push_back(boost::make_shared<UnknownLandmark>(0, Point2f(4.0, 0)));
    if (ukl.size() > 0) {
      Mat_<float> uklData(ukl.size(), 2);
      for (size_t i = 0; i < ukl.size(); ++i) {
        uklData(i, 0) = ukl[i]->pos.x;
        uklData(i, 1) = ukl[i]->pos.y;
      }
      const unsigned char* ptr = uklData.data;
      int count = ukl.size() * 8;
      // Change now to Comm message request
      CommMessage msg = CommMessage(DataUtils::bytesToHexString(ptr, count), CommMsgTypes::UNKNOWN_LANDMARKS);
      CommRequestPtr request = boost::make_shared<SendMsgRequest>(msg);
      BaseModule::publishModuleRequest(request);
    }
  }
}

void VisionModule::sendImages()
{
  if (GET_DVAR(int, debugImageIndex) == 0) {
    CommMessage imageMsg(
      VisionUtils::cvMatToString(FeatureExtraction::getBgrMat(0)),
      CommMsgTypes::TOP_IMAGE
    );
    CommRequestPtr request =
      boost::make_shared<SendMsgRequest>(imageMsg);
    BaseModule::publishModuleRequest(request);
  } else if (GET_DVAR(int, debugImageIndex) == 1) {
    CommMessage imageMsg(
      VisionUtils::cvMatToString(FeatureExtraction::getBgrMat(1)),
      CommMsgTypes::BOTTOM_IMAGE
    );
    CommRequestPtr request = boost::make_shared<SendMsgRequest>(imageMsg);
    BaseModule::publishModuleRequest(request);
  }
}
