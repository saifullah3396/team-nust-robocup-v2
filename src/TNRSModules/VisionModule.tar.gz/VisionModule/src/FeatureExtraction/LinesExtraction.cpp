/**
 * @file FeatureExtraction/LinesExtraction.h
 *
 * This file declares the class for field corners extraction from
 * the image.
 *
 * @author <A href="mailto:saifullah3396@gmail.com">Saifullah</A>
 * @date 22 Aug 2017
 */

#include <chrono>
#include "VisionModule/include/FeatureExtraction/FieldExtraction.h"
#include "VisionModule/include/FeatureExtraction/LinesExtraction.h"
#include "VisionModule/include/FeatureExtraction/RegionSegmentation.h"
#include "VisionModule/include/FeatureExtraction/RobotExtraction.h"
#include "VisionModule/include/FeatureExtraction/RobotRegion.h"
#include "VisionModule/include/FeatureExtraction/Circle.h"
#include "VisionModule/include/FeatureExtraction/FittedLine.h"

LinesExtraction::LinesExtraction(VisionModule* visionModule) :
  FeatureExtraction(visionModule),
  DebugBase("LinesExtraction", this)
{
  //! Initialize debug variables
  initDebugBase();
  int tempSendTime;
  int tempDrawScannedEdges;
  int tempDrawBorderLines;
  int tempDrawWorldLines;
  int tempDrawFiltWorldLines;
  int tempDrawCircle;
  int tempDrawUnknownLandmarks;
  int tempDrawCorners;
  int tempDisplayInfo;
  int tempDisplayOutput;
  GET_CONFIG(
    "VisionConfig",
    (int, LinesExtraction.scanStepHighUpperCam, scanStepHighUpperCam),
    (int, LinesExtraction.scanStepHighLowerCam, scanStepHighLowerCam),
    (int, LinesExtraction.scanStepLowUpperCam, scanStepLowUpperCam),
    (int, LinesExtraction.scanStepLowLowerCam, scanStepLowLowerCam),
    (int, LinesExtraction.sendTime, tempSendTime),
    (int, LinesExtraction.drawScannedEdges, tempDrawScannedEdges),
    (int, LinesExtraction.drawBorderLines, tempDrawBorderLines),
    (int, LinesExtraction.drawWorldLines, tempDrawWorldLines),
    (int, LinesExtraction.drawFiltWorldLines, tempDrawFiltWorldLines),
    (int, LinesExtraction.drawCircle, tempDrawCircle),
    (int, LinesExtraction.drawCorners, tempDrawCorners),
    (int, LinesExtraction.displayInfo, tempDisplayInfo),
    (int, LinesExtraction.displayOutput, tempDisplayOutput),
    (int, LinesExtraction.drawUnknownLandmarks, tempDrawUnknownLandmarks),
  )
  SET_DVAR(int, sendTime, tempSendTime);
  SET_DVAR(int, drawScannedEdges, tempDrawScannedEdges);
  SET_DVAR(int, drawBorderLines, tempDrawBorderLines);
  SET_DVAR(int, drawWorldLines, tempDrawWorldLines);
  SET_DVAR(int, drawFiltWorldLines, tempDrawFiltWorldLines);
  SET_DVAR(int, drawCircle, tempDrawCircle);
  SET_DVAR(int, drawCorners, tempDrawCorners);
  SET_DVAR(int, drawUnknownLandmarks, tempDrawUnknownLandmarks);
  SET_DVAR(int, displayInfo, tempDisplayInfo);
  SET_DVAR(int, displayOutput, tempDisplayOutput);

  //! Get other feature extraction classes
  fieldExt = GET_FEATURE_EXT_CLASS(FieldExtraction, FeatureExtractionIds::FIELD);
  regionSeg = GET_FEATURE_EXT_CLASS(RegionSegmentation, FeatureExtractionIds::SEGMENTATION);
  robotExt = GET_FEATURE_EXT_CLASS(RobotExtraction, FeatureExtractionIds::ROBOT);

  worldImage = Mat(Size(1000, 700), CV_8UC3, Scalar(0));
  int width = 1000;
  int height = 700;
  worldImage = Scalar(0, 100, 0); //BGR
  int borderDiff = 50;
  rectangle(
    worldImage,
    Point(borderDiff, borderDiff),
    Point(width - borderDiff, height - borderDiff),
    Scalar(255, 255, 255),
    5);
  rectangle(
    worldImage,
    Point(borderDiff, height / 2 - 220 / 2),
    Point(borderDiff + 60, height / 2 + 220 / 2),
    Scalar(255, 255, 255),
    5);
  rectangle(
    worldImage,
    Point(width - borderDiff, height / 2 - 220 / 2),
    Point(width - borderDiff - 60, height / 2 + 220 / 2),
    Scalar(255, 255, 255),
    5);
  rectangle(
    worldImage,
    Point(borderDiff + 130 - 6, height / 2 + 3),
    Point(borderDiff + 130 + 6, height / 2 - 3),
    Scalar(255, 255, 255),
    -1);
  rectangle(
    worldImage,
    Point(borderDiff + 130 - 3, height / 2 + 6),
    Point(borderDiff + 130 + 3, height / 2 - 6),
    Scalar(255, 255, 255),
    -1);
  rectangle(
    worldImage,
    Point(width - borderDiff - 130 + 6, height / 2 + 3),
    Point(width - borderDiff - 130 - 6, height / 2 - 3),
    Scalar(255, 255, 255),
    -1);
  rectangle(
    worldImage,
    Point(width - borderDiff - 130 + 3, height / 2 + 6),
    Point(width - borderDiff - 130 - 3, height / 2 - 6),
    Scalar(255, 255, 255),
    -1);
  rectangle(
    worldImage,
    Point(width / 2 - 6, height / 2 + 3),
    Point(width / 2 + 6, height / 2 - 3),
    Scalar(255, 255, 255),
    -1);
  line(
    worldImage,
    Point(width / 2, 5),
    Point(width / 2, height - 5),
    Scalar(255, 255, 255),
    5);
  circle(
    worldImage,
    Point(width / 2, height / 2),
    75,
    Scalar(255, 255, 255),
    5);

  //! Initializing processing times
  edgeScanTime = 0.f;
  fitLinesTime = 0.f;
  filterLinesTime = 0.f;
  findFeaturesTime = 0.f;
  findCircleTime = 0.f;
  addLandmarksTime = 0.f;
  processTime = 0.f;

  //currentImage = BOTTOM_CAM;
}

Point LinesExtraction::worldToImage(const Point& point)
{
  auto& rP = IVAR(RobotPose2D<float>, VisionModule::robotPose2D);
  auto pointT = rP.transform(point);
  return Point(pointT.x * 100 + 500, 350 - pointT.y * 100);
}

/**
 * @brief worldToImage Converts a point from world coordinates to world image coordinates
 * @param point Input point in world
 * @return Output point in world image
 */
Point2f LinesExtraction::worldToImage(const Point2f& point)
{
  auto& rP = IVAR(RobotPose2D<float>, VisionModule::robotPose2D);
  auto pointT = rP.transform(point);
  return Point2f(pointT.x * 100 + 500, 350 - pointT.y * 100);
}

void LinesExtraction::processImage()
{
  auto tStart = high_resolution_clock::now();
  static int imageResetCount = 0;
  if (imageResetCount > 5) {
    currentImage = currentImage == TOP_CAM ? BOTTOM_CAM : TOP_CAM;
    imageResetCount = 0;
  }
  imageResetCount++;
  if (fieldExt->isFound()) {
    if (GET_DVAR(int, displayOutput))
      worldImage = Scalar(0);
    if (currentImage == BOTTOM_CAM) {
      Point2f tempP;
      cameraTransforms[currentImage]->imageToWorld(tempP, Point2f(0, 0), 0.f);
      cameraTransforms[currentImage]->imageToWorld(tempP, Point2f(getImageWidth(), 0), 0.f);
      cameraTransforms[currentImage]->imageToWorld(tempP, Point2f(getImageWidth(), getImageHeight()), 0.f);
      cameraTransforms[currentImage]->imageToWorld(tempP, Point2f(0, getImageHeight()), 0.f);
    }
    vector<vector<ScannedEdgePtr> > connectedEdges;
    if (scanForEdges(connectedEdges)) {
      vector<FittedLinePtr> worldLines;
      findLinesFromEdges(connectedEdges, worldLines);
      if (currentImage != BOTTOM_CAM) {
        vector<Point2f> circlePoints;
        filterLines(worldLines, circlePoints);
        findFeatures(worldLines);
        Circle circleOutput;
        if (findCircle(circleOutput, circlePoints)) {
          computeCircleLandmark(circleOutput, worldLines);
          if (GET_DVAR(int, drawCircle)) {
            circle(
              worldImage,
              worldToImage(circleOutput.center),
              circleOutput.radius * 100,
              Scalar(0, 255, 0),
              1
            );
          }
        }
      }
      addLineLandmarks(worldLines);
    }
  }
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  processTime = timeSpan.count();
  if (GET_DVAR(int, displayInfo)) {
    LOG_INFO("LinesExtraction Results:");
    LOG_INFO("Time taken by scanning for edges: " << edgeScanTime);
    LOG_INFO("Time taken by fitting lines to edges: " << fitLinesTime);
    LOG_INFO("Time taken by filtering lines: " << filterLinesTime);
    LOG_INFO("Time taken by finding features: " << findFeaturesTime);
    LOG_INFO("Time taken by finding circle: " << findCircleTime);
    LOG_INFO("Time taken by adding landmarks: " << addLandmarksTime);
    LOG_INFO("Time taken by overall processing: " << processTime);
  }
  if (GET_DVAR(int, displayOutput)) {
    VisionUtils::displayImage(bgrMat[currentImage], "LinesExtraction Image");
    VisionUtils::displayImage(worldImage, "LinesExtraction World");
    //waitKey(0);
  }
}

bool LinesExtraction::scanForEdges(
  vector<vector<ScannedEdgePtr> >& connectedEdges)
{
  auto tStart = high_resolution_clock::now();
  auto border = fieldExt->getBorder();
  auto fHeight = fieldExt->getFieldHeight();
  auto robotRegions = robotExt->getRobotRegions();
  if (border.empty()) {
    duration<double> timeSpan = high_resolution_clock::now() - tStart;
    edgeScanTime = timeSpan.count();
    return false;
  }
  vector<Point2f> verImagePoints;
  vector<Point2f> horImagePoints;
  vector<Point2f> verWorldPoints;
  vector<Point2f> horWorldPoints;
  //lineEdges.clear();// = regionSeg->getLineEdges();

  srand(time(0));
  int scanStepHigh, scanStepLow;
  if (currentImage == TOP_CAM) {
    scanStepHigh = scanStepHighUpperCam;
    scanStepLow = scanStepLowUpperCam;
  } else {
    scanStepHigh = scanStepHighLowerCam;
    scanStepLow = scanStepLowLowerCam;
  }
  int scanStart = rand() % scanStepHigh + fHeight;
  for (int y = scanStart; y < getImageHeight(); y = y + scanStepHigh) {
    //uchar* p = whiteEdges.ptr<uchar>(y);
    int horStartLine = -1;
    int horStartLow = rand() % scanStepLow;
    for (int x = horStartLow; x < getImageWidth(); x = x + scanStepLow) {
      bool scan = true;
      if (currentImage == TOP_CAM) {
        for (int j = 0; j < robotRegions.size(); ++j) {
          if (!robotRegions[j]) continue;
          if (robotRegions[j]->sr->rect.contains(Point(x, y))) {
            scan = false;
            break;
          }
        }
      }
      if (!scan) continue;
      auto color = getYUV(x, y);
      //! Horizontal Scanning
      if (colorHandler->isColor(color, Colors::WHITE)) {
        if (horStartLine == -1) horStartLine = x;
        if (horStartLine != -1) {
          int diff = abs(x - horStartLine);
          if (diff >= scanStepHigh) {
            horStartLine = -1;
          }/*
           int index = (horStartLine + x - scanStepLow) / 2;
           p[index] = 255;
           auto se =
           boost::make_shared<ScannedEdge>(Point(index, y));
           lineEdges.push_back(se);
           horStartLine = -1;*/
        }
      } else {
        if (horStartLine != -1) {
          int diff = abs(x - horStartLine);
          if (diff >= 0) {
            int index;
            if (diff == 0) {
              index = horStartLine;
            } else {
              index = (horStartLine + x - scanStepLow) / 2;
            }
            //p[index] = 255;
            horImagePoints.push_back(Point2f(index, y));
            //auto se =
            //  boost::make_shared<ScannedEdge>(Point(index, y));
            //horLineEdges.push_back(se);
          }
        }
        horStartLine = -1;
      }
    }
  }

  scanStart = rand() % scanStepHigh;
  for (int x = scanStart; x < getImageWidth(); x = x + scanStepHigh) {
    //cout << "x: " <<x << endl;
    int verStartLine = -1;
    int verStartLow = rand() % scanStepLow;
    if (currentImage == TOP_CAM)
      verStartLow += border[x].y;
    for (int y = verStartLow; y < getImageHeight(); y = y + scanStepLow) {
      //cout << "y: " << y << endl;
      bool scan = true;
      if (currentImage == TOP_CAM) {
        for (int j = 0; j < robotRegions.size(); ++j) {
          if (!robotRegions[j]) continue;
          if (robotRegions[j]->sr->rect.contains(Point(x, y))) {
            scan = false;
            break;
          }
        }
      }
      if (!scan) continue;
      auto color = getYUV(x, y);
      if (colorHandler->isColor(color, Colors::WHITE)) {
        //cout << "found white..." << endl;
        if (verStartLine == -1) {
          verStartLine = y;
        }
        if (verStartLine != -1) {
          float diff = y - verStartLine;
          if (diff >= scanStepHigh) {
            //int index = (verStartLine + y - scanStepLow) / 2;
            //uchar* p = whiteEdges.ptr<uchar>(index);
            //p[x] = 255;
            //auto se =
            // boost::make_shared<ScannedEdge>(Point2f(x, index));
            //lineEdges.push_back(se);
            verStartLine = -1;
          }
        }
      } else {
        if (verStartLine != -1) {
          float diff = y - verStartLine;
          if (diff >= 1) {
            int index;
            if (diff == 0) {
              index = verStartLine;
            } else {
              index = (verStartLine + y - scanStepLow) / 2;
            }
            //uchar* p = whiteEdges.ptr<uchar>(index);
            //p[x] = 255;
            verImagePoints.push_back(Point2f(x, index));
            //auto se =
            // boost::make_shared<ScannedEdge>(Point2f(x, index));
            //verLineEdges.push_back(se);
          }
        }
        verStartLine = -1;
      }
    }
  }

  vector<ScannedEdgePtr> verLineEdges;
  vector<ScannedEdgePtr> horLineEdges;
  if (!verImagePoints.empty()) {
    cameraTransforms[currentImage]->imageToWorld(
      verWorldPoints,
      verImagePoints,
      0.0);
    for (int i = 0; i < verWorldPoints.size(); ++i) {
      auto se =
        boost::make_shared <ScannedEdge> (verImagePoints[i], verWorldPoints[i]);
      verLineEdges.push_back(se);
    }
    findConnectedEdges(connectedEdges, verLineEdges, scanStepHigh * 1.5, scanStepHigh * 1.5, true);
  }
  //imshow("bgr", bgrMat[currentImage]);
  //imshow("wl", worldImage);
  //waitKey(0);
  if (!horImagePoints.empty()) {
    cameraTransforms[currentImage]->imageToWorld(
      horWorldPoints,
      horImagePoints,
      0.0);
    for (int i = 0; i < horWorldPoints.size(); ++i) {
      auto se =
        boost::make_shared < ScannedEdge > (horImagePoints[i], horWorldPoints[i]);
      horLineEdges.push_back(se);
    }
    findConnectedEdges(connectedEdges, horLineEdges, scanStepHigh * 1.5, scanStepHigh * 1.5, false);
  }
  if (GET_DVAR(int, drawScannedEdges)) {
    VisionUtils::drawPoints(horImagePoints, bgrMat[currentImage]);
    VisionUtils::drawPoints(verImagePoints, bgrMat[currentImage]);
  }
  //imshow("bgr", bgrMat[currentImage]);
  //imshow("wl", worldImage);
  //waitKey(0);
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  edgeScanTime = timeSpan.count();
  if (connectedEdges.empty()) return false;
  return true;
}

void LinesExtraction::findConnectedEdges(
  vector<vector<ScannedEdgePtr> >& connectedEdges,
  vector<ScannedEdgePtr>& scannedEdges, const unsigned& xTol,
  const unsigned& yTol, const bool& verticalScan)
{
  typedef vector<ScannedEdgePtr>::iterator sEIter;
  sEIter iter = scannedEdges.begin();
  while (iter != scannedEdges.end()) {
    if (*iter) ++iter;
    else iter = scannedEdges.erase(iter);
  }

  sort(scannedEdges.begin(), scannedEdges.end(), [](
    const ScannedEdgePtr& se1,
    const ScannedEdgePtr& se2)
  { return se1->pI.x < se2->pI.x;});

  ScannedEdgePtr pred;
  for (int i = 0; i < scannedEdges.size(); ++i) {
    ScannedEdgePtr se = scannedEdges[i];
    se->closestDist = 1000;
    se->angleW = 1000;
    se->bestNeighbor.reset();
    se->bestTo.reset();
    if (pred) se->pred = pred;
    pred = se;
  }
  int minDist = 12;
  int maxDist = sqrt(yTol * yTol + xTol * xTol);
  for (int i = 0; i < scannedEdges.size(); ++i) {
    ScannedEdgePtr se = scannedEdges[i];
    ScannedEdgePtr neighbor = se->pred;
    while (neighbor) {
      int diffY = abs(neighbor->pI.y - se->pI.y);
      if (diffY < yTol) {
        int diffX = abs(neighbor->pI.x - se->pI.x);
        if (verticalScan) {
          if (diffX < minDist && fabsf(neighbor->angleW - se->angleW) < 30 * M_PI / 180) {
            neighbor = neighbor->pred;
            continue;
          }
        } else {
          if (diffY < minDist) {
            neighbor = neighbor->pred;
            continue;
          }
        }

        int dist = sqrt(diffX * diffX + diffY * diffY);
        if (dist < maxDist) {
          if (dist < se->closestDist) {
            se->closestDist = dist;
            se->bestNeighbor = neighbor;
            se->bestNeighbor->bestTo = se;
          } else {
            if (se->bestNeighbor) {
              //cout << "se->closestDist: " << se->closestDist << endl;
              //cout << "se->bestNeighbor: " << se->bestNeighbor << endl;
              //cout << "se->angleW: " << se->angleW * 180 /3.14 << endl;
              break;
            }
          }
        } else {
          if (se->bestNeighbor) {
            //cout << "se->closestDist: " << se->closestDist << endl;
            //cout << "se->bestNeighbor: " << se->bestNeighbor << endl;
            //cout << "se->angleW: " << se->angleW * 180 /3.14 << endl;
            break;
          }
        }
      }
      neighbor = neighbor->pred;
    }
    if (se->bestNeighbor) {
      //cout << "i: " << i << endl;
      se->angleW = atan2(
        se->bestNeighbor->pW.y - se->pW.y,
        se->bestNeighbor->pW.x - se->pW.x);
    }
  }
  for (int i = 0; i < scannedEdges.size(); ++i) {
    if (scannedEdges[i]->angleW == 1000) {
      if (scannedEdges[i]->bestTo)
        scannedEdges[i]->angleW = scannedEdges[i]->bestTo->angleW;
      else scannedEdges[i].reset();
    }
  }
  reverse(scannedEdges.begin(), scannedEdges.end());
  //sort(scannedEdges.begin(), scannedEdges.end(), [](
  //  const ScannedEdgePtr& se1,
  //  const ScannedEdgePtr& se2)
  //{ return se1->angleW < se2->angleW;});

  //vector<ScannedEdgePtr> chainParents;
  int minChainLength = 2;
  for (int i = 0; i < scannedEdges.size(); ++i) {
    if (!scannedEdges[i]) continue;
    vector<ScannedEdgePtr> groupedEdges;
    ScannedEdgePtr se = scannedEdges[i];
    if (se->searched) continue;
    groupedEdges.push_back(se);
    //chainParents.push_back(se);
    ScannedEdgePtr neighbor = se->bestNeighbor;
    //VisionUtils::drawPoint(se->pI, bgrMat[currentImage], Scalar(0,255,0));
    while (neighbor) {
      if (fabsf(neighbor->angleW - se->angleW) > 30 * M_PI / 180) {
        //cout << "break" << endl;
        //imshow("bgr", bgrMat[currentImage]);
        //waitKey(0);
        break;
      }
      if (neighbor->searched) {
        //cout << "break" << endl;
        //imshow("bgr", bgrMat[currentImage]);
        //waitKey(0);
        break;
      }
      //cout << "se->angleW: " << se->angleW * 180 / M_PI << endl;
      // cout << "neighbor->angleW: " << neighbor->angleW * 180 / M_PI << endl;
      // cout << "diff:" << fabsf(neighbor->angleW - se->angleW) * 180 / M_PI  << endl;
      //VisionUtils::drawPoint(neighbor->pI, bgrMat[currentImage], Scalar(0,255,255));
      //cout << "angle:" << neighbor->angleW * 180 / M_PI << endl;
      //imshow("bgr", bgrMat[currentImage]);
      //waitKey(0);
      neighbor->searched = true;
      groupedEdges.push_back(neighbor);
      neighbor = neighbor->bestNeighbor;
    }
    se->searched = true;
    if (groupedEdges.size() > minChainLength) {
      connectedEdges.push_back(groupedEdges);
    }
  }
}

void LinesExtraction::findLinesFromEdges(
  const vector<vector<ScannedEdgePtr> >& connectedEdges,
  vector<FittedLinePtr>& lines)
{
  //cout <<"linesfromedges" << endl;
  //cout << "connectedEdges.size(): " << connectedEdges.size() << endl;
  auto tStart = high_resolution_clock::now();
  mt19937 rng;
  uniform_real_distribution<> dist
    { 0, 1 };
  const int maxIters = 5;
  for (size_t i = 0; i < connectedEdges.size(); ++i) {
    if (connectedEdges[i].size() < 3)
      continue;
    //for (size_t j = 0; j < connectedEdges[i].size(); ++j) {
    //  VisionUtils::drawPoint(this->worldToImage(connectedEdges[i][j]->pW), worldImage, Scalar(0,255,255));
    //}
    float bestNx = 0;
    float bestNy = 0;
    float bestD = 0;
    int maxSum = 0;
    int pointsCnt = 0;
    for (int n = 0; n < maxIters; ++n) {
      auto p1 =
        connectedEdges[i][(int) (dist(rng) * connectedEdges[i].size())]->pW;
      auto p2 =
        connectedEdges[i][(int) (dist(rng) * connectedEdges[i].size())]->pW;
      if (p1.x != p2.x || p1.y != p2.y) {
        if (p1.x > p2.x) {
          Point2d tmp = p1;
          p1 = p2;
          p2 = tmp;
        }
        auto diff = p1 - p2;
        float len = norm(diff);
        if (len > 0.20) { // Length greater than 0.20 meters
          float nx = -diff.y / len;
          float ny = diff.x / len;
          float perpDist = nx * p1.x + ny * p1.y;
          int sum = 0;
          int cnt = 0;
          for (int j = 0; j < connectedEdges[i].size(); ++j) {
            auto p = connectedEdges[i][j]->pW;
            float dist = fabsf(nx * p.x + ny * p.y - perpDist);
            if (dist < 0.1f) {
              cnt++;
              sum += 1;
            } else if (dist > 0.1f && dist < 0.25f) {
              sum -= 1;
            }
          }
          if (sum > maxSum) {
            maxSum = sum;
            pointsCnt = cnt;
            bestNx = nx;
            bestNy = ny;
            bestD = perpDist;
          }
          if (pointsCnt >= 0.8 * connectedEdges[i].size()) {
            break;
          }
        }
      }
    }
    if (pointsCnt < 0.5 * connectedEdges[i].size()) {
      auto fl = boost::make_shared<FittedLine>();
      fl->circleLine = true;
      vector<Point2f> points;
      for (int j = 0; j < connectedEdges[i].size(); ++j) {
        points.push_back(connectedEdges[i][j]->pW);
      }
      fl->points = boost::make_shared<vector<Point2f> >(points);
    } else {
      if (pointsCnt >= 3) {
        vector<Point2f> collinearPoints;
        for (int j = 0; j < connectedEdges[i].size(); ++j) {
          auto p = connectedEdges[i][j]->pW;
          float dist = fabsf(bestNx * p.x + bestNy * p.y - bestD);
          if (dist <= 0.1f) collinearPoints.push_back(p);
        }
        sort(
          collinearPoints.begin(),
          collinearPoints.end(),
          [](const Point2f& p1, const Point2f& p2) {
            return (p1.x < p2.x) ||
            ((p1.x == p2.x) && (p1.y < p2.y));
          });
        Point2f minP = collinearPoints[0];
        Point2f maxP = collinearPoints.back();
        auto fl = boost::make_shared<FittedLine> (minP, maxP);
        fl->diff = maxP - minP;
        fl->d = norm(fl->diff);
        fl->perp = Point2f(bestNx, bestNy);
        fl->perpDist = bestD;
        fl->unit = Point2f(fl->diff.x / fl->d, fl->diff.y / fl->d);
        fl->points = boost::make_shared < vector<Point2f> > (collinearPoints);
        lines.push_back(fl);
        if (GET_DVAR(int, drawWorldLines)) {
          Point2f p11 = worldToImage(fl->p1);
          Point2f p12 = worldToImage(fl->p2);
          line(worldImage, p11, p12, Scalar(0,0,255), 1);
        }
        //imshow("worldImage", worldImage);
        //waitKey(0);
      }
    }
  }
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  fitLinesTime = timeSpan.count();
}

void LinesExtraction::filterLines(
  vector<FittedLinePtr>& worldLines,
  vector<Point2f>& circlePoints)
{
  auto tStart = high_resolution_clock::now();
  auto borderLines = fieldExt->getBorderLinesWorld();
  FittedLinePtr borderLine;
  //cout << "borderLines.size(): " << borderLines.size() << endl;
  if (borderLines.size() > 1) {
    borderLine =
      borderLines[0]->d > borderLines[1]->d ? borderLines[0] : borderLines[1];
  } else {
    borderLine = borderLines[0];
  }
  if(GET_DVAR(int, drawBorderLines)) {
    Point2f p11 = worldToImage(borderLine->p1);
    Point2f p12 = worldToImage(borderLine->p2);
    line(worldImage, p11, p12, Scalar(0,255,255), 1);
  }
  auto angleL = atan2(borderLine->unit.y, borderLine->unit.x);
  angleL = angleL > M_PI_2 ? M_PI - angleL : angleL;
  angleL = angleL < 0 ? M_PI + angleL : angleL;
  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    auto wl = worldLines[i];
    //cout << "i: " << i << endl;
    //line(worldImage, worldToImage(wl->p1), worldToImage(wl->p2), Scalar(255,0,0), 1);
    //if (GET_DVAR(int, displayOutput)) {
    //  VisionUtils::displayImage(worldImage, "LinesExtraction Image2");
    //}
    float dist =
      borderLine->perp.x * wl->p1.x + borderLine->perp.y * wl->p1.y - borderLine->perpDist;
    if (fabsf(dist) < 0.35) { // Perpendicular distance from border line
      worldLines[i].reset();
      //cout << "rejected1" << endl;
      continue;
    }
    Point2f inter = findIntersection(wl, borderLine);
    if (inter.x != -100) {
      float diff1 = norm(inter - wl->p1);
      float diff2 = norm(inter - wl->p2);
      float ratio = diff1 / wl->d + diff2 / wl->d;
      if (diff1 < 0.35 || diff2 < 0.35 || (ratio > 0.9 && ratio < 1.1)) {
        worldLines[i].reset();
        //cout << "rejected2" << endl;
        continue;
      }
    }
    float angleW = atan2(wl->unit.y, wl->unit.x);
    //angleW = angleW > M_PI_2 ? M_PI - angleW : angleW;
    angleW = angleW < 0 ? M_PI + angleW : angleW;
    //cout << "angleW: " << angleW * 180 / 3.14<< endl;
    //cout << "angleWcheck1" << (int)(angleW > M_PI_2) << endl;
    //cout << "angleWcheck2" << M_PI - angleW << endl;
    auto angleD = abs(angleW - angleL);
    //cout << "angleDiff: " << angleD  * 180 / 3.14<< endl;
    // 15-75 degrees the difference between border line angle and the estimated world line angle
    // Might or might not have to increase the tolerance in real world
    worldLines[i]->angle = angleW;
    if (angleD >= 0.261666667 && angleD <= 1.308333333) {
      if (wl->d < 1.0f && fabsf(dist) > 2.5f) {
        auto points = *(wl->points);
        //line(worldImage, worldToImage(wl->p1),  worldToImage(wl->p2), Scalar(255,0,255), 1);
        circlePoints.insert(circlePoints.begin(), points.begin(), points.end());
        wl->circleLine = true;
      } else {
        worldLines[i].reset();
        //cout << "rejected3" << endl;
        continue;
      }
    }
  }

  for (size_t i = 0; i < worldLines.size(); ++i) {
    //worldImage= Scalar(0);
    if (!worldLines[i]) continue;
    if (worldLines[i]->circleLine) continue;
    auto wl1 = worldLines[i];
    vector<Point2f> collinearPoints;
    vector<Point2f> points2;
    //Point2f p11 = Point(wl1->p1.x * 100 + 500, 350 - wl1->p1.y * 100);
    //Point2f p12 = Point(wl1->p2.x * 100 + 500, 350 - wl1->p2.y * 100);
    //line(worldImage, p11, p12, Scalar(255,0,0), 2);
    collinearPoints.push_back(wl1->p1);
    collinearPoints.push_back(wl1->p2);
    for (size_t j = i; j < worldLines.size(); ++j) {
      if (!worldLines[j]) continue;
      if (worldLines[j]->circleLine) continue;
      if (i != j) {
        auto wl2 = worldLines[j];
        //Point2f p21 = Point(wl2->p1.x * 100 + 500, 350 - wl2->p1.y * 100);
        //Point2f p22 = Point(wl2->p2.x * 100 + 500, 350 - wl2->p2.y * 100);
        //line(worldImage, p21, p22, Scalar(0,255,0), 2);
        //cout << "angle1: " << wl1->angle * 180/ 3.14 << endl;
        //cout << "angle2: " << wl2->angle * 180/ 3.14 << endl;

        if (abs(wl2->angle - wl1->angle) < 0.261666667) {
          float dist =
            wl1->perp.x * wl2->p1.x + wl1->perp.y * wl2->p1.y - wl1->perpDist;
          if (fabsf(dist) < 0.1) {
            collinearPoints.push_back(wl2->p1);
            collinearPoints.push_back(wl2->p2);
            points2 = *(wl2->points);
            worldLines[j].reset();
          }
        }
      }
    }
    if (!collinearPoints.empty()) {
      Point2f p1, p2;
      float maxDist = 0;
      for (int j = 0; j < collinearPoints.size(); ++j) {
        for (int k = j; k < collinearPoints.size(); ++k) {
          float dist = norm(collinearPoints[j] - collinearPoints[k]);
          if (dist > maxDist) {
            maxDist = dist;
            p1 = collinearPoints[j];
            p2 = collinearPoints[k];
          }
        }
      }
      auto wl = boost::make_shared < FittedLine > (p1, p2);
      wl->diff = p2 - p1;
      wl->d = norm(wl->diff);
      wl->unit = Point2f(wl->diff.x / wl->d, wl->diff.y / wl->d);
      wl->perp = Point2f(-wl->diff.y / wl->d, wl->diff.x / wl->d);
      wl->perpDist = wl->perp.x * wl->p1.x + wl->perp.y * wl->p1.y;
      float angleW = atan2(wl->unit.y, wl->unit.x);
      angleW = angleW < 0 ? M_PI + angleW : angleW;
      wl->angle = angleW;
      vector<Point2f> points1 = *(worldLines[i]->points);
      points1.insert(points1.begin(), points2.begin(), points2.end());
      wl->points = boost::make_shared < vector<Point2f> > (points1);
      worldLines[i] = wl;
      if (GET_DVAR(int, drawFiltWorldLines)) {
        Point2f p11 = worldToImage(p1);
        Point2f p12 = worldToImage(p2);
        line(worldImage, p11, p12, Scalar(0,255,0), 1);
      }
    }
  }

  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    if (worldLines[i]->circleLine) continue;
    auto wl = worldLines[i];
    float dist =
      borderLine->perp.x * wl->p1.x + borderLine->perp.y * wl->p1.y - borderLine->perpDist;
    if (wl->d < 0.65f && fabsf(dist) > 2.5f) { // Perpendicular distance from border line
      wl->circleLine = true;
    }
    //if (GET_DVAR(int, displayOutput)) {
      //VisionUtils::displayImage(worldImage, "LinesExtraction Image2");
    ////}
   // waitKey(0);
  }

  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    if (!worldLines[i]->circleLine) continue;
    auto wl = worldLines[i];
    Point2f p11 = worldToImage(wl->p1);
    Point2f p12 = worldToImage(wl->p2);
    line(worldImage, p11, p12, Scalar(0,255,0), 2);
    for (size_t j = i; j < worldLines.size(); ++j) {
      if (!worldLines[j]) continue;
      if (!worldLines[j]->circleLine) continue;
      if (i != j) {
        auto wl2 = worldLines[j];
        Point2f p11 = worldToImage(wl2->p1);
        Point2f p12 = worldToImage(wl2->p2);
        line(worldImage, p11, p12, Scalar(255,0,0), 2);
        Point2f inter = findIntersection(wl, wl2);
        if (inter.x != -100) {
          float diff1 = norm(inter - wl->p1);
          float diff2 = norm(inter - wl->p2);
          float ratio = diff1 / wl->d + diff2 / wl->d;
          if (diff1 < 0.35 || diff2 < 0.35 || (ratio > 0.9 && ratio < 1.1)) {
            float angleD = fabsf(wl->angle - wl2->angle);
            angleD = angleD > M_PI_2 ? M_PI - angleD : angleD;
            //cout << "angleD : " << angleD * 180 / M_PI  << endl;
            //cout << "wl->angle : " << wl->angle * 180 / M_PI << endl;
            //cout << "wl2->angle : " << wl2->angle * 180 / M_PI  << endl;
            if (angleD >= 75 * M_PI / 180 ||
                angleD <= 15 * M_PI / 180)
            {
              //cout << "circleLine removed" << endl;
              wl->circleLine = false;
              wl2->circleLine = false;
            }
          }
        }
      }
    }
  }

  int nCircleLines = 0;
  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    if (!worldLines[i]->circleLine) continue;
    nCircleLines++;
  }

  if (nCircleLines > 2) {
    for (size_t i = 0; i < worldLines.size(); ++i) {
      if (!worldLines[i]) continue;
      if (!worldLines[i]->circleLine) continue;
      auto points = *(worldLines[i]->points);
      //line(worldImage, worldToImage(worldLines[i]->p1),  worldToImage(worldLines[i]->p2), Scalar(255,0,255), 1);
      circlePoints.insert(circlePoints.begin(), points.begin(), points.end());
      //imshow("worldImage", worldImage);
      //waitKey(0);
    }
  } else {
    for (size_t i = 0; i < worldLines.size(); ++i) {
      if (!worldLines[i]) continue;
      if (!worldLines[i]->circleLine) continue;
      worldLines[i]->circleLine = false;
    }
  }

  /*for (size_t i = 0; i < circlePoints.size(); ++i) {
    VisionUtils::drawPoint(worldToImage(circlePoints[i]), worldImage);
  }
  imshow("circlePoints", worldImage);
  waitKey(0);*/

  FlIter iter = worldLines.begin();
  while (iter != worldLines.end()) {
    if (*iter) ++iter;
    else iter = worldLines.erase(iter);
  }
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  filterLinesTime = timeSpan.count();
}

void LinesExtraction::findFeatures(vector<FittedLinePtr>& worldLines)
{
  //cout << "Finding features..." << endl;
  auto tStart = high_resolution_clock::now();
  /*for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    if (worldLines[i]->circleLine) continue;
    auto wl1 = worldLines[i];
    Point2f p21 = Point(wl1->p1.x * 100 + 500, 350 - wl1->p1.y * 100);
    Point2f p22 = Point(wl1->p2.x * 100 + 500, 350 - wl1->p2.y * 100);
    line(worldImage, p21, p22, Scalar(255,0,0), 2);
    imshow("worldImage test", worldImage);
    waitKey(0);
  }*/
  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    if (worldLines[i]->circleLine) continue;
    //cout << "i;  " << i << endl;
    auto wl1 = worldLines[i];
    //Point2f p21 = Point(wl1->p1.x * 100 + 500, 350 - wl1->p1.y * 100);
    //Point2f p22 = Point(wl1->p2.x * 100 + 500, 350 - wl1->p2.y * 100);
    //line(worldImage, p21, p22, Scalar(255,0,0), 2);
    //imshow("worldImage", worldImage);
    //waitKey(0);
    for (size_t j = 0; j < worldLines.size(); ++j) {
      if (!worldLines[j]) continue;
      if (worldLines[j]->circleLine) continue;
      if (j != i) {
        auto wl2 = worldLines[j];
        Point2f inter = findIntersection(wl1, wl2);
        Point2f imageP;
        cameraTransforms[currentImage]->worldToImage(Point3f(inter.x, inter.y, 0.f), imageP);
        if (imageP.x < 20 || imageP.x > getImageWidth() - 20 || imageP.y < 20 || imageP.y > getImageHeight() - 20) {
          //cout << "imageP: " << imageP << endl;
          //VisionUtils::drawPoint(imageP, bgrMat[currentImage], Scalar(0, 0, 255));
          //imshow("bgrMat", bgrMat[currentImage]);
          //waitKey(0);
          continue;
        }
        //Point2f p21 = Point(wl2->p1.x * 100 + 500, 350 - wl2->p1.y * 100);
        //Point2f p22 = Point(wl2->p2.x * 100 + 500, 350 - wl2->p2.y * 100);
        //line(worldImage, p21, p22, Scalar(0,255,0), 2);
        //VisionUtils::drawPoint(Point(inter.x * 100 + 500, 350 - 100 * inter.y), worldImage, Scalar(0, 0, 255));
        //imshow("worldImage", worldImage);
        //waitKey(0);
        if (inter.x == -100) continue;
        //cout << "got inter" << endl;
        bool firstPass = false;
        bool secondPass = false;
        bool center1 = false;
        bool center2 = false;
        Point2f diff1 = inter - wl1->p1;
        float d1 = norm(diff1);
        //cout << "d1: " << d1 << endl;
        //cout << "d1 - wl1->d: " << d1 - wl1->d<< endl;
        Point2f unit1 = Point2f(diff1.x / d1, diff1.y / d1);
        if (unit1.x / (float) wl1->unit.x < 0) {
          if (d1 < 0.2) {
            firstPass = true;
          }
        } else {
          if (d1 - wl1->d < 0.3) { // meaning within 30 centimeters ahead of p2
            firstPass = true;
            float r = d1 / wl1->d;
            if (r > 0.05 && r < 0.95) {
              center1 = true;
            }
          }
        }
        if (firstPass) {
          //cout << "In first pass" << endl;
          Point2f diff2 = inter - wl2->p1;
          float d2 = norm(diff2);
          //cout << "d2: " << d2 << endl;
          //cout << "wl2->d: " << wl2->d << endl;
          //cout << "d2 - wl2->d: " << d2 - wl2->d<< endl;
          Point2f unit2 = Point2f(diff2.x / d2, diff2.y / d2);
          if (unit2.x / (float) wl2->unit.x < 0) {
            if (d2 < 0.2) {
              //cout << " 1"  << endl;
              secondPass = true;
            }
          } else {
            if (d2 - wl2->d < 0.3) { // meaning within 30 centimeters ahead of p2
              //cout << "2"  << endl;
              float r = d2 / wl2->d;
              if (r > 0.05 && r < 0.95) {
                center2 = true;
              }
              secondPass = true;
            }
          }
          // if (d1 / d2 > 3.f || d1 > d2 < 1/3.f)
          //  continue;

          if (secondPass) {
            //cout << "In second pass" << endl;
            // Finding angle
            float angle = acos(wl1->unit.dot(wl2->unit));
            //cout << "angle1:" << angle * 180/ 3.14 << endl;
            angle = angle > M_PI_2 ? M_PI - angle : angle;
            //cout << "angle:" << angle  * 180/ 3.14 << endl;
            //float diff45 = abs(angle - M_PI_2 / 2);
            //cout << "diff45:" << diff45 * 180/ 3.14<< endl;
            //Point2f p11 = Point(wl1->p1.x * 100 + 500, 350 - wl1->p1.y * 100);
            //Point2f p12 = Point(wl1->p2.x * 100 + 500, 350 - wl1->p2.y * 100);
            //Point2f p21 = Point(wl2->p1.x * 100 + 500, 350 - wl2->p1.y * 100);
            //Point2f p22 = Point(wl2->p2.x * 100 + 500, 350 - wl2->p2.y * 100);
            //line(worldImage, p11, p12, Scalar(255,255,255), 2);
            //line(worldImage, p21, p22, Scalar(255,255,255), 2);
            //cout << "center1: " << center1 << endl;
            //cout << "center2: " << center2 << endl;
            if (angle > 1.308333333) // 75 degrees
            {
              if (center1) {
                if (center2) {
                  if (GET_DVAR(int, drawCorners))
                    putText(worldImage, "X", worldToImage(Point(inter.x + 0.02, inter.y - 0.02)), CV_FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, CV_AA);
                  //VisionUtils::drawPoint(Point(inter.x * 100 + 500, 350 - 100 * inter.y), worldImage, Scalar(0,0,255));
                } else {
                  // Line 2 is perpendicular
                  // T joint
                  float norm1, norm2;
                  Point2f dist1, dist2;
                  dist1 = wl2->p1 - inter;
                  dist2 = wl2->p2 - inter;
                  norm1 = norm(dist1);
                  norm2 = norm(dist2);
                  Point2f unitT =
                    norm1 > norm2 ?
                      Point2f(dist1.x / norm1, dist1.y / norm1) :
                      Point2f(dist2.x / norm2, dist2.y / norm2);
                  computeLandmark(inter, unitT, FL_TYPE_T_CORNER);
                  //cout << "T joint " << endl;
                  if (GET_DVAR(int, drawCorners))
                    putText(worldImage, "T", worldToImage(Point(inter.x + 0.02, inter.y - 0.02)), CV_FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, CV_AA);
                }
              } else if (center2) {
                // Line 1 is perpendicular
                // T joint
                float norm1, norm2;
                Point2f dist1, dist2;
                dist1 = wl1->p1 - inter;
                dist2 = wl1->p2 - inter;
                norm1 = norm(dist1);
                norm2 = norm(dist2);
                Point2f unitT =
                  norm1 > norm2 ?
                    Point2f(dist1.x / norm1, dist1.y / norm1) :
                    Point2f(dist2.x / norm2, dist2.y / norm2);
                computeLandmark(inter, unitT, FL_TYPE_T_CORNER);
                //cout << "T joint " << endl;
                if (GET_DVAR(int, drawCorners))
                  putText(worldImage, "T", worldToImage(Point(inter.x + 0.02, inter.y - 0.02)), CV_FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, CV_AA);
              } else {
                // L joint
                float norm11, norm12;
                Point2f dist11, dist12;
                dist11 = wl1->p1 - inter;
                dist12 = wl1->p2 - inter;
                norm11 = norm(dist11);
                norm12 = norm(dist12);
                Point2f unitL1 =
                  norm11 > norm12 ?
                    Point2f(dist11.x / norm11, dist11.y / norm11) :
                    Point2f(dist12.x / norm12, dist12.y / norm12);
                float norm21, norm22;
                Point2f dist21, dist22;
                dist21 = wl2->p1 - inter;
                dist22 = wl2->p2 - inter;
                norm21 = norm(dist21);
                norm22 = norm(dist22);
                Point2f unitL2 =
                  norm21 > norm22 ?
                    Point2f(dist21.x / norm21, dist21.y / norm21) :
                    Point2f(dist22.x / norm22, dist22.y / norm22);
                Point2f unitL = unitL1 + unitL2;
                float normL = norm(unitL);
                unitL.x = unitL.x / normL;
                unitL.y = unitL.y / normL;
                computeLandmark(inter, unitL, FL_TYPE_L_CORNER);
                //cout << "L joint " << endl;
                if (GET_DVAR(int, drawCorners))
                  putText(worldImage, "L", worldToImage(Point(inter.x + 0.02, inter.y - 0.02)), CV_FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2, CV_AA);
              }
            }/* else if (angle > 0.087222222 * 2 && angle < 1.046666667) {
             /*if (!center1) {
             if (!center2) {
             if (wl1->d < 0.5) {
             //line(worldImage, p11, p12, Scalar(0,255,255), 2);
             circlePoints.push_back(wl1->p1);
             circlePoints.push_back(wl1->p1);
             }
             if (wl2->d < 0.5) {
             //line(worldImage, p21, p22, Scalar(0,255,255), 2);
             circlePoints.push_back(wl2->p1);
             circlePoints.push_back(wl2->p1);
             }
             //both 1 and 2
             } else {
             if (wl1->d < 0.5) {
             //line(worldImage, p11, p12, Scalar(0,255,255), 2);
             circlePoints.push_back(wl1->p1);
             circlePoints.push_back(wl1->p1);
             }
             //add 1
             }
             } else if (!center2) {
             //add 2
             if (wl2->d < 0.5) {
             //line(worldImage, p21, p22, Scalar(0,255,255), 2);
             circlePoints.push_back(wl2->p1);
             circlePoints.push_back(wl2->p1);
             }
             }
             circlePoints.push_back(inter);
             }*/
          }
        }
        //imshow("worldImage", worldImage);
        //waitKey(0);
      }
    }
  }
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  findFeaturesTime = timeSpan.count();
}

Point2f LinesExtraction::findIntersection(const FittedLinePtr& l1,
  const FittedLinePtr& l2)
{
  auto p1 = l1->p1;
  auto p2 = l1->p2;
  auto p3 = l2->p1;
  auto p4 = l2->p2;
  auto p1p2 = p1 - p2;
  auto p3p4 = p3 - p4;
  auto det = p1p2.x * p3p4.y - p1p2.y * p3p4.x;
  auto c1 = p1.x * p2.y - p1.y * p2.x;
  auto c2 = p3.x * p4.y - p3.y * p4.x;
  if (det != 0.0) {
    //! det == 0 -> Lines are parallel
    auto pX = (c1 * p3p4.x - p1p2.x * c2) / det;
    auto pY = (c1 * p3p4.y - p1p2.y * c2) / det;
    return Point2f(pX, pY);
  } else {
    return Point2f(-100, -100);
  }
}

void LinesExtraction::computeLandmark(
  const Point2f& inter,
  const Point2f& unitToBaseLine,
  const unsigned& type)
{
  float len = norm(inter);
  Point2f interUnit = Point2f(inter.x / len, inter.y / len);
  float cross = interUnit.x * unitToBaseLine.y - interUnit.y * unitToBaseLine.x;
  float dot = interUnit.dot(unitToBaseLine);
  float perpAngle = atan2(cross, dot) + atan2(inter.y, inter.x);
  float cosa = cos(perpAngle);
  float sina = sin(perpAngle);
  KnownLandmarkPtr l = boost::make_shared<KnownLandmark>();
  l->type = type;
  l->pos = inter;
  l->poseFromLandmark.x() = -cosa * inter.x - sina * inter.y; // From -R^t * t inverse rotation
  l->poseFromLandmark.y() = +sina * inter.x - cosa * inter.y;
  l->poseFromLandmark.theta() = -perpAngle;
  knownLandmarks.push_back(l);
  //cout << "inter: " << inter << endl;
  //cout << "robotX: "<< l.poseFromLandmark.x << endl;
  //cout << "robotY: "<< l.poseFromLandmark.y << endl;
  //cout << "robotOrientation: "<< l.poseFromLandmark.theta * 180 / 3.14 << endl;
  //VisionUtils::drawPoint(Point(inter.x * 100 + 500, 350 - 100 * inter.y), worldImage, Scalar(0,255,0));
  //imshow("worldImage", worldImage);
  //waitKey(0);
}

bool LinesExtraction::findCircle(Circle& circleOutput, vector<Point2f>& circlePoints)
{
  auto tStart = high_resolution_clock::now();
  if (circlePoints.empty()) {
    duration<double> timeSpan = high_resolution_clock::now() - tStart;
    findCircleTime = timeSpan.count();
    return false;
  }
  if (circlePoints.size() > 15) {
    float radius = 0.75;
    Mat meanMat;
    reduce(circlePoints, meanMat, 01, CV_REDUCE_AVG);
    Point2f meanP = Point2f(meanMat.at<float>(0, 0), meanMat.at<float>(0, 1));
    float maxDist = 0.f;
    for (int i = 0; i < circlePoints.size(); ++i) {
      auto dist = norm(meanP - circlePoints[i]);
      maxDist = dist > maxDist ? dist : maxDist;
    }
    //cout << "meanP: " << meanP << endl;
    //cout << "maxDist: " << maxDist << endl;
    if (maxDist < radius - 0.1)
      return false;
    //for (size_t i = 0 ; i < circlePoints.size(); ++i)
    //  VisionUtils::drawPoint(worldToImage(circlePoints[i]), worldImage);
    int maxCount = circlePoints.size() > 20 ? 20 : circlePoints.size();
    unsigned RANSACiterations = 10;
    int bestPoints = 0;
    Circle bestCircle;
    mt19937 rng;
    uniform_real_distribution<> dist
      { 0, 1 };
    bool circleFound = false;
    for (size_t n = 0; n < RANSACiterations; ++n) {
      if (circleFound)
        break;
      Point2f p1 = circlePoints[(int) (dist(rng) * circlePoints.size())];
      Point2f p2 = circlePoints[(int) (dist(rng) * circlePoints.size())];
      //! Make a circle for two points
      auto circles = Circle::pointsToCircle(p1, p2, radius);
      //cout  << "n: " << n << endl;
      for (size_t c = 0; c < circles.size(); ++c) {
        //cout  << "c: " << c << endl;
        int numPoints = 0;
        for (size_t i = 0; i < maxCount; ++i) {
          float dist = norm(circles[c].center - circlePoints[i]) - radius;
          if (fabsf(dist) < 0.15) {
            ++numPoints;
          } //else {
          //  --numPoints;
          //}
        }
        //cout << "numPoints: " << numPoints << endl;
        if (numPoints > bestPoints) {
          bestPoints = numPoints;
          bestCircle = circles[c];
        }
        if (GET_DVAR(int, drawCircle)) {
          circle(
            worldImage,
            worldToImage(circles[c].center),
            circles[c].radius * 100,
            Scalar(0, 255, 255 - c * 100),
            1
          );
        }
        if (bestPoints >= maxCount * 0.65)
          circleFound = true; break;
      }
      //if (n > RANSACiterations / 4.0 && bestPoints <= maxCount / 4.0)
      //  return false;
      //cout << "bestPoints: " << bestPoints << endl;
      //cout << "maxCount: " << maxCount << endl;
      //VisionUtils::displayImage(worldImage, "circle");
      //waitKey(0);
    }
    duration<double> timeSpan = high_resolution_clock::now() - tStart;
    findCircleTime = timeSpan.count();
    if (bestPoints >= maxCount * 0.65) {
      circleOutput = bestCircle;
      return true;
    } else {
      return false;
    }
  }
  return false;
}

void LinesExtraction::computeCircleLandmark(const Circle& c,
  const vector<FittedLinePtr>& worldLines)
{
  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    vector<Point2f> inters;
    auto wl = worldLines[i];
    if (wl->d > 0.6) {
      if (findCircleLineIntersection(c, wl, inters)) {
        if (!inters.empty()) {
          for (int i = 0; i < inters.size(); ++i) {
            Point2f diff;
            diff = inters[i] - c.center;
            float dist = norm(diff);
            Point2f unit = Point2f(diff.x / dist, diff.y / dist);
            computeLandmark(c.center, unit, FL_TYPE_CIRCLE);
          }
          break;
        }
        //VisionUtils::drawPoint(Point(inters[0].x * 100 + 500, 350 - 100 * inters[0].y), worldImage, Scalar(0,255,0));
        //VisionUtils::drawPoint(Point(inters[1].x * 100 + 500, 350 - 100 * inters[1].y), worldImage, Scalar(0,255,0));
        //imshow("worldImage", worldImage);
        //waitKey(0);
      }
    }
  }
}

bool LinesExtraction::findCircleLineIntersection(const Circle& c,
  const FittedLinePtr& wl, vector<Point2f>& intersections)
{
  float t =
    wl->unit.x * (c.center.x - wl->p1.x) + wl->unit.y * (c.center.y - wl->p1.y);
  Point2f bisectorP;
  bisectorP.x = t * wl->unit.x + wl->p1.x;
  bisectorP.y = t * wl->unit.y + wl->p1.y;
  float perpDist = norm(bisectorP - c.center);
  if (perpDist < 0.2) {
    float dt = sqrt(c.radius * c.radius - perpDist * perpDist);
    Point2f inter1, inter2;
    inter1.x = bisectorP.x + dt * wl->unit.x;
    inter1.y = bisectorP.y + dt * wl->unit.y;

    inter2.x = bisectorP.x - dt * wl->unit.x;
    inter2.y = bisectorP.y - dt * wl->unit.y;
    intersections.push_back(inter1);
    intersections.push_back(inter2);
    return true;
  } else {
    return false;
  }
}

void LinesExtraction::addLineLandmarks(vector<FittedLinePtr>& worldLines)
{
  auto tStart = high_resolution_clock::now();
  int count = 0;
  float nDiv;
  nDiv = currentImage == TOP_CAM ? 0.2 : 0.05;
  for (size_t i = 0; i < worldLines.size(); ++i) {
    if (!worldLines[i]) continue;
    auto wl = worldLines[i];
    int numPoints = ceil(wl->d / nDiv);
    for (int i = 0; i < numPoints; ++i) {
      UnknownLandmarkPtr l = boost::make_shared<UnknownLandmark>();
      l->type = FL_TYPE_LINES;
      float r = i / (float) numPoints;
      l->pos.x = wl->p1.x + wl->unit.x * wl->d * r;
      l->pos.y = wl->p1.y + wl->unit.y * wl->d * r;
      if (GET_DVAR(int, drawUnknownLandmarks))
        VisionUtils::drawPoint(worldToImage(l->pos), worldImage, Scalar(255, 255, 255));
      unknownLandmarks.push_back(l);
      count++;
    }
    if (count >= 20) break;
  }
  duration<double> timeSpan = high_resolution_clock::now() - tStart;
  addLandmarksTime = timeSpan.count();
  //cout << "Number of landmarks observerd2: " << OVAR(ObsLandmarks, VisionModule::unknownLandmarksObs).data.size() << endl;
}

/*bool LinesExtraction::checkEllipse(Ellipse& e)
{
  float ratio = e.rs / e.rl;
  if (ratio < 0.8 && ratio > 1.2) return false;
  if (e.rl < 0.45 || e.rs < 0.45 || e.rl > 0.9 || e.rs > 0.9) return false;
  return true;
}*/
